<?php include("../../bd.php"); ?>
<?php include("../../templates/header.php"); ?>

<div
    class="alert alert-primary"
    role="alert"
>
   
    <a href="anio_lectivos.php" class="alert-link">Administrador de años lectivos</a>
</div>

<?php include("../../templates/footer.php"); ?>