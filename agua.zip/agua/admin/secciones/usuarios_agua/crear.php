<?php 

include("../../bd.php");

if($_POST)
{
    $orden_lista=(isset($_POST['orden']))?$_POST['orden']:"";
    $nombres=(isset($_POST['nombres']))?$_POST['nombres']:"";
    $apellidos=(isset($_POST['apellidos']))?$_POST['apellidos']:"";
    $direccion=(isset($_POST['direccion']))?$_POST['direccion']:"";
    $telefono=(isset($_POST['telefono']))?$_POST['telefono']:"";
    $cedula=(isset($_POST['cedula']))?$_POST['cedula']:"";
    $anio_ingreso=(isset($_POST['anio_ingreso']))?$_POST['anio_ingreso']:"";
    $estado=(isset($_POST['estado']))?$_POST['estado']:"";
    $tercera_edad=(isset($_POST['tercera_edad']))?$_POST['tercera_edad']:"";
    $id_acceso="1";

        
    $sentencia=$conexion->prepare("INSERT INTO usuarios (orden_lista,nombres,apellidos,direccion,telefono,cedula,estado,tercera_edad,anio_ingreso,id_acceso)values(:valor_orden,:txtnombres,:txtapellidos,:txtdireccion,:txttelefono,:txtcedula,:txtestado,:txttercera,:txtanio,:txtacceso); ");
    $sentencia->bindParam(':valor_orden',$orden_lista);
    $sentencia->bindParam(':txtnombres',$nombres);
    $sentencia->bindParam(':txtapellidos',$apellidos);
    $sentencia->bindParam(':txtdireccion',$direccion);
    $sentencia->bindParam(':txttelefono',$telefono);
    $sentencia->bindParam(':txtcedula',$cedula);
    $sentencia->bindParam(':txtestado',$estado);
    $sentencia->bindParam(':txttercera',$tercera_edad);
    $sentencia->bindParam(':txtanio',$anio_ingreso);
    $sentencia->bindParam(':txtacceso',$id_acceso);
     
    $sentencia->execute();
    $mensaje="El usuario de Agua ha sido creado Exitosamente";

}


include("../../templates/header.php"); ?>

<script src="../../libs/CalendarControl.js" type="text/javascript"></script>
<link href="../../libs/CalendarControl.css"  rel="stylesheet" type="text/css">

<div class="card">
    <div class="card-header">Crear Usuarios</div>
    <div class="card-body">
        <form action="" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label for="orden" class="form-label">Orden</label>
            <input
                type="text"
                class="form-control"
                name="orden"
                id="orden"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="nombres" class="form-label">Nombres</label>
            <input
                type="text"
                class="form-control"
                name="nombres"
                id="nombres"
                aria-describedby="helpId"
                placeholder="El nombre de usuario de agua"
            />
            
        </div>
        <div class="mb-3">
            <label for="apellidos" class="form-label">Apellidos</label>
            <input
                type="text"
                class="form-control"
                name="apellidos"
                id="apellidos"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="direccion" class="form-label">Dirección</label>
            <input
                type="text"
                class="form-control"
                name="direccion"
                id="direccion"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="telefono" class="form-label">Teléfono</label>
            <input
                type="text"
                class="form-control"
                name="telefono"
                id="telefono"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="cedula" class="form-label">Cedula</label>
            <input
                type="text"
                class="form-control"
                name="cedula"
                id="cedula"
                aria-describedby="helpId"
                placeholder=""
            />
            
            
        </div>

        <div class="mb-3">
            <label for="anio_ingreso" class="form-label">Año de ingreso</label>
            <input
                type="text"
                class="form-control"
                name="anio_ingreso"
                id="anio_ingreso"
                aria-describedby="helpId"
                placeholder=""
                onclick="showCalendarControl(this);"
            />
        </div>

        <div class="mb-3">
            <label for="estado" class="form-label">Estado</label>
            <select
                class="form-select form-select-lg"
                name="estado"
                id="estado"
            >
                <option selected>Selecionar Uno</option>
                <option value="activo">Activo</option>
                <option value="pasivo">Pasivo</option>
                <option value="nuevo">Nuevo</option>
                
            </select>
        </div>
        
        <div class="mb-3">
            <label for="tercera_edad" class="form-label">Tercera Edad</label>
            <select
                class="form-select form-select-lg"
                name="tercera_edad"
                id="tercera_edad"
            >
                <option selected>Selecionar Uno</option>
                <option value="si">Si</option>
                <option value="no">No</option>
                                
            </select>
        </div>
        <button
            type="submit"
            class="btn btn-success"
        >
            Guardar
        </button>
        
        <a
            name=""
            id=""
            class="btn btn-primary"
            href="index.php"
            role="button"
            >Cancelar</a
        >
        
        
        </form>
       
    </div>
    
</div>




<?php include("../../templates/footer.php"); ?>

 