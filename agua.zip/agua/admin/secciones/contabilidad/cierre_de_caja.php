<?php   


include("../../bd.php");
include("../../templates/header.php"); 
    $anio_lectivo=$_SESSION['anio_lectivo'];
    $sentencia_anio=$conexion->prepare("SELECT * FROM a_lectivo WHERE anio_lectivo=:txtanio ");
    $sentencia_anio->bindParam(':txtanio',$anio_lectivo);
    $sentencia_anio->execute();
    $lista_anio=$sentencia_anio->fetch(PDO::FETCH_LAZY);

    $f_inicio=$_SESSION['f_inicio_periodo'];
    $f_final=$_SESSION['f_final_periodo'];
    $sentencia=$conexion->prepare("SELECT f_pago, sum(total)  as total_de_fecha FROM arqueo_total WHERE f_pago  between :txtfinicio  and :txtffinal GROUP BY f_pago ");
    $sentencia->bindParam(':txtfinicio',$f_inicio);
    $sentencia->bindParam(':txtffinal',$f_final);
    $sentencia->execute();
    $lista_aportes=$sentencia->fetchAll(PDO::FETCH_ASSOC);

?>
<script src="contabilidad.js" type="text/javascript">
</script>
<div class="card">
   <div class="card-header d-flex flex-grow-1 justify-content-center " >
   <h6> Comite de Agua Pijal</h6>
   </div>
</br>
<div class="card-header" >
Cierre de caja
<p class="text-end">Periodo &#160;<?php echo  $lista_anio['nombre_anio'];  ?> &#160;Desde &#160;<?php echo $f_inicio ?>&#160; Hasta&#160; <?php echo $f_final ?></p> 

  </div>
  
  <div class="card-body">
   <?php $i=0; ?>
  <table class="table" >
            <thead>
                <tr class="table-primary">
                    <th scope="col">Numero</th>
                    <th scope="col">Fecha de Pago</th>
                    <th scope="col">Total a la Fecha </th>
                    <th scope="col"> </th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_aportes as $registros){ ?>
                <tr class="table-light">
                    <td scope="row"><?php echo $i=$i+1; ?></li></td>
                    <td scope="row"><?php 
                    $fechaEntera = strtotime($registros['f_pago']);
                    $anio = date("Y", $fechaEntera);
                    $mes = date("m", $fechaEntera);
                    $dia = date("d", $fechaEntera);
                    $mes=abs($mes); 
                    
                    ?>
                <script language="JavaScript" type="text/javascript">
                document.write(fecha('<?php echo $registros['f_pago'];?>','<?php echo $dia;?>','<?php echo $mes;?>'));
	  	
                  </script>    
                
                </td>
                    <td class="subtotal"><?php echo $registros['total_de_fecha']; ?></td>
                    <td>
                    <!-- Modal -->
    <!-- Button trigger modal -->
<button type="button" 
class="btn btn-light" 
data-bs-toggle="modal" 
data-bs-target="#exampleModal"
title="Listar detalles del dia"
onclick="listar('<?php echo $registros['f_pago']; ?> ')"
data-bs-placement="top"
>
  Lista Pagos
</button>   
                   
                    </td>
                    
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
        <button
        name="sumar"
        id="sumar"
        class="btn btn-outline-primary"
        type="submit"
        value="sumar"
        onclick="sumar_cierre_caja()"

        >Total por Hoja </button> <input type="text" id="resultado_total" name="resultado_total"></input> Usd
        <!-- Scrollable modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">    </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="cerrar_modal" name="cerrar_modal"></button>
      </div>
      <div class="modal-body" id="divdetalle" >
        
      
     
      
      </div>
      <div class="modal-footer">
        
      <!--
      <button type="submit" class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Guardar el Usuario" name="guardar " id="guardar">Guardar</button>
      -->
    </div>
    </div>
  </div>
</div>

   </div>
</div>

<?php 

include("../../templates/footer.php"); 
?>

<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[2,'asc']]});
} );

  </script>
  <script>
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

  </script>