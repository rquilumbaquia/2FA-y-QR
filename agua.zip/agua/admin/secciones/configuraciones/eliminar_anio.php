<?php include("../../bd.php"); ?>
<?php 
if(isset($_GET['anio_lectivo']))
{
    $anio_lectivo=(isset($_GET['anio_lectivo']))?$_GET['anio_lectivo']:"";
       
    $sentencia=$conexion->prepare("DELETE FROM a_lectivo WHERE anio_lectivo=:txtaniolectivo; ");
    $sentencia->bindParam(':txtaniolectivo',$anio_lectivo);
    $sentencia->execute();
    $mensaje="El registro ha sido Eliminado del Sistema";

    
    $MM_redirectLoginSuccess ="anio_lectivos.php?mensaje=".$mensaje;
    header("Location: " . $MM_redirectLoginSuccess );

}

?>