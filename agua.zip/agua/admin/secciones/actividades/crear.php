<?php 
include("../../bd.php");

if($_POST)
{
    $nombre_actividad=(isset($_POST['nombre_actividad']))?$_POST['nombre_actividad']:"";
    $cantidad_rayas=(isset($_POST['cantidad_rayas']))?$_POST['cantidad_rayas']:"";
    $f_ejecucion=(isset($_POST['f_ejecucion']))?$_POST['f_ejecucion']:"";
    $observacion=(isset($_POST['observacion']))?$_POST['observacion']:"";
    $valor_no_cumplir=(isset($_POST['valor_no_cumplir']))?$_POST['valor_no_cumplir']:"";
   
    $sentencia=$conexion->prepare("INSERT INTO actividades (nombre_actividad,cantidad_rayas,f_ejecucion,observacion,valor_no_cumplir)values(:txtnombreactividad,:txtcantidadrayas,:txtfejecucion,:txtobservacion,:txtvalornocumplir); ");
    $sentencia->bindParam(':txtnombreactividad',$nombre_actividad);
    $sentencia->bindParam(':txtcantidadrayas',$cantidad_rayas);
    $sentencia->bindParam(':txtfejecucion',$f_ejecucion);
    $sentencia->bindParam(':txtobservacion',$observacion);
    $sentencia->bindParam(':txtvalornocumplir',$valor_no_cumplir);
    $sentencia->execute();
    $mensaje="La actividad se ha creado";

}

include("../../templates/header.php"); ?>

<script src="../../libs/CalendarControl.js" type="text/javascript"></script>
<link href="../../libs/CalendarControl.css"  rel="stylesheet" type="text/css">
<div class="card">
    <div class="card-header">Crear Actividades o Mingas</div>
    <div class="card-body">
        <form action="" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label for="nombre_actividad" class="form-label">Nombre actividad</label>
            <input
                type="text"
                class="form-control"
                name="nombre_actividad"
                id="nombre_actividsd"
                aria-describedby="helpId"
                placeholder="Ingrese la minga"
            />
        </div>
        <div class="mb-3">
            <label for="cantidad_rayas" class="form-label">Por la cantidad de rayas</label>
            <input
                type="text"
                class="form-control"
                name="cantidad_rayas"
                id="cantidad_rayas"
                aria-describedby="helpId"
                placeholder="numero de rayas validad por esta  minga"
            />
        </div>
        <div class="mb-3">
            <label for="f_ejecucionn" class="form-label">Fecha en la que se ralizará</label>
            <input
                type="text"
                class="form-control"
                name="f_ejecucion"
                id="f_ejecucion"
                aria-describedby="helpId"
                placeholder=""
                onclick="showCalendarControl(this);"
            />
            
        </div>
        <div class="mb-3">
            <label for="observacion" class="form-label">Detalles de la minga</label>
            <input
                type="text"
                class="form-control"
                name="observacion"
                id="observacion"
                aria-describedby="helpId"
                placeholder=""
            />
        </div>
        <div class="mb-3">
            <label for="valor_no_cumplir" class="form-label">Valor de multa por no cumplir</label>
            <input
                type="text"
                class="form-control"
                name="valor_no_cumplir"
                id="valor_no_cumplir"
                aria-describedby="helpId"
                placeholder="el valor de multa"
                
            />
        </div>
        <button
            type="submit"
            class="btn btn-success"
        >
            Guardar
        </button>
        <a
            name=""
            id=""
            class="btn btn-primary"
            href="index.php"
            role="button"
            >Cancelar</a
        >
        </form>
       
    </div>
</div>

<?php include("../../templates/footer.php"); ?>
