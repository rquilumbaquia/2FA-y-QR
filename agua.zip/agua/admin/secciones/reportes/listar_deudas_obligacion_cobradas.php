<?php 
include("../../bd.php");
include("../../templates/header.php"); 

if((isset($_GET['tabla']))&&($_GET['tabla']=="obligacion_por_llave"))
{
 

$codigo=$_GET['codigo'];
$datos_obligacion_llave=$conexion->prepare("SELECT * FROM obligacion_por_llave where id_obligacion_llave=:txtcodigo " );
$datos_obligacion_llave->bindParam(':txtcodigo',$codigo);
$datos_obligacion_llave->execute();
$lista=$datos_obligacion_llave->fetch(PDO::FETCH_LAZY);
   
$codigo=$_GET['codigo'];
$sentencia=$conexion->prepare("SELECT aporte_llave.id_aporte,aporte_llave.pagar,aporte_llave.valor_pago,usuarios.nombres,usuarios.apellidos,aporte_llave.observacion FROM aporte_llave,llaves,usuarios where aporte_llave.id_obligacion_llave=:txtcodigo and aporte_llave.id_llave=llaves.id_llave and llaves.id_usuario=usuarios.id_usuario and aporte_llave.observacion='Pagado' " );
$sentencia->bindParam(':txtcodigo',$codigo);
$sentencia->execute();
$lista_deudas=$sentencia->fetchAll(PDO::FETCH_ASSOC);

}

if((isset($_GET['tabla']))&&($_GET['tabla']=="obligacion_por_usuario"))
{
$codigo=$_GET['codigo'];
$datos_obligacion_llave=$conexion->prepare("SELECT * FROM obligacion_por_usuario where id_obligacion_usuario=:txtcodigo " );
$datos_obligacion_llave->bindParam(':txtcodigo',$codigo);
$datos_obligacion_llave->execute();
$lista=$datos_obligacion_llave->fetch(PDO::FETCH_LAZY);

$codigo=$_GET['codigo'];
$sentencia=$conexion->prepare("SELECT aporte_por_usuario.id_aporte,aporte_por_usuario.pagar,aporte_por_usuario.valor_pago,usuarios.nombres,usuarios.apellidos,aporte_por_usuario.observacion FROM aporte_por_usuario,usuarios where aporte_por_usuario.id_obligacion_usuario=:txtcodigo  and aporte_por_usuario.id_usuario=usuarios.id_usuario and aporte_por_usuario.observacion='Pagado' " );
$sentencia->bindParam(':txtcodigo',$codigo);
$sentencia->execute();
$lista_deudas=$sentencia->fetchAll(PDO::FETCH_ASSOC);
$total=0;

}

?>

 Obligaciones de: <?php echo $lista['nombre_obligacion']  ?>
<div class="card">
  
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table
            class="table" 
        >
            <thead>
                <tr>
                   
                    <th scope="col">Nombres</th>
                    <th scope="col">Pagar</th>
                    <th scope="col">Valor Pago</th>
                    <th scope="col">Observacion</th>
                   
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_deudas as $registros){ ?>
                <tr class="">
                   
                    <td><?php echo $registros['apellidos']." ".$registros['nombres']; ?></td>
                    <td><?php echo $registros['pagar']; ?></td>
                    <td><?php echo $registros['valor_pago']; $total=$total+$registros['valor_pago']; ?></td>
                    <td><?php echo $registros['observacion']; ?></td>
                    
                    
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
       

    </div>
  
</div>

Total Cobrado <?php echo $total;  ?>

<?php include("../../templates/footer.php"); ?>


<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[0,'asc']]});
} );

  </script>
