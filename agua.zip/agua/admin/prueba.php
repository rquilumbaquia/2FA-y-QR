<?php 
$contenido = "Eüste es el conßtenidöo aÅl ¥cual eliüminaré carÅactere£s raro¥s";
echo $contenido."<br>";
echo PDO::quote($contenido); 
$caracteresNoPermitidos = array("£","¥","è","ù","ì","ò","Ç","Ø","ø","Å","å","Æ","æ","ß","¤","¡","ä","ö","ü","à","Ü","Ö","Ä");
$contenido = str_replace($caracteresNoPermitidos,'',$contenido);

echo $contenido;

?>