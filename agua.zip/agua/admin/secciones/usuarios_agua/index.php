
<?php 
include("../../bd.php");
include("../../templates/header.php"); 
if((isset($_GET['eliminar']))&&($_GET['eliminar']=='si')&&($_SESSION['tocte']==$_GET['csrf_token']))
{   $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";       
    $sentencia=$conexion->prepare("DELETE FROM usuarios WHERE id_usuario=:txtusuario; ");
    $sentencia->bindParam(':txtusuario',$id_usuario);
    $sentencia->execute();
    $mensaje="El Usuario de Agua se ha eliminado";
}
$sentencia=$conexion->prepare("SELECT * FROM usuarios where estado='activo' or estado='nuevo' ");
$sentencia->execute();
$lista_usuarios=$sentencia->fetchAll(PDO::FETCH_ASSOC);
?>
Lista de Usuarios
<div class="card">
   <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')||($_SESSION['cargo']=='secretario')){ ?>    
    <div class="card-header">
    <a  name=""
        id=""
        class="btn btn-primary"
        href="crear.php"
        role="button"
        >Nuevo Usuario</a>        
   </div>
   <?php } ?>   
    <div class="card-body">
    <div
        class="table-responsive-sm"    >
        <table 
            class="table"        >
            <thead>
                <tr>
                    <th scope="col">Orden</th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Cedula</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Tercera Edad</th>
                    <th scope="col">Año Ingreso</th>
                    <th scope="col">Opciones</th>
                    <th scope="col">Aportes</th>                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_usuarios as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['orden_lista']; ?></td>
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['telefono']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td><?php echo $registros['estado']; ?></td>
                    <td><?php echo $registros['tercera_edad']; ?></td>
                    <td><?php echo $registros['anio_ingreso']; ?></td>
                    <td>
                    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')||($_SESSION['cargo']=='secretario')){ ?> 
                    <a name="" id="" href="editar.php?id_usuario=<?php echo $registros['id_usuario'];  ?>&csrf_token=<?php echo $_SESSION['tocte']  ?>" >Editar</a>                        |
                    <a name="" id="" href="index.php?id_usuario=<?php echo $registros['id_usuario'];  ?>&eliminar=si&csrf_token=<?php echo $_SESSION['tocte']  ?>" >Eliminar</a>  
                     <?php } ?>
                   </td>
                    <td>
                    <a name="" id="" href="pagos.php?id_usuario=<?php echo $registros['id_usuario'];  ?>&csrf_token=<?php echo $_SESSION['tocte']  ?>" >Pagos</a>|
                    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?>   
                    <a
                    name=""
                    id=""                   
                    href="../llaves/index.php?id_usuario=<?php echo $registros['id_usuario'];  ?>&csrf_token=<?php echo $_SESSION['tocte']  ?>" >Llaves</a>                        
                        |Rayas
                    <?php } ?>                    
                    </td>
                </tr>
            <?php         } ?>  
               
            </tbody>
        </table>
    </div>     

    </div>   
</div>
<?php include("../../templates/footer.php"); ?>
<script>
$(document).ready( function () {
   
    //$('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"https://cdn.datatables.net/plug-ins/1.13.7/i18n/es-MX.json"},order: [[2,'asc']]});
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[2,'asc']]});
} );

  </script>

 