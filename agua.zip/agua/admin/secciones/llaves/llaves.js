var plano;

function cambiar_valor(campo,id_llave,valor,accion)
{
    // Función que envía y recibe respuesta con AJAX
    $.ajax({
     type: 'POST',  // Envío con método POST
     url: 'cambiar_valor.php',  // Fichero destino (el PHP que trata los datos)
     data: { id_llave: id_llave,campo:campo,valor:valor,accion:accion } // Datos que se envían
     }).done(function( msg ) { // Función que se ejecuta si todo ha ido bien
      $("#"+campo+id_llave).html(msg);  // Escribimos en el div consola el mensaje devuelto
     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
     // Mostramos en consola el mensaje con el error que se ha producido
      // Mostramos en consola el mensaje con el error que se ha producido
      $("#"+campo+id_llave).html("The following error occured: "+ textStatus +" "+ errorThrown); 

    // $("#txt"+id_aporte).val("The following error occured: "+ textStatus +" "+ errorThrown); 
    });


}






