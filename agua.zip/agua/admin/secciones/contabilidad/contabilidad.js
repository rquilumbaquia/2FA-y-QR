function fecha(valor,dia,mes)
{


var dx=new Date(valor);
var fecha=new Array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
//Ensure correct for language. English is "January 1, 2004"
var DAY = fecha[mes] + " " + dia + ", " + dx.getFullYear();
return DAY;

}

function listar(fecha)
{

    
    // Función que envía y recibe respuesta con AJAX
    $.ajax({
     type: 'POST',  // Envío con método POST
     url: 'detalle_cierre.php',  // Fichero destino (el PHP que trata los datos)
     data: { fecha: fecha } // Datos que se envían
     }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
      $("#divdetalle").html(msg);  // Escribimos en el div consola el mensaje devuelto
     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
     // Mostramos en consola el mensaje con el error que se ha producido
     $("#divdetalle").html("The following error occured: "+ textStatus +" "+ errorThrown); 
    });


}
function sumar_cierre_caja()
{
    
    var sum=0;
    $('.subtotal').each(function() {  
     sum += parseFloat($(this).text().replace(/,/g, ''), 10);  
    }); 
    $('#resultado_total').val(sum.toFixed(2));

}