<?php

include("../../bd.php");
include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php"); 
if (!isset($_SESSION)) {
    correr_session();
  }

if ((isset($_POST['poner']))&&($_POST['poner']=="si"))
 {
   
    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
    $f_registro=date("Y-m-d");
    $cumplido=1;
    $id_actividad=(isset($_POST['id_actividad']))?$_POST['id_actividad']:"";
    $id_acceso=$_SESSION['id_acceso'];
    
    $sentencia=$conexion->prepare("UPDATE rayas_usuario SET fecha_registro=:txtfregistro,cumplido=:txtcumplido,id_acceso=:txtidacceso WHERE id_raya=:txtidraya ");
    $sentencia->bindParam(':txtfregistro',$f_registro);
    $sentencia->bindParam(':txtcumplido',$cumplido);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidraya', $id_raya);
    $sentencia->execute();
}

if ((isset($_POST['poner']))&&($_POST['poner']=="no"))
 {
    
    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
    $f_registro=date("Y-m-d");
    $cumplido="";
    
    $id_actividad=(isset($_POST['id_actividad']))?$_POST['id_actividad']:"";
    $id_acceso=$_SESSION['id_acceso'];
    $sentencia=$conexion->prepare("UPDATE rayas_usuario SET fecha_registro=:txtfregistro,cumplido=:txtcumplido,id_acceso=:txtidacceso WHERE id_raya=:txtidraya ");
    $sentencia->bindParam(':txtfregistro',$f_registro);
    $sentencia->bindParam(':txtcumplido',$cumplido);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidraya', $id_raya);
    $sentencia->execute();

}

                    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM rayas_usuario where id_raya=:txtidraya ");
                    $sentencia_aplicacion->bindParam(':txtidraya',$id_raya);
                    
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetch(PDO::FETCH_LAZY);
                    
              if(($sentencia_aplicacion->rowCount())>0){      
                    if($resultado['cumplido']==1)
                    {
                     
                        ?>
                          <di id="raya<?php echo $POST['id_usuario']; ?>-<?php echo $_POST['id_actividad']; ?>" >
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    checked
                                    onclick="poner_raya('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_actividad']?>','no')"
                                    autocomplete="off"
                                />
                                <?php echo $resultado['cantidad_raya'];  ?>
                            </div>
                        <?php

                    }
                    
                    if($resultado['cumplido']!=1)

                    {

                        ?>
                        <di id="raya<?php echo $POST['id_usuario']; ?>-<?php echo $_POST['id_actividad']; ?>" >
                        <input
                            type="checkbox"
                            class="form-check-input"
                            name=""
                            onclick="poner_raya('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_actividad']?>','si')"
                            autocomplete="off"
                        />

                        <input id="txt<?php echo $POST['id_usuario']; ?>-<?php echo $_POST['id_actividad']; ?>" 
                        type="text" value="<?php echo $resultado['cantidad_raya']  ?>" 
                        size="2" 
                        onchange="cantidadraya('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_actividad']?>',this.value)" 
                        placeholder="rayas" 
                        data-bs-toggle="tooltip"
                        data-bs-placement="top" title="Ingrese Numero de rayas" 
                        
                        />
                        </div>
                <?php
                    }

                }        

    ?>


