<?php    
/*
 * PHP QR Code encoder
 *
 * Exemplatory usage
 *
 * PHP QR Code is distributed under LGPL 3
 * Copyright (C) 2010 Dominik Dzienia <deltalab at poczta dot fm>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

 //Funcion de cifrado
 

class Crypto {
    private $key;

    public function __construct(string $key) {
        $this->key = $key;
    }

    public function encrypt(string $value): string {
        // Generar un vector de inicialización aleatorio
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));

        // Encriptar el valor utilizando OpenSSL
        $encrypted = openssl_encrypt($value, 'aes-256-cbc', $this->key, 0, $iv);

        // Combinar el valor encriptado y el vector de inicialización en una cadena codificada en base64
        return base64_encode($encrypted . '::' . $iv);
    }

    public function decrypt(string $value): string {
        // Decodificar la cadena codificada en base64 y separar el valor encriptado del vector de inicialización
        $parts = explode('::', base64_decode($value), 2);

        // Desencriptar el valor utilizando OpenSSL
        $decrypted = openssl_decrypt($parts[0], 'aes-256-cbc', $this->key, 0, $parts[1]);

        // Devolver el valor desencriptado
        return $decrypted;
    }
}

// Crear una nueva instancia de Crypto
$crypto = new Crypto("esta-es-la-clave-secreta");

 //fin de funcion de cifrado
           
    if (isset($_REQUEST['login']))
    {
    $_REQUEST['data']=$_REQUEST['login'].":".$_REQUEST['password'];
    $encrypted_value = $crypto->encrypt($_REQUEST['data']);
    $_REQUEST['data']=$encrypted_value;
   }
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    $url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/libs/generadorqr/temp/";        
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';      
    include "qrlib.php";
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);   
    
    $filename = $PNG_TEMP_DIR.'test.png';    
    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'L';
    if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
        $errorCorrectionLevel = $_REQUEST['level'];   

    $matrixPointSize = 4;
    if (isset($_REQUEST['size']))
        $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);
    if (isset($_REQUEST['data'])) {     
        //Muy  importane!
        if ((trim($_REQUEST['data']) == ''))
            die('data cannot be empty! <a href="?">back</a>');            
        // datos de usuario
                
        $filename = $PNG_TEMP_DIR.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
        QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
    } else {   
    
        //datos por defecto
        echo 'You can provide data in GET parameter: <a href="?data=like_that">like that</a><hr/>';    
        QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
        
    }              
    //desplegar archivo generado
    echo '<img src="'. $url_base.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png'.'" /><hr/>';      
    //config form
    echo '
    Dato:&nbsp;<input name="data" id="data" type="hidden"  value="'.(isset($_REQUEST['data'])?htmlspecialchars($_REQUEST['data']):'PHP QR Code :)').'" />&nbsp;
        ECC:&nbsp;<select name="level" id="level">
            <option value="L"'.(($errorCorrectionLevel=='L')?' selected':'').'>L - Muy pequeño</option>
            <option value="M"'.(($errorCorrectionLevel=='M')?' selected':'').'>M</option>
            <option value="Q"'.(($errorCorrectionLevel=='Q')?' selected':'').'>Q</option>
            <option value="H"'.(($errorCorrectionLevel=='H')?' selected':'').'>H - Mejor</option>
        </select>&nbsp;
        Size:&nbsp;<select name="size" id="size">';
        
    for($i=1;$i<=10;$i++)
        echo '<option value="'.$i.'"'.(($matrixPointSize==$i)?' selected':'').'>'.$i.'</option>';
        
    echo '</select>&nbsp;
        <input type="button" value="Generar" onclick="generarUsuario()"/>
        <input type="hidden"  name="imagen_qr" id="imagen_qr" value="'.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png'.'" onclick="generarUsuario()"/>
         <hr/>';
        
    // benchmark
    QRtools::timeBenchmark();    

    