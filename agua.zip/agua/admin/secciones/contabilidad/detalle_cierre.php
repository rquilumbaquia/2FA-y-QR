<?php 

include("../../bd.php");
function fecha_txt($valor,$dia,$mes)
{
 $dx= date($valor);
$fecha= array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
//Ensure correct for language. English is "January 1, 2004"
$DAY = $fecha[$mes] . " " . $dia . ", " . date("Y", $dx);
return $DAY;
}

$fecha_pago=$_POST['fecha'];
$sentencia_pagos=$conexion->prepare("SELECT t1.id_usuario as id_usuario ,t1.apellidos as apellidos,t1.nombres as nombres,t1.f_pago as f_pago,sum(t1.total_pagado) as total_pagado FROM (SELECT usuarios.id_usuario,usuarios.nombres,usuarios.apellidos,aporte_llave.f_pago,sum(aporte_llave.valor_pago)as total_pagado from aporte_llave,llaves,usuarios where aporte_llave.f_pago=:txtfpago and aporte_llave.id_llave=llaves.id_llave and llaves.id_usuario=usuarios.id_usuario group by usuarios.id_usuario union all SELECT usuarios.id_usuario,usuarios.nombres,usuarios.apellidos,aporte_por_usuario.f_pago,sum(aporte_por_usuario.valor_pago)as total_pagado FROM usuarios,aporte_por_usuario WHERE aporte_por_usuario.f_pago=:txtfpago and usuarios.id_usuario=aporte_por_usuario.id_usuario GROUP BY usuarios.id_usuario) as t1 GROUP BY t1.id_usuario" );
$sentencia_pagos->bindParam(':txtfpago',$fecha_pago);
$sentencia_pagos->bindParam(':txtfpago',$fecha_pago);
$sentencia_pagos->execute();
$lista=$sentencia_pagos->fetchAll(PDO::FETCH_ASSOC);
$fechaEntera = strtotime($_POST['fecha']);
//select t1.deposito as deposito,sum(t1.valor) as valor from(SELECT deposito as deposito,sum(valor_pago)as valor FROM aporte_llave WHERE f_pago=%s and observacion='pagado' GROUP BY aporte_llave.deposito asc  union all  SELECT deposito as deposito,sum(valor_pago)as valor FROM aporte_por_usuario WHERE f_pago=%s and observacion='pagado' GROUP BY aporte_por_usuario.deposito asc ) as t1 GROUP BY t1.deposito asc

$sentencia_efectivo_deposito=$conexion->prepare("select t1.deposito as deposito,sum(t1.valor) as valor from(SELECT deposito as deposito,sum(valor_pago)as valor FROM aporte_llave WHERE f_pago=:txtfpago and observacion='pagado' GROUP BY aporte_llave.deposito asc  union all  SELECT deposito as deposito,sum(valor_pago)as valor FROM aporte_por_usuario WHERE f_pago=:txtfpago and observacion='pagado' GROUP BY aporte_por_usuario.deposito asc ) as t1 GROUP BY t1.deposito asc" );
$sentencia_efectivo_deposito->bindParam(':txtfpago',$fecha_pago);
$sentencia_efectivo_deposito->bindParam(':txtfpago',$fecha_pago);
$sentencia_efectivo_deposito->execute();
$lista_efectivo_deposito=$sentencia_efectivo_deposito->fetchAll(PDO::FETCH_ASSOC);



$mes = date("m", $fechaEntera);
$mes=abs($mes);

$dia = date("d", $fechaEntera);

echo "Lista de pagos en ".fecha_txt($fechaEntera,$dia,$mes);

?>


<table
            class="table" 
        >
            <thead>
                <tr class="table-primary">
                    <th scope="col">Numero</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Valor</th>
                    
                </tr>
            </thead>
            <tbody><?php $i=0;$total=0; ?>
            <?php foreach($lista as $registros){ ?>
                <tr >
                    <td scope="row"><?php echo $i=$i+1; ?></li></td>
                    <td scope="row"> <?php echo strtoupper($registros['apellidos'])."  ".strtoupper($registros['nombres']); ?> </td>
                    <td><?php echo $registros['total_pagado']; $total=$total+$registros['total_pagado'] ?></td>
                                      
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>

        <div class="card" ><?php echo "El total es :". number_format($total, 2, '.', '') ?> Usd</div>

        <table
            class="table" 
        >
            <thead>
                <tr class="table-primary">
                    <th scope="col">Numero</th>
                    <th scope="col">Deposito</th>
                    <th scope="col">Valor</th>
                    
                </tr>
            </thead>
            <tbody><?php $i=0;$total_efectivo=0; ?>
            <?php foreach($lista_efectivo_deposito as $registros_efectivo){ ?>
                <tr  >
                    <td scope="row"><?php echo $i=$i+1; ?></li></td>
                    <td scope="row"> <?php echo $registros_efectivo['deposito']; ?> </td>
                    <td><?php echo $registros_efectivo['valor']; $total_efectivo=$total_efectivo+$registros_efectivo['valor'] ?></td>
                                      
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
        
        <div class="card" ><?php echo "El total es :". number_format($total_efectivo, 2, '.', '') ?> Usd</div>

