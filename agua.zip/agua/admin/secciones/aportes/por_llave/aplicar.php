<?php 
include("../../../templates/header.php"); 
include("../../../bd.php");
if(($_GET))
{
    $id_obligacion_llave=(isset($_GET['id_obligacion_llave']))?$_GET['id_obligacion_llave']:"";
    $sentencia=$conexion->prepare("SELECT * FROM obligacion_por_llave WHERE id_obligacion_llave=:txtidobligacionllave");
    $sentencia->bindParam(':txtidobligacionllave',$id_obligacion_llave);
    $sentencia->execute();
    $aportes_llave=$sentencia->fetchAll(PDO::FETCH_ASSOC);
}
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios where estado='activo' or estado='nuevo' order by apellidos ASC ");
$sentencia_usuario->execute();
$lista_usuarios=$sentencia_usuario->fetchAll(PDO::FETCH_ASSOC);
?>
<script src="aplicaciones_llaves.js" type="text/javascript"></script>
<div class="card">
    <div class="card-header">
        <div
            class="alert alert-primary"
            role="alert"
        >
            <strong>Aplicacion de: | <?php  foreach($aportes_llave as $registros_obligacion){  echo ucwords($registros_obligacion['nombre_obligacion'])." | Valor: ";echo $registros_obligacion['valor']; echo "|  Fecha Creacion: ".$registros_obligacion['fecha_creacion']."| Fecha Vencimiento: ".$registros_obligacion['fecha_vencimiento']; $valor=$registros_obligacion['valor']; $opcion=$registros_obligacion['opcion'];  }  ?>| Por LLave</strong> 
        </div>
    </div>
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table 
            class="table"
        >
            <thead>
                <tr>
                    
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">Cedula</th>
                    <th scope="col">Estado</th>
                    <th scope="col">
                    <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_obligacion_llave=<?php echo $_GET['id_obligacion_llave'] ?>&valor=<?php echo $valor ?>&poner=poner"
        >Todos</a>
        <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_obligacion_llave=<?php echo $_GET['id_obligacion_llave'] ?>&valor=<?php echo $valor ?>&poner=quitar"
        >Quitar</a>
                    </th>
                    
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_usuarios as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td><?php echo $registros['estado']; ?></td>
                    <td>
                    <?php 
                    $sentencia_llaves=$conexion->prepare("SELECT * FROM llaves where id_usuario=:txtidusuario and suspendido='no' ");
                    $sentencia_llaves->bindParam(':txtidusuario',$registros['id_usuario']);
                    $sentencia_llaves->execute();
                    $lista_llaves=$sentencia_llaves->fetchAll(PDO::FETCH_ASSOC);
                   
                  
                    foreach($lista_llaves as $registros_llaves)
                    {
                    
                    
                                      
                     echo $registros_llaves['sector'];
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM aporte_llave where id_llave=:txtidllave and id_obligacion_llave=:txtidobligacionllave ");
                    $sentencia_aplicacion->bindParam(':txtidllave',$registros_llaves['id_llave']);
                    $sentencia_aplicacion->bindParam(':txtidobligacionllave',$_GET['id_obligacion_llave']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);
                    foreach($resultado as $dato)
                    {
                        $pagar=$dato['pagar'];
                    }
                    if(($sentencia_aplicacion->rowCount())>0)
                    {
                        ?>

                            <div id="check<?php echo $registros_llaves['id_llave']."_".$registros['id_usuario']; ?>">
                            
                             <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    checked
                                    onclick="poner('<?php echo $registros_llaves['id_llave'];?>','<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_llave']?>','no','<?php echo $valor  ?>','<?php echo $opcion  ?>','<?php echo $registros['tercera_edad']; ?>')"
                                    
                                />

                                <?php if($opcion=='ingresado'){ ?>
                                
                                <input type="text" size="4" value="<?php echo $pagar ?>" onchange="poner('<?php echo $registros_llaves['id_llave'];?>','<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_llave']?>','cambiar',thi.value,'<?php echo $opcion  ?>','<?php echo $registros['tercera_edad']; ?>')"  />

                                 <?php } ?>

                            </div>
                        <?php
                    }else
                    {
                           ?>
                                <div id="check<?php echo $registros_llaves['id_llave']."_".$registros['id_usuario']; ?>">
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    onclick="poner('<?php echo $registros_llaves['id_llave'];?>','<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_llave']?>','si','<?php echo $valor  ?>','<?php echo $opcion  ?>','<?php echo $registros['tercera_edad']; ?>')"
                                 />
                        
                                </div>
                            <?php

                    }
                echo "<br>";
                
                    }                    
                    ?>
                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
    </div>
</div>
<?php include("../../../templates/footer.php"); ?>
<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[1,'asc']]});
} );

  </script>