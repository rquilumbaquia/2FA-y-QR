<?php include("../../bd.php"); ?>
<?php 
if($_POST){

    $id_aporte=$_POST['id_aporte'];
    $valor=$_POST['lectura_actual'];
    
    $anterior=$_POST['id_aporte_anterior'];
    $llave=$_POST['id_llave'];
    $sentencia_revisar=$conexion->prepare("SELECT * FROM aporte_llave where  id_llave=:txtidllave AND id_obligacion_llave=:txtidobligacion " );
    $sentencia_revisar->bindParam(':txtidllave',$llave);
    $sentencia_revisar->bindParam(':txtidobligacion',$anterior);
    $sentencia_revisar->execute();
    $lista=$sentencia_revisar->fetch(PDO::FETCH_LAZY);
    if(($sentencia_revisar->rowCount())>0)
    {

        $lectura_anterior=$lista['lectura_actual'];
    }else{$lectura_anterior=0;}

    if($lectura_anterior>0)
    {
    }else{$lectura_anterior=0;}
    
    $id_aporte=$_POST['id_aporte'];
    $sentencia_poner_anterior=$conexion->prepare("UPDATE aporte_llave SET lectura_actual=:txtvalor, lectura_anterior=:txtlectura where id_aporte=:txtaporte " );
    $sentencia_poner_anterior->bindParam(':txtvalor', $valor);
    $sentencia_poner_anterior->bindParam(':txtlectura', $lectura_anterior);
    $sentencia_poner_anterior->bindParam(':txtaporte',$id_aporte);
    $sentencia_poner_anterior->execute();
    
    $sentencia_poner_anterior=$conexion->prepare("UPDATE aporte_llave SET  medidor=lectura_actual-lectura_anterior where id_aporte=:txtaporte " );
    $sentencia_poner_anterior->bindParam(':txtaporte',$id_aporte);
    $sentencia_poner_anterior->execute();
    
    $sentencia_revisar=$conexion->prepare("SELECT * FROM aporte_llave where id_aporte=:txtidaporte " );
    $sentencia_revisar->bindParam(':txtidaporte',$id_aporte);
    $sentencia_revisar->execute();
    $lista=$sentencia_revisar->fetch(PDO::FETCH_LAZY);

?>
 <input type="text" name="txt<?php echo $lista['id_aporte'] ?>" id="txt<?php echo $lista['id_aporte'] ?>" value="<?php echo $lista['lectura_actual'] ?>" onchange="poner_lectura('<?php echo $lista['id_aporte'] ?>',this,'<?php echo $_POST['id_aporte_anterior'] ?>');" size="4" class="text-primary" />
<?php
}

?>



