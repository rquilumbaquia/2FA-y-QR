<?php 
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
$url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/";
//header("Content-Security-Policy: default-src 'self' *".$url_base."  ");
header("Content-Security-Policy: default-src 'self'");
include("../../bd.php");
include("../../sesion.php");
if (!isset($_SESSION)) 
{
    correr_session();
}
if(!isset($_SESSION['usuario']))
 {
 $MM_redirectLoginSuccess =$url_base."login.php";
 header("Location: " . $MM_redirectLoginSuccess );
 }
if(isset($_POST)&&($_POST['csrf_token']==$_SESSION['tocte'])){
     $id_acceso=(isset($_POST['id_acceso']))?$_POST['id_acceso']:"";
     $sentencia_revision=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
     $sentencia_revision->bindParam(':txtidacceso',$id_acceso);
     $sentencia_revision->execute();
     $lista_usuario=$sentencia_revision->fetch(PDO::FETCH_LAZY);    
     $id_acceso=(isset($_POST['id_acceso']))?$_POST['id_acceso']:"";
     $nombre=(isset($_POST['nombre']))?$_POST['nombre']:"";
     $login=(isset($_POST['login']))?$_POST['login']:"";
     $cargo=(isset($_POST['cargo']))?$_POST['cargo']:"";
     $activo=(isset($_POST['activo']))?$_POST['activo']:"";
     $anio_lectivo=(isset($_POST['anio_lectivo']))?$_POST['anio_lectivo']:"";
     $f_inicio=(isset($_POST['f_inicio']))?$_POST['f_inicio']:"";
     $f_final=(isset($_POST['f_final']))?$_POST['f_final']:"";
     $correo=(isset($_POST['correo']))?$_POST['correo']:"";
     $aplicar_2fa=(isset($_POST['aplicar_2fa']))?$_POST['aplicar_2fa']:"";
     $imagen_qr=(isset($_POST['imagen_qr']))?$_POST['imagen_qr']:"";
     $intentos="";
     /* Buscando un coste apropiado para generacion del Hash */
     if($_POST['password-input']!=""){
     $timeTarget = 0.05; // Tentativo para 50 milisegundos 
     $coste = 8; //Coste tentativo
     do {
        $coste++;
        $inicio = microtime(true);
        password_hash("test", PASSWORD_BCRYPT, ["cost" => $coste]);
        $fin = microtime(true);
      } while (($fin - $inicio) < $timeTarget);    
      echo "Coste apropiado encontrado: " . $coste . "\n";    
      $opciones = [
        'cost' => $coste,
      ];     
      /* realizando el Hash de la contraseña*/
     $password=password_hash($_POST['password-input'], PASSWORD_BCRYPT, $opciones);
     /*  $password=password_hash($_POST['password'], PASSWORD_DEFAULT);*/     
     $sentencia=$conexion->prepare("UPDATE usuario_acceso SET nombre=:txtnombre,login=:txtlogin,password=:txtpassword,cargo=:txtcargo,activo=:txtactivo,anio_lectivo=:txtaniolectivo,f_inicio=:txtfinicio,f_final=:txtffinal,correo=:txtcorreo,aplicar_2fa=:txt2fa,imagen_qr=:txtimagenqr ,intentos=:txtintentos WHERE id_acceso=:idacceso");
     $sentencia->bindParam(':txtnombre',$nombre);
     $sentencia->bindParam(':txtlogin',$login);
     $sentencia->bindParam(':txtpassword',$password);
     $sentencia->bindParam(':txtcargo',$cargo);
     $sentencia->bindParam(':txtactivo',$activo);
     $sentencia->bindParam(':txtaniolectivo',$anio_lectivo);
     $sentencia->bindParam(':txtfinicio',$f_inicio);
     $sentencia->bindParam(':txtffinal',$f_final);
     $sentencia->bindParam(':txtcorreo',$correo);
     $sentencia->bindParam(':txt2fa',$aplicar_2fa);
     $sentencia->bindParam(':txtimagenqr',$imagen_qr);
     $sentencia->bindParam(':txtintentos',$intentos);
     $sentencia->bindParam(':idacceso',$id_acceso);
     $sentencia->execute();      
    }else{
      $sentencia=$conexion->prepare("UPDATE usuario_acceso SET nombre=:txtnombre,login=:txtlogin,cargo=:txtcargo,activo=:txtactivo,anio_lectivo=:txtaniolectivo,f_inicio=:txtfinicio,f_final=:txtffinal,correo=:txtcorreo,aplicar_2fa=:txt2fa,imagen_qr=:txtimagenqr ,intentos=:txtintentos WHERE id_acceso=:idacceso");
      $sentencia->bindParam(':txtnombre',$nombre);
      $sentencia->bindParam(':txtlogin',$login);
      $sentencia->bindParam(':txtcargo',$cargo);
      $sentencia->bindParam(':txtactivo',$activo);
      $sentencia->bindParam(':txtaniolectivo',$anio_lectivo);
      $sentencia->bindParam(':txtfinicio',$f_inicio);
      $sentencia->bindParam(':txtffinal',$f_final);
      $sentencia->bindParam(':txtcorreo',$correo);
      $sentencia->bindParam(':txt2fa',$aplicar_2fa);
      $sentencia->bindParam(':txtimagenqr',$imagen_qr);
      $sentencia->bindParam(':txtintentos',$intentos);
      $sentencia->bindParam(':idacceso',$id_acceso);
      $sentencia->execute();
    }       
    If ($imagen_qr!=$lista_usuario['imagen_qr']) {      
      unlink("../../libs/generadorqr/temp/".$lista_usuario['imagen_qr']);
      echo "Archivo eliminado correctamente";            
    } else {echo "No se elimina ";}    
    $MM_redirectLoginSuccess ="index.php";
    header("Location: " . $MM_redirectLoginSuccess );
    
}

?>