<?php 
include("../../bd.php");

if ((isset($_GET['id_actividad']))&&($_GET['poner']=="poner"))
 {
 
    $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, usuarios.nombres, usuarios.apellidos, usuarios.estado,usuarios.tercera_edad  FROM  usuarios WHERE (usuarios.estado='activo' or usuarios.estado='nuevo' )   AND usuarios.id_usuario NOT IN(select rayas_usuario.id_usuario from rayas_usuario where rayas_usuario.id_actividad=:txtidactividad and rayas_usuario.id_usuario=usuarios.id_usuario ) ");
    $sentencia->bindParam(':txtidactividad',$_GET['id_actividad']);
    $sentencia->execute();
    $lista_usuarios=$sentencia->fetchAll(PDO::FETCH_ASSOC);

    $sentencia_cantidad=$conexion->prepare("SELECT * FROM actividades where  id_actividad=:txtidactividad ");
    $sentencia_cantidad->bindParam(':txtidactividad',$_GET['id_actividad']);
    $sentencia_cantidad->execute();                   
    $resultado=$sentencia_cantidad->fetch(PDO::FETCH_LAZY);
    $cantidad=$resultado['cantidad_rayas'];
 
    foreach($lista_usuarios as $registros)
    {


          
    $id_raya=$registros['id_usuario']."-".$_GET['id_actividad'];   
    $id_usuario=$registros['id_usuario'];
  
    $fecha_registro="";

    $id_acceso="";
    $id_actividad=$_GET['id_actividad'];
    $cumplido="";
    

    $sentencia=$conexion->prepare("INSERT INTO rayas_usuario (id_raya, id_usuario, id_actividad, fecha_registro, id_acceso, cumplido, cantidad_raya )values(:txtidraya, :txtidusuario, :txtidactividad, :txtfecharegistro, :txtidacceso, :txtcumplido, :txtcantidad); ");
    $sentencia->bindParam(':txtidraya',$id_raya);
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':txtidactividad',$id_actividad);
    $sentencia->bindParam(':txtfecharegistro', $fecha_registro);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtcumplido',$cumplido);
    $sentencia->bindParam(':txtcantidad',$cantidad);
    $sentencia->execute();


    }

}

if ((isset($_GET['id_actividad']))&&($_GET['poner']=="quitar"))
 {
 $id_actividad=$_GET['id_actividad'];
  $sentencia=$conexion->prepare("DELETE FROM rayas_usuario WHERE id_actividad=:txtidactividad  ");
  $sentencia->bindParam(':txtidactividad',$id_actividad);
  $sentencia->execute();

}

$MM_redirectLoginSuccess ="aplicar.php?id_actividad=".$_GET['id_actividad'];
header("Location: " . $MM_redirectLoginSuccess );


?>