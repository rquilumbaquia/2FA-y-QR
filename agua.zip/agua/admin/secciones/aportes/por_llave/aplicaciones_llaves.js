var plano;

function creaObjetoAjax () { //Mayoría de navegadores
    var obj;
    if (window.XMLHttpRequest) {
       obj=new XMLHttpRequest();
       }
    else { //para IE 5 y IE 6
       obj=new ActiveXObject(Microsoft.XMLHTTP);
       }
    return obj;
    }

function poner(id_llave,id_usuario,id_obligacion_llave,poner,valor,opcion,tercera_edad)
{

   plano="check"+id_llave+"_"+id_usuario;

     //datos para el envio por POST:
   misdatos="id_usuario="+id_usuario+"&id_obligacion_llave="+id_obligacion_llave+"&id_llave="+id_llave+"&poner="+poner+"&valor="+valor+"&opcion="+opcion+"&tercera_edad="+tercera_edad;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","casilla.php",true);
   //Enviar cabeceras para que acepte POST:

   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_poner;
   objetoAjax.send(misdatos);

 } 
function recogeDatos_poner() 
{

if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        document.getElementById(plano).innerHTML=miTexto;
    }
}