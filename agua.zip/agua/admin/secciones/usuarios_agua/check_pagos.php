<?php  
include("../../bd.php");
include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php");
if (!isset($_SESSION)) {
    correr_session();
  }
date_default_timezone_set("America/Bogota");

if(isset($_POST['accion'])&&($_POST['accion']=="poner")&&($_POST['tarifa_cuota']=="tarifa"))

{
    
    $id_acceso=$_SESSION['id_acceso'];
    $f_pago=date( 'Y-m-d');
    $pagado="Pagado";
    $deposito=$_POST['deposito'];
    $sentencia=$conexion->prepare("UPDATE aporte_llave SET f_pago=:txtfpago, valor_pago=:txtvalorpago, id_acceso=:txtidacceso, observacion=:txtobservacion,  deposito=:txtdeposito  WHERE id_aporte=:txtidaporte");
    $sentencia->bindParam(':txtfpago',$f_pago);
    $sentencia->bindParam(':txtvalorpago',$_POST['pagar']);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtobservacion',$pagado);
    $sentencia->bindParam(':txtdeposito',$deposito);
    $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
    $sentencia->execute();

}

if(isset($_POST['accion'])&&($_POST['accion']=="quitar")&&($_POST['tarifa_cuota']=="tarifa"))

{
    $f_pago="";
    $deposito="";
    $pagado="Solo asignado";
    $id_acceso=$_SESSION['id_acceso'];
    $valor=0;
    $sentencia=$conexion->prepare("UPDATE aporte_llave SET f_pago=:txtfpago, valor_pago=:txtvalorpago, id_acceso=:txtidacceso, observacion=:txtobservacion,  deposito=:txtdeposito  WHERE id_aporte=:txtidaporte");
    $sentencia->bindParam(':txtfpago', $f_pago);
    $sentencia->bindParam(':txtvalorpago', $valor);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtobservacion', $pagado);
    $sentencia->bindParam(':txtdeposito',$deposito);
    $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
    $sentencia->execute();

}

if(isset($_POST['accion'])&&($_POST['accion']=="poner")&&($_POST['tarifa_cuota']=="cuota"))

{

    $id_acceso=$_SESSION['id_acceso'];
    $f_pago=date( 'Y-m-d');
    $pagado="Pagado";
    $deposito=$_POST['deposito'];
    $sentencia=$conexion->prepare("UPDATE aporte_por_usuario SET f_pago=:txtfpago, valor_pago=:txtvalorpago, id_acceso=:txtidacceso, observacion=:txtobservacion, deposito=:txtdeposito WHERE id_aporte=:txtidaporte");
    $sentencia->bindParam(':txtfpago',$f_pago);
    $sentencia->bindParam(':txtvalorpago',$_POST['pagar']);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtobservacion',$pagado);
    $sentencia->bindParam(':txtdeposito',$deposito);
    $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
    $sentencia->execute();


}
if(isset($_POST['accion'])&&($_POST['accion']=="quitar")&&($_POST['tarifa_cuota']=="cuota"))

{
    $f_pago="";
    $valor=0;
    $observacion="Solo asignado";
    $deposito="";
    $id_acceso=$_SESSION['id_acceso'];
    $sentencia=$conexion->prepare("UPDATE aporte_por_usuario SET f_pago=:txtfpago, valor_pago=:txtvalorpago, id_acceso=:txtidacceso, observacion=:txtobservacion, deposito=:txtdeposito WHERE id_aporte=:txtidaporte");
    $sentencia->bindParam(':txtfpago',$f_pago);
    $sentencia->bindParam(':txtvalorpago',$valor);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtobservacion',$observacion);
    $sentencia->bindParam(':txtdeposito',$deposito);
    $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
    $sentencia->execute();
}

if($_POST['tarifa_cuota']=="tarifa")
{
    if (isset($_POST['id_aporte'])) {
        $sentencia=$conexion->prepare("SELECT * FROM aporte_llave WHERE id_aporte = :txtidaporte");
        $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
        $sentencia->execute();
        $lista_tarifa=$sentencia->fetch(PDO::FETCH_LAZY);
        if($lista_tarifa['observacion']=="Solo asignado")
	
        {
?>

         <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" onchange="poner_pago_llave_cuota('<?php echo $_POST['id_aporte']; ?>','<?php echo $_POST['pagar']; ?>','tarifa','poner')" value="<?php echo $_POST['id_aporte']; ?>" >

<?php

        }   
        if($lista_tarifa['observacion']=="Pagado")
	
        { ?>

        
         <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" onchange="poner_pago_llave_cuota('<?php echo $_POST['id_aporte']; ?>','<?php echo $_POST['pagar']; ?>','tarifa','quitar')" value="<?php echo $_POST['id_aporte']; ?>" checked >
        

        <?php


        }   
    }

    

}

if($_POST['tarifa_cuota']=="cuota")
{
    if (isset($_POST['id_aporte'])) {
        $sentencia=$conexion->prepare("SELECT * FROM aporte_por_usuario WHERE id_aporte = :txtidaporte");
        $sentencia->bindParam(':txtidaporte',$_POST['id_aporte']);
        $sentencia->execute();
        $lista_cuota=$sentencia->fetch(PDO::FETCH_LAZY);
        if($lista_cuota['observacion']=="Solo asignado")
	
        {
?>

         <input type="checkbox" name="check_cuota[]" id="check_cuota[]" onchange="poner_pago_llave_cuota('<?php echo $_POST['id_aporte']; ?>','<?php echo $_POST['pagar']; ?>','cuota','poner')" value="<?php echo $_POST['id_aporte']; ?>" >

<?php

        }   
        if($lista_cuota['observacion']=="Pagado")
	
        { ?>

        
         <input type="checkbox" name="check_cuota[]" id="check_cuota[]" onchange="poner_pago_llave_cuota('<?php echo $_POST['id_aporte']; ?>','<?php echo $_POST['pagar']; ?>','cuota','quitar')" value="<?php echo $_POST['id_aporte']; ?>" checked >
       

        <?php


        }   
    }

    

}





?>