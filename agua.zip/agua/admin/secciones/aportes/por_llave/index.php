
<?php 

include("../../../bd.php");
include("../../../templates/header.php"); 
if(($_GET))
{
    $id_obligacion_llave=(isset($_GET['id_obligacion_llave']))?$_GET['id_obligacion_llave']:"";
       
    $sentencia=$conexion->prepare("DELETE FROM obligacion_por_llave WHERE id_obligacion_llave=:txtobligacionporllave; ");
    $sentencia->bindParam(':txtobligacionporllave',$id_obligacion_llave);
    $sentencia->execute();
    $mensaje="La obligación por llave  ha sido eliminado";

}

/*$fecha_inicio=$_SESSION['f_inicio_periodo'];
$fecha_final=$_SESSION['f_final_periodo'];*/

$sentencia=$conexion->prepare("SELECT * FROM obligacion_por_llave    order by fecha_creacion ASC ");
$sentencia->execute();
$lista_aportes_llave=$sentencia->fetchAll(PDO::FETCH_ASSOC);


?>

Lista para aplicacion de aportes
<div class="card">
    <div class="card-header">
    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?> 
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="crear.php"
        role="button"
        >Nuevo Aporte por Llave</a
    >
    <?php } ?>
    </div>
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table
            class="table" 
        >
            <thead>
                <tr>
                    <th scope="col">Id Obligacion llave</th>
                    <th scope="col">Nombre Obligación</th>
                    <th scope="col">Valor</th>
                    <th scope="col">Fecha de Creación</th>
                    <th scope="col">Fecha de vencimiento</th>
                    <th scope="col">Tercera Edad</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Tarifa Mes</th>
                    <th scope="col">Aplicaciones</th>
                   
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_aportes_llave as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['id_obligacion_llave']; ?></td>
                    <td><?php echo $registros['nombre_obligacion']; ?></td>
                    <td><?php echo $registros['valor']; ?></td>
                    <td><?php echo $registros['fecha_creacion']; ?></td>
                    <td><?php echo $registros['fecha_vencimiento']; ?></td>
                    <td><?php echo $registros['aplica_tercera']; ?></td>
                    <td><?php echo $registros['opcion']; ?></td>
                    <td><?php echo $registros['tarifa_mes']; ?></td>
                    <td>
                    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?> 
                    <a
                    name=""
                    id=""                   
                    href="editar.php?id_obligacion_llave=<?php echo $registros['id_obligacion_llave'];  ?>"                    
                    >Editar</a>|
                        
                    
                    <a
                    name=""
                    id=""                   
                    href="index.php?id_obligacion_llave=<?php echo $registros['id_obligacion_llave'];  ?>"                    
                    >Eliminar</a>
                    |<a
                    name=""
                    id=""                   
                    href="aplicar.php?id_obligacion_llave=<?php echo $registros['id_obligacion_llave'];  ?>"                    
                    >Aplicar</a>
                    <?php } ?>
                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
       

    </div>
   
</div>

<?php include("../../../templates/footer.php"); ?>
<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[3,'desc']]});
} );

  </script>
