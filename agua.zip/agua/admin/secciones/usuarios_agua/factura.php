<?php 
include("../../bd.php");
include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php");
if (!isset($_SESSION)) {
    correr_session();
  }
  $url_base="http://".$_SERVER['SERVER_NAME']."/agua/admin/";
if($_GET)
{

    $pagado="Pagado";
    $fecha_pago=$_GET['f_pago'];
    $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, llaves.id_llave, llaves.sector, aporte_llave.id_aporte, obligacion_por_llave.id_obligacion_llave, obligacion_por_llave.nombre_obligacion, aporte_llave.f_pago, aporte_llave.f_asignacion, aporte_llave.medidor, aporte_llave.observacion, obligacion_por_llave.fecha_creacion, obligacion_por_llave.fecha_vencimiento, obligacion_por_llave.valor, aporte_llave.pagar, aporte_llave.valor_pago, aporte_llave.deposito FROM usuarios, llaves, aporte_llave, obligacion_por_llave WHERE usuarios.id_usuario = :txtidusuario   AND llaves.id_usuario=usuarios.id_usuario AND llaves.id_llave=aporte_llave.id_llave  AND aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave AND aporte_llave.f_pago=:fechapago AND aporte_llave.observacion=:txtobservacion  ORDER BY obligacion_por_llave.fecha_creacion, llaves.id_llave ");
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':fechapago',$fecha_pago);
    $sentencia->bindParam(':txtobservacion',$pagado);
    $sentencia->execute();
    $lista_pagos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
    
    $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sentencia_couta=$conexion->prepare("SELECT aporte_por_usuario.id_aporte, aporte_por_usuario.id_usuario, aporte_por_usuario.f_pago, aporte_por_usuario.f_asignacion, aporte_por_usuario.pagar, aporte_por_usuario.valor_pago, aporte_por_usuario.deposito, aporte_por_usuario.id_acceso, aporte_por_usuario.id_obligacion_usuario, aporte_por_usuario.observacion, obligacion_por_usuario.nombre_obligacion, obligacion_por_usuario.valor, obligacion_por_usuario.fecha_creacion, obligacion_por_usuario.fecha_vencimiento FROM aporte_por_usuario, obligacion_por_usuario WHERE aporte_por_usuario.id_usuario =:txtidusuario  AND aporte_por_usuario.id_obligacion_usuario=obligacion_por_usuario.id_obligacion_usuario AND aporte_por_usuario.f_pago=:fechapago AND  aporte_por_usuario.observacion=:txtobservacion ");
    $sentencia_couta->bindParam(':txtidusuario',$id_usuario);
    $sentencia_couta->bindParam(':fechapago',$fecha_pago);
    $sentencia_couta->bindParam(':txtobservacion',$pagado);
    $sentencia_couta->execute();
    $lista_pagos_cuota=$sentencia_couta->fetchAll(PDO::FETCH_ASSOC); 

    $usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios WHERE id_usuario=:txtusuario");
    $sentencia_usuario->bindParam(':txtusuario',$usuario);
    $sentencia_usuario->execute();
    $lista_usuario=$sentencia_usuario->fetch(PDO::FETCH_LAZY);

}

$total=0;
?>
<div id="div_print">
Comite de Agua Pijal (JAAPY)<br>
Comprobante de Pago del servicio de agua potable y alcantarillado<br>

 Usuario:<?php echo ucwords($lista_usuario['apellidos'])." ".ucwords($lista_usuario['nombres']);  ?>   
<br>_______________________________________________________________________

<table id="" >
            <thead>
                <tr>
                    <th >Codigo</th>
                    <th >Llave</th>
                    <th >Obligacion</th>
                    <th >Fecha de Pago</th>
                    
                    <th>Valor</th>
                    <th>.......</th>
                    
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_pagos as $registros){ ?>
                <tr align="center" >
                    <td ><?php echo $registros['id_aporte']; ?></td>
                    <td><?php echo $registros['sector']; ?></td>
                    <td><?php echo $registros['nombre_obligacion']; ?></td>
                    <td><?php echo $registros['f_pago']; ?></td>
                    
                    <td><?php echo $registros['valor_pago']; $total=$total+$registros['valor_pago']; ?></td>
                    <td><?php echo $registros['deposito']; ?></td>
                    
                    
                </tr>
            <?php          } ?> 

            <?php foreach($lista_pagos_cuota as $registros_cuotas){ ?>
                <tr align="center" >
                    <td ><?php echo $registros_cuotas['id_aporte']; ?></td>
                    <td><?php echo "......"; ?></td>
                    <td><?php echo $registros_cuotas['nombre_obligacion']; ?></td>
                    
                    <td><?php echo $registros_cuotas['f_pago'];  ?></td>
                    
                    <td><?php echo $registros_cuotas['valor_pago']; $total=$total+$registros_cuotas['valor_pago']; ?></td>
                    <td><?php echo $registros_cuotas['deposito']; ?></td>
                   
                    
                </tr>
            <?php          } ?> 
            
            
            </tbody>
        </table>
        <br>

        ________________Total____Pagado_________<?php echo $total ?>___Usd_________________________

   

</div>

<script language="Javascript">
function imprimirSeleccion(nombre) {
var ficha = document.getElementById(nombre);
var ventimp = window.open(' ', 'popimpr');
ventimp.document.write( ficha.innerHTML );
ventimp.document.close();
ventimp.print( );
ventimp.close();
}
</script>

<script>
imprimirSeleccion('div_print');
location.href ='<?php echo $url_base."secciones/usuarios_agua/pagos.php?id_usuario=".$_GET['id_usuario']."&csrf_token=".$_SESSION['tocte'] ?>';

</script>

