<?php
include("../../../bd.php");
if ((isset($_POST['poner']))&&($_POST['poner']=="cambiar"))
 {
    $id_aporte=$_POST['id_llave']."-".$_POST['id_obligacion_llave'];   
    $id_llave=(isset($_POST['id_llave']))?$_POST['id_llave']:"";
    $f_pago="";
    $f_asignacion=date("Y-m-d");
    $pagar=$_POST['valor'];
    $observacion="Solo asignado";
    $sentencia=$conexion->prepare("UPDATE aporte_llave SET pagar=:txtpagar where id_aporte=:txtidaporte ");
    $sentencia->bindParam(':txtpagar', $pagar);
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->execute();
}
if ((isset($_POST['poner']))&&($_POST['poner']=="si"))
 {
    $id_aporte=$_POST['id_llave']."-".$_POST['id_obligacion_llave'];   
    $id_llave=(isset($_POST['id_llave']))?$_POST['id_llave']:"";
    $f_pago="";
    $f_asignacion=date("Y-m-d");
    if($_POST['tercera_edad']=='si')
    {
    $pagar=$_POST['valor']/2;
    }else{ $pagar=$_POST['valor'];}
    $valor_pago="";
    $id_acceso="";
    $id_obligacion_llave=(isset($_POST['id_obligacion_llave']))?$_POST['id_obligacion_llave']:"";
    $observacion="Solo asignado";
    $sentencia=$conexion->prepare("INSERT INTO aporte_llave (id_aporte, id_llave, f_pago, f_asignacion, pagar, valor_pago, id_acceso, id_obligacion_llave, observacion)values(:txtidaporte, :txtidllave, :txtfpago, :txtfasignacion, :txtpagar, :txtvalorpago, :txtidacceso, :txtidobligacionllave, :txtobservacion); ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->bindParam(':txtidllave',$id_llave);
    $sentencia->bindParam(':txtfpago', $f_pago);
    $sentencia->bindParam(':txtfasignacion',$f_asignacion);
    $sentencia->bindParam(':txtpagar',$pagar);
    $sentencia->bindParam(':txtvalorpago',$valor_pago);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidobligacionllave',$id_obligacion_llave);
    $sentencia->bindParam(':txtobservacion',$observacion);
    $sentencia->execute();
}
if ((isset($_POST['poner']))&&($_POST['poner']=="no"))
 {
    $id_aporte=$_POST['id_llave']."-".$_POST['id_obligacion_llave']; 
    $sentencia=$conexion->prepare("DELETE FROM aporte_llave WHERE id_aporte=:txtidaporte and observacion<>'Pagado'; ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->execute();
}
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM aporte_llave where id_llave=:txtidllave and id_obligacion_llave=:txtidobligacionllave ");
                    $sentencia_aplicacion->bindParam(':txtidllave',$_POST['id_llave']);
                    $sentencia_aplicacion->bindParam(':txtidobligacionllave',$_POST['id_obligacion_llave']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);
                    foreach($resultado as $dato)
                    {
                    $pagar=$dato['pagar'];
                    }
                    if(($sentencia_aplicacion->rowCount())>0)
                    {                     
                        ?>
                            <div id="check<?php echo $_POST['id_llave']."_".$_POST['id_usuario']; ?>">
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    checked
                                    onclick="poner('<?php echo $_POST['id_llave'];?>','<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_llave']?>','no','<?php echo $_POST['valor']  ?>','<?php echo $_POST['opcion']  ?>','<?php echo $_POST['tercera_edad']; ?>')"
                                    autocomplete="off"
                                />
                                <?php if($_POST['opcion']=='ingresado'){
                                ?>
                               <input type="text" size="4" value="<?php echo $pagar; ?>" onchange="poner('<?php echo $_POST['id_llave'];?>','<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_llave']?>','cambiar',this.value,'<?php echo $_POST['opcion']  ?>','<?php echo $_POST['tercera_edad']; ?>')" />
                               
                                <?php } ?>
                                
                            </div>
                        <?php

                    }
                    else
                    {
                        ?>
                        <div id="check<?php echo $_POST['id_llave']."_".$_POST['id_usuario']; ?>">
                        <input
                            type="checkbox"
                            class="form-check-input"
                            name=""
                            onclick="poner('<?php echo $_POST['id_llave'];?>','<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_llave']?>','si','<?php echo $_POST['valor']  ?>','<?php echo $_POST['opcion']  ?>','<?php echo $_POST['tercera_edad']; ?>')"
                            autocomplete="off"
                        />
                        </div>
                <?php
                    }
    ?>