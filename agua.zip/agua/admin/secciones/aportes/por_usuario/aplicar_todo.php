<?php 
include("../../../bd.php");

if ((isset($_GET['id_obligacion_usuario']))&&($_GET['poner']=="poner"))
 {
 
    $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, usuarios.nombres, usuarios.apellidos, usuarios.estado,usuarios.tercera_edad  FROM  usuarios WHERE usuarios.estado='activo'   AND usuarios.id_usuario NOT IN(select aporte_por_usuario.id_usuario from aporte_por_usuario where aporte_por_usuario.id_obligacion_usuario=:txtobligacionusuario and aporte_por_usuario.id_usuario=usuarios.id_usuario ) ");
    $sentencia->bindParam(':txtobligacionusuario',$_GET['id_obligacion_usuario']);
    $sentencia->execute();
    $lista_usuarios=$sentencia->fetchAll(PDO::FETCH_ASSOC);

    foreach($lista_usuarios as $registros)
    {
         
    $id_aporte=$registros['id_usuario']."-".$_GET['id_obligacion_usuario'];   
    $id_usuario=$registros['id_usuario'];
    $f_pago="";
    $f_asignacion=date("Y-m-d");

    $pagar=$_GET['valor'];
    $valor_pago="";
    $id_acceso="";
    $id_obligacion_usuario=$_GET['id_obligacion_usuario'];
    $observacion="Solo asignado";

    $sentencia=$conexion->prepare("INSERT INTO aporte_por_usuario (id_aporte, id_usuario, f_pago, f_asignacion, pagar, valor_pago, id_acceso, id_obligacion_usuario, observacion)values(:txtidaporte, :txtidusuario, :txtfpago, :txtfasignacion, :txtpagar, :txtvalorpago, :txtidacceso, :txtidobligacionusuario, :txtobservacion); ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':txtfpago', $f_pago);
    $sentencia->bindParam(':txtfasignacion',$f_asignacion);
    $sentencia->bindParam(':txtpagar',$pagar);
    $sentencia->bindParam(':txtvalorpago',$valor_pago);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidobligacionusuario',$id_obligacion_usuario);
    $sentencia->bindParam(':txtobservacion',$observacion);
    
    $sentencia->execute();


    }

}

if ((isset($_GET['id_obligacion_usuario']))&&($_GET['poner']=="quitar"))
 {
 $id_obligacion_usuario=$_GET['id_obligacion_usuario'];
  $sentencia=$conexion->prepare("DELETE FROM aporte_por_usuario WHERE id_obligacion_usuario=:txtidobligacionusuario AND observacion='Solo asignado' ");
  $sentencia->bindParam(':txtidobligacionusuario',$id_obligacion_usuario);
  $sentencia->execute();

}

$MM_redirectLoginSuccess ="aplicar.php?id_obligacion_usuario=".$_GET['id_obligacion_usuario'];
header("Location: " . $MM_redirectLoginSuccess );


?>