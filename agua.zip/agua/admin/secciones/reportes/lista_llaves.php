<?php 
include("../../bd.php");
    $sentencia=$conexion->prepare("SELECT * FROM usuarios,llaves WHERE usuarios.id_usuario=llaves.id_usuario and usuarios.estado='activo' and llaves.suspendido!='si' ");
    $sentencia->execute();
    $total=$sentencia->rowCount();
    $lista=$sentencia->fetchAll(PDO::FETCH_ASSOC);
    
include("../../templates/header.php"); 
?>
<script src="reportes.js"></script>
<a href="javascript:imprimirSeleccion('div_print','lista_llaves.php')" >Imprimir</a>
<div id="div_print">

<div class="card">

<div class="card-header">
<div class="card-header d-flex flex-grow-1 justify-content-center " >
   <h6> Comite de Agua Pijal</h6>
</div>
    Lista general de usuarios y llaves de agua<br>
    ..................................................................
    
</div>
<div class="card-body">

<table class="table">
            <thead>
                <tr class="table-primary">
                    <th scope="col">Llave</th>
                    <th scope="col">Codigo Medidor </th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Sector  vivienda</th>
                    <th scope="col"></th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['sector']; ?></td>
                    <td><?php echo $registros['codigo_medidor']; ?></td>
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td scope="col">------------------------</td>
                    
                </tr>
            <?php  } ?>    
               
            </tbody>
        </table>

        </div>    
</div>
</div>

<?php include("../../templates/footer.php"); ?>

<script>
$(document).ready( function () {
    $('table').DataTable({"pageLength":<?php echo $total ?>,lengthMenu:[[<?php echo $total ?>,3,10,25,50],[<?php echo $total ?>,3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[2,'asc']]});
} );

</script>