<?php 

include("../../../bd.php");

if($_POST)
{
    $nombre_obligacion=(isset($_POST['nombre_obligacion']))?$_POST['nombre_obligacion']:"";
    $valor=(isset($_POST['valor']))?$_POST['valor']:"";
    $fecha_creacion=(isset($_POST['fecha_creacion']))?$_POST['fecha_creacion']:"";
    $fecha_vencimiento=(isset($_POST['fecha_vencimiento']))?$_POST['fecha_vencimiento']:"";
    $opcion=(isset($_POST['opcion']))?$_POST['opcion']:"";
   
    $sentencia=$conexion->prepare("INSERT INTO obligacion_por_usuario (nombre_obligacion,valor,fecha_creacion,fecha_vencimiento,opcion)values(:txtnombre,:txtvalor,:txtfechacreacion,:txtfechavencimiento,:txtopcion); ");
    $sentencia->bindParam(':txtnombre',$nombre_obligacion);
    $sentencia->bindParam(':txtvalor',$valor);
    $sentencia->bindParam(':txtfechacreacion',$fecha_creacion);
    $sentencia->bindParam(':txtfechavencimiento',$fecha_vencimiento);
    $sentencia->bindParam(':txtopcion',$opcion);
    $sentencia->execute();

}




include("../../../templates/header.php"); ?>

<script src="../../../libs/CalendarControl.js" type="text/javascript"></script>
<link href="../../../libs/CalendarControl.css"  rel="stylesheet" type="text/css">

<div class="card">
    <div class="card-header">Crear Obligaciones para Usuario</div>
    <div class="card-body">
        <form action="" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label for="nombre_obligacion" class="form-label">Nombre Obligacion</label>
            <input
                type="text"
                class="form-control"
                name="nombre_obligacion"
                id="nombre_obligacion"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="valor" class="form-label">Valor</label>
            <input
                type="text"
                class="form-control"
                name="valor"
                id="valor"
                aria-describedby="helpId"
                placeholder=""
            />
            
        </div>
        <div class="mb-3">
            <label for="fecha_creacion" class="form-label">Fecha de creación</label>
            <input
                type="text"
                class="form-control"
                name="fecha_creacion"
                id="fecha_creacion"
                aria-describedby="helpId"
                placeholder=""
                onclick="showCalendarControl(this);"
            />
            
        </div>
        <div class="mb-3">
            <label for="fecha_vencimiento" class="form-label">Fecha Vencimiento</label>
            <input
                type="text"
                class="form-control"
                name="fecha_vencimiento"
                id="fecha_vencimiento"
                aria-describedby="helpId"
                placeholder=""
                onclick="showCalendarControl(this);"
            />
            
        </div>
        
        <div class="mb-3">
            <label for="opcion" class="form-label">Tipo</label>
            <select
                class="form-select form-select-lg"
                name="opcion"
                id="opcion"
            >
                <option selected>Selecionar Uno</option>
                <option value="fijo">Valor fijo</option>
                <option value="ingresado">Valor ingresado</option>
                                
            </select>
        </div>
        
        
        
        
        <button
            type="submit"
            class="btn btn-success"
        >
            Guardar
        </button>
        
        <a
            name=""
            id=""
            class="btn btn-primary"
            href="index.php"
            role="button"
            >Cancelar</a
        >
        
        
        </form>
       
    </div>
    
</div>




<?php include("../../../templates/footer.php"); ?>

 