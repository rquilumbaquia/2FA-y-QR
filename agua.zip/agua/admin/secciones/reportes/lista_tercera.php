<?php 
include("../../bd.php");
    $sentencia=$conexion->prepare("SELECT * FROM usuarios WHERE estado='activo' AND tercera_edad='si' ");
    $sentencia->execute();
    $total=$sentencia->rowCount();
    $lista=$sentencia->fetchAll(PDO::FETCH_ASSOC);
    
include("../../templates/header.php"); 
?>
<script src="reportes.js"></script>
<a href="javascript:imprimirSeleccion('div_print','lista_general.php')" >Imprimir</a>
<div id="div_print">

<div class="card">

<div class="card-header">
<div class="card-header d-flex flex-grow-1 justify-content-center " >
   <h6> Comite de Agua Pijal</h6>
   </div>
    Lista de Usuarios en tercera edad<br>
    ..................................................................
    
</div>
<div class="card-body">

<table class="table">
            <thead>
                <tr class="table-primary">
                    
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Dirección/Sector</th>
                    <th scope="col">Cedula</th>
                    <th scope="col">Tercera Edad</th>
                    <th scope="col"></th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td><?php echo $registros['tercera_edad']; ?></td>
                    <td>---------------------------</td>
                    
                </tr>
            <?php  } ?>    
               
            </tbody>
        </table>

        </div>    
</div>
</div>

<?php include("../../templates/footer.php"); ?>

<script>
$(document).ready( function () {
    $('table').DataTable({"pageLength":<?php echo $total ?>,lengthMenu:[[<?php echo $total ?>,3,10,25,50],[<?php echo $total ?>,3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[2,'asc']]});
} );

</script>