function validarUsuario()
{   
    var mensaje="";
    var usuario= $('#login').val();
    var contrasenia= $('#password-input').val();    
    var contrasenia2= $('#password-input2').val();// Cogemos del formulario el valor pass

    // Función que envía y recibe respuesta con AJAX
     
     if(($('#password-input').val()=="")){
             mensaje=mensaje+"Ingrese Password<br>";
      } 
      
      if(($('#password-input2').val()=="")){
        mensaje=mensaje+"Ingrese Segundo Password<br>";
      } 
 
      if(contrasenia!==contrasenia2)
        {
        mensaje=mensaje+"Las contraseñas no estan iguales";
        }      
      if(mensaje!==""){
    $('#mensajetotal').html("<div class='alert alert-danger alert-dismissible fade show' role='alert' > <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button><strong>"+mensaje+"</strong></div>");
    document.getElementById("cerrar_modal").click();
    document.getElementById("guardar").disabled=true;
   }else{   
    document.getElementById("guardar").disabled=false;
    $.ajax({
     type: 'POST',  // Envío con método POST
     url: '/agua/admin/libs/generadorqr/aguaqr.php',  // Fichero destino (el PHP que trata los datos)
     data: { login: usuario, password: contrasenia } // Datos que se envían
     }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
      $("#divimagen").html(msg);  // Escribimos en el div consola el mensaje devuelto
     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
     // Mostramos en consola el mensaje con el error que se ha producido
     $("#divimagen").html("The following error occured: "+ textStatus +" "+ errorThrown); 
    });
    
    }
     
}
        function generarUsuario()
        {
        datos= $('#data').val(); // Cogemos del formulario el valor nom
        nivel= $('#level').val(); // Cogemos del formulario el valor pass
        tamanio= $('#size').val();
        // Función que envía y recibe respuesta con AJAX
        $.ajax({
         type: 'POST',  // Envío con método POST
         url: '/agua/admin/libs/generadorqr/aguaqr.php',  // Fichero destino (el PHP que trata los datos)
         data: { data: datos, level: nivel, size: tamanio } // Datos que se envían
         }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
          $("#divimagen").html(msg);  // Escribimos en el div consola el mensaje devuelto
         }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
         // Mostramos en consola el mensaje con el error que se ha producido
         $("#divimagen").html("The following error occured: "+ textStatus +" "+ errorThrown); 
        });
                            
         }
 
      
            
