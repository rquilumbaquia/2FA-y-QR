<?php 
include("../../bd.php");
include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php");
if (!isset($_SESSION)) {
  correr_session();
  }

  if ((isset($_POST['id_usuario'])))
 {
   
    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
    
    $cantidad=$_POST['valor'];
    $sentencia=$conexion->prepare("UPDATE rayas_usuario SET cantidad_raya=:txtcantidad WHERE id_raya=:txtidraya ");
    $sentencia->bindParam(':txtcantidad',$cantidad);
    $sentencia->bindParam(':txtidraya', $id_raya);
    $sentencia->execute();
}

                    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM rayas_usuario where id_raya=:txtidraya ");
                    $sentencia_aplicacion->bindParam(':txtidraya',$id_raya);
                    
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetch(PDO::FETCH_LAZY);
                    echo  $resultado['cantidad_raya'];


?>