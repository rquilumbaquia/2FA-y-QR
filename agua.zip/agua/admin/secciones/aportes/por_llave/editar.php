<?php
include("../../../bd.php");
include("../../../templates/header.php"); ?>
<?php
if($_POST)
{

    $id_obligacion_llave=$_POST['id_obligacion_llave'];
    $nombre_obligacion=$_POST['nombre_obligacion'];
    $valor=$_POST['valor'];
    $fecha_creacion=$_POST['fecha_creacion'];
    $fecha_vencimiento=$_POST['fecha_vencimiento'];
    $tercera_edad=$_POST['aplica_tercera'];
    $opcion=$_POST['opcion'];
    $tarifa_mes=$_POST['tarifa_mes'];
    
    $sentencia=$conexion->prepare("UPDATE obligacion_por_llave SET nombre_obligacion=:txtnombreobligacion, valor=:txtvalor, fecha_creacion=:txtfechacreacion, fecha_vencimiento=:txtfechavencimiento, opcion=:txtopcion, aplica_tercera=:txtterceraedad, tarifa_mes=:txttarifames where id_obligacion_llave=:txtidobligacionllave ");
    $sentencia->bindParam(':txtnombreobligacion', $nombre_obligacion);
    $sentencia->bindParam(':txtvalor', $valor);
    $sentencia->bindParam(':txtfechacreacion', $fecha_creacion);
    $sentencia->bindParam(':txtfechavencimiento', $fecha_vencimiento);
    $sentencia->bindParam(':txtopcion', $opcion);
    $sentencia->bindParam(':txtterceraedad', $tercera_edad);
   
    $sentencia->bindParam(':txttarifames', $tarifa_mes);
    $sentencia->bindParam(':txtidobligacionllave', $id_obligacion_llave);
    $sentencia->execute();
   
    $MM_redirectLoginSuccess ="index.php";
    header("Location: " . $MM_redirectLoginSuccess );

}

if($_GET)

{
$id_obligacion_llave=(isset($_GET['id_obligacion_llave']))?$_GET['id_obligacion_llave']:"";
$sentencia=$conexion->prepare("SELECT * FROM obligacion_por_llave where  id_obligacion_llave=:txtidobligaciollave   ");
$sentencia->bindParam(':txtidobligaciollave',$id_obligacion_llave);
$sentencia->execute();
$lista_aportes_llave=$sentencia->fetch(PDO::FETCH_LAZY);


}

?> 
<script src="../../../libs/CalendarControl.js" type="text/javascript"></script>
<link href="../../../libs/CalendarControl.css"  rel="stylesheet" type="text/css">
<div class="mb-3">
<form action="" method="post">

<input type="text" class="form-control" name="id_obligacion_llave" id="id_obligacion_llave"   value="<?php echo $lista_aportes_llave['id_obligacion_llave'] ?>"/><br>

Nombre Obligacion<input type="text" class="form-control" name="nombre_obligacion" id="nombre_obligacion"  value="<?php echo $lista_aportes_llave['nombre_obligacion'] ?>"/><br>
valor<input type="text" class="form-control"  name="valor" value="<?php echo $lista_aportes_llave['valor'] ?>" /><br>
Fecha creacion<input type="text" class="form-control" name="fecha_creacion"   value="<?php echo $lista_aportes_llave['fecha_creacion'] ?>" onclick="showCalendarControl(this);" /><br>
Fecha vencimiento<input type="text" class="form-control" name="fecha_vencimiento"   value="<?php echo $lista_aportes_llave['fecha_vencimiento'] ?>" onclick="showCalendarControl(this);" /><br>
Tercera Edad
<select
                class="form-select form-select-lg"
                name="aplica_tercera"
                id="activo"
            >
                <option selected value="<<?php echo $lista_aportes_llave['aplica_tercera'] ?>">Selecionar Uno</option>
                <option value="si">Si</option>
                <option value="no">No</option>
                                                
            </select>


Tipo
<select
                class="form-select form-select-lg"
                name="opcion"
                id="activo"
            >
                <option selected value="<<?php echo $lista_aportes_llave['opcion'] ?>">Selecionar Uno</option>
                <option value="fijo">Fijo</option>
                <option value="ingresado">Ingresado</option>
                                                
            </select>

Tarifa Mes 
<select
                class="form-select form-select-lg"
                name="tarifa_mes"
                id="activo"
            >
                <option selected value="<?php echo $lista_aportes_llave['tarifa_mes'] ?>">Selecionar Uno</option>
                <option value="si">Si</option>
                <option value="no">No</option>
                                                
            </select>


<input type="submit" value="Guardar" />

</form>
</div>




<?php include("../../../templates/footer.php"); ?>

 