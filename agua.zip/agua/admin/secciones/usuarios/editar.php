<?php 
include("../../bd.php");
include("../../templates/header.php");
if(($_GET)&&($_SESSION['tocte']==$_GET['csrf_token']))
{
  $id_acceso="";
$sentencia=$conexion->prepare("SELECT * FROM a_lectivo ORDER BY f_inicio desc");
$sentencia->execute();
$lista_anios=$sentencia->fetchAll(PDO::FETCH_ASSOC);
$id_acceso=(isset($_GET['id_acceso']))?$_GET['id_acceso']:"";
/*saneamiento de valores */
//echo "VALOR CON INYECCION ES :".$id_acceso."<br>";
$id_acceso=$conexion->quote($id_acceso);
$caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
$id_acceso = trim(str_replace($caracteresNoPermitidos,'',$id_acceso));
/*echo "VALOR CON FILTRO ES :".$id_acceso."<br>";*/
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
$sentencia_usuario->bindParam(':txtidacceso',$id_acceso,PDO::PARAM_INT);
$sentencia_usuario->execute();
//echo $sentencia_usuario->debugDumpParams()."<br>";

$lista_usuarios=$sentencia_usuario->fetch(PDO::FETCH_LAZY);
if($sentencia_usuario->rowCount()>0) {

?>
<script src="usuarios.js" type="text/javascript">
</script>
<script src="../../../admin/libs/CalendarControl.js" type="text/javascript"></script>
<script src="password.js" type="text/javascript"></script>
<link href="../../../admin/libs/CalendarControl.css"  rel="stylesheet" type="text/css">
<link href="password.css"  rel="stylesheet" type="text/css">

<svg xmlns="" style="display: none;">
  <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
  </symbol>
  <symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
  </symbol>
  <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
  </symbol>
 </svg>
<div class="card">
  <div class="card-header">Desea modificar los datos?
         <button type="button"
            id="btcambiar"
            name="btcambiar"
            class="btn btn-outline-primary"
            data-bs-toggle="modal" 
            data-bs-target="#exampleModal"
            title="Cambiar password"
            onclick="cambio_password()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
            <path d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
            </svg>
         </button>
  </div>
  <div class="card-body">
   <form action="guardar_usuario.php" method="post" autocomplete="off" > 
  <div class="mb-3">
      
        <input type="hidden" 
        name="csrf_token" 
        id="csrf_token"
        value="<?php echo $_SESSION['tocte']; ?>"
         />
        <input
        type="hidden"
        name="id_acceso"
        id="id_acceso"
        value="<?php echo $lista_usuarios['id_acceso']; ?>" />   
    <label for="nombre" class="form-label">Nombre del Usuario</label>
    <input
        type="text"
        class="form-control"
        name="nombre"
        id="nombre"
        aria-describedby="helpId"
        placeholder="Nombre del usuario"
        value="<?php echo $lista_usuarios['nombre']; ?>"
        disabled />
    <label for="correo" class="form-label">Correo</label>
    <div id="mensajecorreo"></div>
    <input
        type="text"
        class="form-control"
        name="correo"
        id="correo"
        onchange="verificar_adecuado('correo',this.value)"
        aria-describedby="helpId"
        placeholder="@correo electronico"
        value="<?php echo $lista_usuarios['correo']; ?>"
        disabled />
    <label for="login" class="form-label">Login</label>
    <div id="mensajelogin"></div>
    <input
        type="text"
        class="form-control"
        name="login"
        id="login"
        onchange="verificar_adecuado('login',this.value)"
        aria-describedby="helpId"
        placeholder="JAAPI<?php echo date('Y'); ?>--su login---"
        value="<?php echo $lista_usuarios['login']; ?>"
        disabled />
<label for="password-input" class="form-label">Cambiar la Contraseña</label>    
<div class="row">
<div class="col-6">
  <div class="input-group d-flex">
    <span
      class="input-group-text border-0"
      id="password"
      >
    </span>
      <input
        type="password"
        class="form-control rounded mt-1"
        placeholder="Ingrese su nueva contraseña"
        aria-label="password"
        aria-describedby="password"
        id="password-input"
        name="password-input"
        value=""
        disabled
      />
      <script>
      //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
      $('#password-input').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
      });
      </script> 
      
            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword()"> 
            <span class="fa fa-eye-slash icon"></span> 
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
            </svg>
            </button>

                           
      <div class="valid-feedback">Fortaleza Bueno</div>
      <div class="invalid-feedback">Fortaleza Malo</div>
    </div>
  </div>
  <div class="col-6 mt-4 mt-xxl-0 w-auto h-auto">
    <div
      data-mdb-alert-init class="alert px-4 py-3 mb-0 d-none"
      role="alert"
      data-mdb-color="warning"
      id="password-alert"
      >
      <ul class="list-unstyled mb-0">
        <li class="requirements leng">
        Su contraseña debe tener al menos 12 caracteres
          <i class="fa fa-check text-success me-2" >
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>

          <i class="fa fa-times text-danger me-3" ></i>
          </li>
        <li class="requirements big-letter">
        Su password debe tener al menos una letra mayuscula.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
        <li class="requirements num">
        Su contraseña debe tener al menos un numero.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
        <li class="requirements special-char">
        su contraseña debe tener al menos un caracter especial.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
      </ul>
    </div>

  </div>
</div>
            <label for="cargo" class="form-label">Cargo</label>
            <select
                class="form-select form-select-lg"
                name="cargo"
                id="cargo"
                disabled
            >
                <option selected value="<?php echo $lista_usuarios['cargo']; ?>">Selecionar Uno</option>
                <option value="presidente">Presidente</option>
                <option value="secretario">Secretario</option>
                <option value="tesorero">Tesorero</option>
                <option value="coperativa">Coperativa</option>                                
            </select>

            <label for="activo" class="form-label">Activo</label>
            <select
                class="form-select form-select-lg"
                name="activo"
                id="activo"
                disabled
            >
                <option selected value="<?php echo $lista_usuarios['activo']; ?>">Selecionar Uno</option>
                <option value="si">Si</option>
                <option value="no">No</option>
                <option value="bloqueado">Bloqueado</option>
                                                
            </select>
            
            <label for="anio_lectivo" class="form-label">Año Lectivo</label>
            <select
                class="form-select form-select-lg"
                name="anio_lectivo"
                id="anio_lectivo"
                onchange="poner_fechas()"
                disabled
            >
                <option selected value="<?php echo $lista_usuarios['anio_lectivo']; ?>">Selecionar Uno</option>
                <?php foreach($lista_anios as $registros){ ?>
                <option value="<?php echo $registros['anio_lectivo']; ?>" ><?php echo $registros['nombre_anio']; ?></option>
                <?php } ?>
            </select>

    <label for="f_inicio" class="form-label">Fecha de Inicio</label>
    <input
        type="text"
        class="form-control"
        name="f_inicio"
        id="f_inicio"
        aria-describedby="helpId"
        placeholder="Fecha de Inicio"
        value="<?php echo $lista_usuarios['f_inicio']; ?>"
        onclick="showCalendarControl(this);"
        disabled
    />
    <label for="f_final" class="form-label">Fecha de final</label>    
    <input
        type="text"
        class="form-control"
        name="f_final"
        id="f_final"
        aria-describedby="helpId"
        placeholder="Fecha de finalizacion"
        value="<?php echo $lista_usuarios['f_final']; ?>"
        onclick="showCalendarControl(this);"
        disabled
    />
    <label for="aplicar_2fa" class="form-label">Aplicar 2FA</label>
    <select
    class="form-select form-select-lg"
    name="aplicar_2fa"
    id="aplicar_2fa"
    disabled
    >
    <option selected value="<?php echo $lista_usuarios['aplicar_2fa']; ?>">Selecionar Uno</option>
    <option value="">Ninguno</option>
    <option value="email">Correo electronico</option>
    <option value="watsap">Watsap</option>
    <option value="QR">Imagen QR</option>    
    </select>    

        <!-- Modal -->
    <!-- Button trigger modal -->
    
    

    <button type="button"
    id="btgenerar"
    name="btgenerar"
    class="btn btn-outline-success"
    data-bs-toggle="modal" 
    data-bs-target="#exampleModal"
    title="Generar Codigo QR para el usuario"
    disabled
    onclick="validarUsuario()">
    Generar Usuario
    </button>
    

<!-- Scrollable modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">                </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="cerrar_modal" name="cerrar_modal"></button>
      </div>
      <div class="modal-body" id="divimagen" >        
      <div id="mensajetotal" ></div>
      </div>
      <div class="modal-footer">        
        <button type="submit" class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Guardar el Usuario" name="guardar " id="guardar">Guardar</button>
      </div>
    </div>
  </div>
</div>
        <a
            name=""
            id=""
            class="btn btn-outline-success"
            href="index.php"
            role="button"
            data-bs-toggle="tooltip" data-bs-placement="top" 
            title="Dejar de Crear Usuarios para el Sistema"
            >Cancelar</a
        >          
   
</div>
</form>
        
    </div>
    <div class="card-footer text-muted">

    </div>
</div>
<?php 
}
}
?>

<?php include("../../templates/footer.php"); ?>
<script>

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

var myModal = document.getElementById('exampleModal')
var myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', function () {
  myInput.focus()
})




</script>