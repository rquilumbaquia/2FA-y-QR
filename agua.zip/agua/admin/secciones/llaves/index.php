<?php 
include("../../bd.php");
include("../../templates/header.php"); 

if((isset($_GET['csrf_token']))&&($_GET['csrf_token']==$_SESSION['tocte'])){
if(isset($_GET['eliminar'])&&($_GET['eliminar']=='si')){ 
    $id_llave=(isset($_GET['id_llave']))?$_GET['id_llave']:"";
    $sentencia=$conexion->prepare("DELETE FROM llaves WHERE id_llave=:txtllave; ");
    $sentencia->bindParam(':txtllave',$id_llave);
    $sentencia->execute();
    $mensaje="La llave ha sido eliminada";
}
if(($_GET)){
    $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sentencia=$conexion->prepare("SELECT * FROM llaves WHERE id_usuario=:txtusuario; ");
    $sentencia->bindParam(':txtusuario',$id_usuario);
    $sentencia->execute();
    $lista_llaves=$sentencia->fetchAll(PDO::FETCH_ASSOC);   
    $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios WHERE id_usuario=:txtidusuario");
    $sentencia_usuario->bindParam(':txtidusuario',$id_usuario);
    $sentencia_usuario->execute();
    $lista_usuario=$sentencia_usuario->fetch(PDO::FETCH_LAZY);    
}
?>
<script src="llaves.js"></script>
Lista de llaves de <?php echo $lista_usuario['apellidos']." ".$lista_usuario['nombres'];  ?>
<div class="card">
    <div class="card-header">
       <a  name=""
        id=""
        href="crear.php?id_usuario=<?php echo $_GET['id_usuario'] ?>"       
        >Asignar Nueva LLave</a>        
    </div>   
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table 
            class="table"
        >
            <thead>
                <tr>
                    <th scope="col">Sector</th>
                    <th scope="col">Orden en Lista</th>
                    <th scope="col">codigo Medidor</th>
                    <th scope="col">Suspendido</th>
                    <th scope="col">Información</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_llaves as $registros){ ?>
                <tr class="">                    
                    <td><img src="../imagenes/grifo.jpeg" height="40"  />
                    <div id="sector<?php echo $registros['id_llave'];  ?>" ondblclick="cambiar_valor('sector','<?php echo $registros['id_llave'];  ?>','','mostrar')" >
                    -<?php echo $registros['sector']; ?>
                    </div>
                    </td>
                    <td>-<?php echo $registros['orden_lista']; ?></td>
                    <td>-<?php echo $registros['codigo_medidor']; ?></td>
                    <td>                    
                    <div id="suspendido<?php echo $registros['id_llave'];  ?>" ondblclick="cambiar_valor('suspendido','<?php echo $registros['id_llave'];  ?>','','mostrar')" >
                    -<?php echo $registros['suspendido']; ?>                    
                    </div>                    
                    </td>
                    <td>
                    <div id="informacion<?php echo $registros['id_llave'];  ?>" ondblclick="cambiar_valor('informacion','<?php echo $registros['id_llave'];  ?>','','mostrar')" >
                    -<?php echo $registros['informacion']; ?>                    
                    </div>
                    </td>
                    <td>
                    <a
                    name=""
                    id=""                   
                    href="index.php?eliminar=si&id_llave=<?php echo $registros['id_llave'];  ?>&id_usuario=<?php echo $_GET['id_usuario'] ?>&csrf_token=<?php echo $_SESSION['tocte'] ?>"                    
                    >Eliminar</a>    
                   </td>                    
                </tr>
            <?php  } ?> 
            </tbody>
        </table>
    </div>
    </div>   
</div>
<?php } ?>
<?php include("../../templates/footer.php"); ?>