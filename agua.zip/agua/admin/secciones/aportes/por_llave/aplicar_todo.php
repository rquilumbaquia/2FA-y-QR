<?php 
include("../../../bd.php");
if ((isset($_GET['id_obligacion_llave']))&&($_GET['poner']=="poner"))
{
    $sentencia=$conexion->prepare("SELECT usuarios.nombres, usuarios.apellidos, usuarios.estado,usuarios.tercera_edad, llaves.id_llave, llaves.id_usuario FROM llaves, usuarios WHERE usuarios.estado='activo' AND llaves.id_usuario=usuarios.id_usuario AND llaves.suspendido='no' AND llaves.id_llave NOT IN(select aporte_llave.id_llave from aporte_llave where aporte_llave.id_obligacion_llave=:txtobligacion and aporte_llave.id_llave=llaves.id_llave ); ");
    $sentencia->bindParam(':txtobligacion',$_GET['id_obligacion_llave']);
    $sentencia->execute();
    $lista_usuarios=$sentencia->fetchAll(PDO::FETCH_ASSOC);
    foreach($lista_usuarios as $registros)
    {
    $id_aporte=$registros['id_llave']."-".$_GET['id_obligacion_llave'];   
    $id_llave=$registros['id_llave'];
    $f_pago="";
    $f_asignacion=date("Y-m-d");
    if($registros['tercera_edad']=='si')
    {

    $pagar=$_GET['valor']/2;
    
     }else{ $pagar=$_GET['valor'];}
   
    $valor_pago="";
    $id_acceso="";
    $id_obligacion_llave=$_GET['id_obligacion_llave'];
    $observacion="Solo asignado";
    $sentencia=$conexion->prepare("INSERT INTO aporte_llave (id_aporte, id_llave, f_pago, f_asignacion, pagar, valor_pago, id_acceso, id_obligacion_llave, observacion)values(:txtidaporte, :txtidllave, :txtfpago, :txtfasignacion, :txtpagar, :txtvalorpago, :txtidacceso, :txtidobligacionllave, :txtobservacion); ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->bindParam(':txtidllave',$id_llave);
    $sentencia->bindParam(':txtfpago', $f_pago);
    $sentencia->bindParam(':txtfasignacion',$f_asignacion);
    $sentencia->bindParam(':txtpagar',$pagar);
    $sentencia->bindParam(':txtvalorpago',$valor_pago);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidobligacionllave',$id_obligacion_llave);
    $sentencia->bindParam(':txtobservacion',$observacion);
    $sentencia->execute();
    }
}
if ((isset($_GET['id_obligacion_llave']))&&($_GET['poner']=="quitar"))
 {
  $id_obligacion_llave=$_GET['id_obligacion_llave'];
  $id_obligacion_llave=(isset($_GET['id_obligacion_llave']))?$_GET['id_obligacion_llave']:"";
  $observacion="Solo asignado";
  $sentencia=$conexion->prepare("DELETE FROM aporte_llave WHERE id_obligacion_llave=:txtidobligacionllave AND observacion='Solo asignado' ");
  $sentencia->bindParam(':txtidobligacionllave',$id_obligacion_llave);
  $sentencia->execute();

 }

$MM_redirectLoginSuccess ="aplicar.php?id_obligacion_llave=".$_GET['id_obligacion_llave'];
header("Location: " . $MM_redirectLoginSuccess );
?>