<?php include("../../bd.php"); ?>
<?php include("../../templates/header.php"); ?>
<?php 
if(isset($_GET))
{

$id_obligacion_llave=$_GET['id_obligacion_llave'];
$sentencia=$conexion->prepare("SELECT llaves.orden_lista,llaves.codigo_medidor ,aporte_llave.id_aporte,aporte_llave.id_llave,aporte_llave.medidor,aporte_llave.lectura_actual,aporte_llave.lectura_anterior,aporte_llave.id_obligacion_llave,usuarios.nombres,usuarios.apellidos,usuarios.direccion ,llaves.sector,llaves.informacion FROM aporte_llave,llaves,usuarios WHERE aporte_llave.id_llave=llaves.id_llave AND llaves.id_usuario=usuarios.id_usuario and llaves.suspendido='no' AND usuarios.estado='activo' AND aporte_llave.id_obligacion_llave=:txtidobligaciollave ORDER BY llaves.orden_lista ASC ; " );
$sentencia->bindParam(':txtidobligaciollave',$id_obligacion_llave);
$sentencia->execute();
$lista_lectura=$sentencia->fetchAll(PDO::FETCH_ASSOC);

$id_obligacion_llave=$_GET['id_obligacion_llave'];
$sentencia_obligacion=$conexion->prepare("SELECT * FROM obligacion_por_llave WHERE id_obligacion_llave=:txtidobligaciollave" );
$sentencia_obligacion->bindParam(':txtidobligaciollave',$id_obligacion_llave);
$sentencia_obligacion->execute();
$lista_obligacion=$sentencia_obligacion->fetch(PDO::FETCH_LAZY);

$fechaactual=$lista_obligacion['fecha_creacion'];
$sentencia_obligacion_anterior=$conexion->prepare("SELECT * FROM obligacion_por_llave WHERE fecha_creacion<:txtfechaactual AND tarifa_mes='si' order by fecha_creacion desc " );
$sentencia_obligacion_anterior->bindParam(':txtfechaactual',$fechaactual);
$sentencia_obligacion_anterior->execute();
$lista_obligacion_anterior=$sentencia_obligacion_anterior->fetch(PDO::FETCH_LAZY);


}


?>
<script src="lecturas.js" type="text/javascript"></script>

<p class="text-center"  >Lecturas para <?php echo $lista_obligacion['nombre_obligacion']; ?><br>
 
</p>



<table
            class="table" 
        >
            <thead>
                <tr>
                    
                    <th scope="col">Codigo Medidor</th>
                    <th scope="col">Direccion llave</th>
                    <th scope="col">Direccion/Casa</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Lectura anterior</th>
                    <th scope="col">Lectura Actual</th>
                    <th scope="col">Medidor/Consumo</th>
                    <th scope="col"></th>
                    
                    
                   
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_lectura as $registros){ ?>
                <tr class="">
                   
                    <td>
                        
                        <div id="codigo_medidor<?php echo $registros['id_llave'] ?>" >
                        <input type="text" 
                        value="<?php echo $registros['codigo_medidor']; ?>"
                        id="txtcodigo_medidor<?php  $registros['id_llave']; ?>"
                        name="txtcodigo_medidor<?php  $registros['id_llave']; ?>"
                        onchange="cambiar_datos('<?php echo $registros['id_llave'] ?>',this.value,'codigo_medidor');" 
                        size="5"
                        />
                        </div>
                    
                    </td>
                    <td>
                    <div id="sector<?php echo $registros['id_llave'] ?>" >
                        <input type="text" 
                        value="<?php echo $registros['sector']; ?>"
                        id="txtsector<?php  $registros['id_llave']; ?>"
                        name="txtsector<?php  $registros['id_llave']; ?>"
                        onchange="cambiar_datos('<?php echo $registros['id_llave'] ?>',this.value,'sector');" 
                        size="10"
                        />

                    </div>
                    </td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['apellidos']." ".$registros['nombres']; ?></td>
                    <td>
                    <div id="anterior<?php echo $registros['id_aporte'] ?>" >
                    
                    <?php echo $registros['lectura_anterior']; ?>
                   
                    </div>
                    </td>
                    <td>
                    <div id="lectura<?php echo $registros['id_aporte'] ?>" >
                    <input type="text" value="<?php echo $registros['lectura_actual']; ?>" 
                    id="txt<?php echo $registros['id_aporte'] ?>" 
                    name="txt<?php echo $registros['id_aporte'] ?>"  
                    onchange="poner_lectura('<?php echo $registros['id_aporte'] ?>',this,'<?php echo $lista_obligacion_anterior['id_obligacion_llave'] ?>','<?php echo $registros['id_llave'] ?>');" 
                    size="4"/>
                    </div>
                    </td>
                    <td>
                    <div id="consumo<?php echo $registros['id_aporte'] ?>" >
                        <?php echo $registros['medidor']; ?></td>
                        </div>
                    <td></td>
                   
                   
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>






<?php include("../../templates/footer.php"); ?>

<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[5,'desc']]});
} );

  </script>

 