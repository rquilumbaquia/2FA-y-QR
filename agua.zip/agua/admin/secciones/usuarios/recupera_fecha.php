<?php 
include("../../bd.php");

if($_POST){
    $anio=$_POST['anio_lectivo'];

$sentencia=$conexion->prepare("SELECT * FROM a_lectivo where anio_lectivo=:txtaniolectivo ");
$sentencia->bindParam(':txtaniolectivo',$anio);
$sentencia->execute();
$lista=$sentencia->fetch(PDO::FETCH_LAZY);

if($_POST['campo']=="f_inicio"){
    echo $lista['f_inicio'];
    }
    if($_POST['campo']=="f_final"){
        echo $lista['f_final'];
        }
    

}


?>