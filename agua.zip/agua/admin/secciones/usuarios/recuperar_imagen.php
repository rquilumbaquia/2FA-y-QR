<?php 
include("../../bd.php");
if(isset($_POST))
{
    $url_base="http://".$_SERVER['SERVER_NAME']."/agua/admin/libs/generadorqr/temp/";
    $id_acceso=(isset($_POST['id_acceso']))?$_POST['id_acceso']:"";
    $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->execute();
    $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);

echo '<img src="'. $url_base.$lista_usuario['imagen_qr'].'" /><hr/>';


}

?>
<input type="hidden"  value="<?php echo  $id_acceso ?>" name="id_user" id="id_user" />