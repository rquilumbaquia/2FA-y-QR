<?php 
include("../../bd.php");
if($_POST){

    $id_acceso=(isset($_POST['id_acceso']))?$_POST['id_acceso']:"";
    $password_actual=(isset($_POST['password_actual']))?$_POST['password_actual']:"";
    /*saneamiento de valores */
    $sentencia_usuario=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
    $sentencia_usuario->bindParam(':txtidacceso',$id_acceso);
    $sentencia_usuario->execute();
    $lista_usuarios=$sentencia_usuario->fetch(PDO::FETCH_LAZY);
    if (password_verify($password_actual, $lista_usuarios['password']))  {    
    echo "correcto";
    }else{echo "incorrecto";}

?>




<?php

}


?>




