<?php 
include("../../bd.php");
include("../../templates/header.php"); 

if((isset($_GET['periodos']))&&(($_GET['periodos']=="otros")))
{
    $sentencia=$conexion->prepare("SELECT @tabla:='obligacion_por_llave' as tabla, id_obligacion_llave as codigo, nombre_obligacion as nombre ,fecha_creacion as creacion ,fecha_vencimiento as vencimiento ,valor as cantidad  FROM obligacion_por_llave  UNION ALL SELECT @tabla:='obligacion_por_usuario' as tabla,id_obligacion_usuario as codigo,nombre_obligacion as nombre,fecha_creacion  as creacion,fecha_vencimiento as vencimiento,valor as cantidad FROM obligacion_por_usuario ");
    $sentencia->execute();
    $lista_aportes=$sentencia->fetchAll(PDO::FETCH_ASSOC);
    
}else
{
    $fecha_inicio=$_SESSION['f_inicio_periodo'];
    $fecha_final=$_SESSION['f_final_periodo'];
    $sentencia=$conexion->prepare("SELECT @tabla:='obligacion_por_llave' as tabla, id_obligacion_llave as codigo, nombre_obligacion as nombre ,fecha_creacion as creacion ,fecha_vencimiento as vencimiento ,valor as cantidad  FROM obligacion_por_llave WHERE fecha_creacion>=:txtfechainicio and fecha_creacion <=:txtfechafinal UNION ALL SELECT @tabla:='obligacion_por_usuario' as tabla ,id_obligacion_usuario as codigo,nombre_obligacion as nombre,fecha_creacion  as creacion,fecha_vencimiento as vencimiento,valor as cantidad FROM obligacion_por_usuario WHERE fecha_creacion>=:txtfechainicio2 and fecha_creacion <=:txtfechafinal2 ");
    $sentencia->bindParam(':txtfechainicio',$fecha_inicio);
    $sentencia->bindParam(':txtfechafinal',$fecha_final);
    $sentencia->bindParam(':txtfechainicio2',$fecha_inicio);
    $sentencia->bindParam(':txtfechafinal2',$fecha_final);
    $sentencia->execute();
    $lista_aportes=$sentencia->fetchAll(PDO::FETCH_ASSOC);

}

?>

Lista de Obligaciones 
<div class="card">

    <div class="card-header">
    
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="recaudacion_por_obligaciones.php"
        role="button"
        >Periodo actual</a
    >
       
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="recaudacion_por_obligaciones.php?periodos=otros"
        role="button"
        >Otros periodos</a
    >
 
    </div>
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table
            class="table" 
        >
            <thead>
                <tr>
                    <th scope="col">Codigo</th>
                    <th scope="col">Nombre Obligación</th>
                    <th scope="col">Valor</th>
                    <th scope="col">Fecha de Creación</th>
                    <th scope="col">Fecha de vencimiento</th>
                    <th scope="col">.........</th>
                   
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_aportes as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['codigo']; ?></td>
                    <td><?php echo $registros['nombre']; ?></td>
                    <td><?php echo $registros['cantidad']; ?></td>
                    <td><?php echo $registros['creacion']; ?></td>
                    <td><?php echo $registros['vencimiento']; ?></td>
                    <td>
                    <a href="listar_deudas_obligacion.php?tabla=<?php echo $registros['tabla']; ?>&codigo=<?php echo $registros['codigo']; ?>">Por cobrar</a>
                    <a href="listar_deudas_obligacion_cobradas.php?tabla=<?php echo $registros['tabla']; ?>&codigo=<?php echo $registros['codigo']; ?>">Cobrados</a>
                    </td>
                  
                    
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
       

    </div>
   
</div>


<?php include("../../templates/footer.php"); ?>
<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[3,'desc']]});
} );

  </script>
