function imprimirSeleccion(nombre,direccion) {
    var ficha = document.getElementById(nombre);
    //DataTables_Table_0_filter
   var varhtml=document.getElementById('DataTables_Table_0_length').innerHTML;
   var varhtml_filtro=document.getElementById('DataTables_Table_0_filter').innerHTML;

   document.getElementById('DataTables_Table_0_length').innerHTML="";
   document.getElementById('DataTables_Table_0_filter').innerHTML="";
   
    var ventimp = window.open(' ', 'popimpr');
    ventimp.document.write( ficha.innerHTML );
    ventimp.document.close();
    ventimp.print( );
    ventimp.close();
   
    location.href =direccion;

}