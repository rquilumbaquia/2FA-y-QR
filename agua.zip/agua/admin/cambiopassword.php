

<script src="./js/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="./css/sweetalert2.min.css">
<link href="/agua/admin/libs/bootstrap-5.2.3-dist/css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
<script src="cambio_password.js" type="text/javascript"></script>
<link href="cambio_password.css"  rel="stylesheet" type="text/css">
<script src="cambio_password_funciones.js" type="text/javascript"></script>
<script  src="/agua/admin/js/jquery-3.6.3.min.js"
			  integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU="
			  crossorigin="anonymous">
</script>
<?php 
include("./bd.php");
date_default_timezone_set("America/Bogota");
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'self' ;form-action 'self' ");

/* funcion para comprobación de tiempo de expiración y generacion de un nuevo hash de contraseña
   y almacenamiento del hash en la base de datos  */

include("sesion.php");   
   if (!isset($_SESSION)) {
    correr_session(); 
   }   
if((isset($_POST['password-input']))&&(isset($_POST['password-input2']))&&(isset($_POST['id_acceso'])))
{    /* Recupera los datos del usuario de la base de datos*/
     $id_acceso=$_POST['id_acceso'];
     $sentencia_revision=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso AND codigo_recuperacion!='' ");
     $sentencia_revision->bindParam(':txtidacceso',$id_acceso);
     $sentencia_revision->execute();
     $lista_usuario=$sentencia_revision->fetch(PDO::FETCH_LAZY); 
     /* si existe un registro del usuario */
     if($sentencia_revision->rowCount()>0)
    {   /*Generamos el tiempo actual*/
        $hora_actual=date("His"); 
        $hora_recuperacion = new DateTime($lista_usuario['hora_recuperacion']);
        $hora_limite=($hora_recuperacion->format('His'))+300;
       /* comparamos el tiempo actual con el tiempo de expiracion */
    if(($hora_actual>$hora_limite))
    {
        $mensaje= "El tiempo ha expirado realice un nuevo proceso de recuperacion";
        $id_acceso=$_POST['id_acceso'];
        $sentencia=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion='',hora_recuperacion='',intentos='' WHERE id_acceso=:txtidacceso ");
        $sentencia->bindParam(':txtidacceso',$id_acceso);
        $sentencia->execute();
    }else{
        /* Caso contrario comparamos si las contraseña nuevas son iguales password1 password 2 */ 
        if($_POST['password-input']==$_POST['password-input2'])
       {
            /*Generamos un nuevo hash para la nueva contraseña */
            $timeTarget = 0.05; // 50 milisegundos 
            $coste = 8;
         do {
            $coste++;
            $inicio = microtime(true);
            password_hash("test", PASSWORD_BCRYPT, ["cost" => $coste]);
            $fin = microtime(true);
            }   while (($fin - $inicio) < $timeTarget);
               /*echo "Coste apropiado encontrado: " . $coste . "\n";*/
               $opciones = [
              'cost' => $coste,
                   ];
            $password=password_hash($_POST['password-input'], PASSWORD_BCRYPT, $opciones);
            /* fin de genración del hash */
            $id_acceso=$_POST['id_acceso'];
            $imagen_qr=(isset($_POST['imagen_qr']))?$_POST['imagen_qr']:"";
            /*Eliminamos el archivo QR antiguo */

            If ($imagen_qr!=$lista_usuario['imagen_qr']) {
              unlink("./libs/generadorqr/temp/".$lista_usuario['imagen_qr']);
              echo "Archivo eliminado correctamente";            
            } else {echo "No se elimina";}
            /*Actualizamos la base de datos del usuario con un nuevo hash de contraseña */                   
            $sentencia=$conexion->prepare("UPDATE usuario_acceso SET password=:txtpassword,imagen_qr=:txtimagen,codigo_recuperacion='',hora_recuperacion='',intentos='' WHERE id_acceso=:txtidacceso AND codigo_recuperacion<>''");
            $sentencia->bindParam(':txtpassword',$password);
            $sentencia->bindParam(':txtimagen',$imagen_qr);
            $sentencia->bindParam(':txtidacceso',$id_acceso);
            $sentencia->execute();
            $mensaje="El cambio de contraseña se ha realizado corretamente";
        }else{           
            /*si el password no es igual */
            $mensaje="El Password no es igual";}
    }
    }else{$mensaje="el registro ya ha sido alterado(No se realiza ningun cambio)";}
}
/*funcion de recepción de codigo de recuperacion y despliegue de formulario de cambio de contraseña */
if((isset($_POST['id_acceso']))&&(isset($_POST['codigo_recuperacion'])))
{   /*Recuperacion del usuario de la base de datos con el codigo de recuperacion */
    $id_acceso=$_POST['id_acceso'];
    $codigo=$_POST['codigo_recuperacion'];
    $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->execute();
    $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);
    /*Verificamos el Hash del codigo con el codigo ingresado*/
    if (password_verify($codigo, $lista_usuario['codigo_recuperacion']))    {
    
            /*Generamos la hora actual */
            $hora_actual=date("His"); 
            $valor=$lista_usuario['hora_recuperacion'];
            $hora_recuperacion = new DateTime($valor);
            $hora_limite=($hora_recuperacion->format('His'))+300;
            /*Verificamos la expiración por tiempo del codigo de recuperación */
            if(($hora_actual>$hora_limite))
            {
          $mensaje= "El tiempo ha expirado realice un nuevo proceso de recuperacion";
          $id_acceso=$_POST['id_acceso'];
          $sentencia=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion='',hora_recuperacion='' WHERE id_acceso=:txtidacceso ");
          $sentencia->bindParam(':txtidacceso',$id_acceso);
          $sentencia->execute();
            }else{/* si no existe incomvenientes desplegamos el formulario de restablecimiento de contraseña */
    ?>
   
  <svg xmlns="" style="display: none;">
  <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
  </symbol>
  <symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
  </symbol>
  <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
    <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
  </symbol>
  </svg>
        <div class="card">
        <div class="card-header">Cambio de contraseña del Usuario: <?php echo $lista_usuario['login'] ?></div>
        <div class="card-body">
            
        <form action="" method="post" class="" >
        <input
        type="hidden"
        name="csrf_token"
        id="csrf_token"
        value="<?php
        if(isset($_SESSION['tocte'])){
        echo  $_SESSION['tocte'];
        }
      
      ?>"
      />  

        <input
        type="hidden"
        id="login"
        name="login"
        value="<?php echo $lista_usuario['login'] ?>"
      />
    
<label for="password-input" class="form-label">Contraseña</label>    
<div class="row">
<div class="col-6">
  <div class="input-group d-flex">
    <span
      class="input-group-text border-0"
      id="password"
      >
    </span>

     
         <input
        type="password"
        class="form-control rounded mt-1"
        placeholder="Ingrese su contraseña nueva"
        aria-label="password"
        aria-describedby="password"
        id="password-input"
        name="password-input"
      />
        <script>
        //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
        $('#password-input').on('input', function () { 
        this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
        });
        </script> 
            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword('password-input')">            
            <span class="fa fa-eye-slash icon"></span>           
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
            </svg>
            
          </button>
                  
       <div class="valid-feedback">Fortaleza Bueno</div>
      <div class="invalid-feedback">Fortaleza Malo</div>
    </div>
  </div>

  <div class="col-6 mt-4 mt-xxl-0 w-auto h-auto">

    <div
      data-mdb-alert-init class="alert px-4 py-3 mb-0 d-none"
      role="alert"
      data-mdb-color="warning"
      id="password-alert"
      >
      <ul class="list-unstyled mb-0">
        <li class="requirements leng">
        Su contraseña debe tener al menos 12 caracteres
          <i class="fa fa-check text-success me-2" >
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>

          <i class="fa fa-times text-danger me-3" ></i>
          </li>
        <li class="requirements big-letter">
        Su password debe tener al menos una letra mayuscula.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
        <li class="requirements num">
        Su contraseña debe tener al menos un numero.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
        <li class="requirements special-char">
        su contraseña debe tener al menos un caracter especial.
          <i class="fa fa-check text-success me-2">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
          </i>
          <i class="fa fa-times text-danger me-3"></i>
          </li>
      </ul>
    </div>

  </div>
</div>
       
<label for="password-input2" class="form-label">Contraseña</label>    
<div class="row">
<div class="col-6">
  <div class="input-group d-flex">
     <span
      class="input-group-text border-0"
      id="password"
      >  
      </span>
     
      <input
       type="password"
       class="form-control rounded mt-1"
       placeholder="Repita su contraseña nueva"
       aria-label="password"
       aria-describedby="password"
       id="password-input2"
       name="password-input2"
      />
      <script>
      //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
      $('#password-input2').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
      });
      </script>      
      <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPassword('password-input2')"> 
      <span class="fa fa-eye-slash icon"></span> 
         
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
            <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z"/>
            <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"/>
            </svg>            
       </button>      
  </div>
</div>
</div>
                <input
                   type="hidden"
                   value="<?php echo $_POST['id_acceso'];  ?>"
                   name="id_acceso"
                   id="id_acceso"
                   aria-describedby="helpId"
                />
<!-- Modal -->
    <!-- Button trigger modal -->
    <button type="button" 
class="btn btn-primary" 
data-bs-toggle="modal" 
data-bs-target="#exampleModal"
title="Generar Codigo QR para el usuario"
onclick="validarUsuario()"
>  Generar clave
</button>

<!-- Scrollable modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ventana de Reestablecimiento de codigo QR</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="cerrar_modal" name="cerrar_modal"></button>
      </div>
      <div class="modal-body" id="divimagen" >
        
      <div id="mensajetotal" ></div>
      </div>
      <div class="modal-footer">
        
        <button type="submit" class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Guardar el Usuario" name="guardar " id="guardar">Guardar</button>
      </div>
    </div>
  </div>
</div>

                </form>

                <div class="card-footer text-muted">

                 </div>
            </div>
        </div>
        </div>
           <?php 
           
            }

        }else {
           
            $mensaje="El codigo de acceso es incorecto";}   
}

if(isset($mensaje)){ echo "Existe alertas";}       
          
           ?>

<script>
    <?php if(isset($mensaje)){  ?>
    swal.fire({icon:"success", title:"<?php echo $mensaje; ?>",confirmButtonColor: "#3085d6",
    confirmButtonText: "Si?"}).then((result) => {
  if (result.isConfirmed) {
    window.location.href = "login.php";
  }
});
    <?php } ?>
</script>
<script src="/agua/admin/libs/bootstrap-5.2.3-dist/js/bootstrap.js" >
  </script>
<script>
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

var myModal = document.getElementById('exampleModal')
var myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', function () {
  myInput.focus()
})
</script>