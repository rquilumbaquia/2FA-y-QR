<?php 
include("../../bd.php");
include("../../templates/header.php");
/* seleccionar obligaciones del periodo */
$fecha_inicio=$_SESSION['f_inicio_periodo'];
$fecha_final=$_SESSION['f_final_periodo'];

$sentencia=$conexion->prepare("SELECT id_obligacion_llave,nombre_obligacion FROM obligacion_por_llave where fecha_creacion>=:txtfcreacion AND fecha_vencimiento<=:txtfechafin  " );
$sentencia->bindParam(':txtfcreacion',$fecha_inicio);
$sentencia->bindParam(':txtfechafin',$fecha_final);
$sentencia->execute();
$lista_meses=$sentencia->fetchAll(PDO::FETCH_ASSOC);

$sentencia_por_usuario=$conexion->prepare("SELECT id_obligacion_usuario,nombre_obligacion FROM obligacion_por_usuario where fecha_creacion>=:txtfcreacion AND fecha_vencimiento<=:txtfechafin  " );
$sentencia_por_usuario->bindParam(':txtfcreacion',$fecha_inicio);
$sentencia_por_usuario->bindParam(':txtfechafin',$fecha_final);
$sentencia_por_usuario->execute();
$lista_por_usuario=$sentencia_por_usuario->fetchAll(PDO::FETCH_ASSOC);
/*seleccionar lista de usuarios */
$sentencia_usuario=$conexion->prepare("SELECT id_usuario,nombres,apellidos,direccion FROM usuarios WHERE usuarios.estado='activo'  ");
$sentencia_usuario->execute();
$total=$sentencia_usuario->rowCount();
$lista=$sentencia_usuario->fetchAll(PDO::FETCH_ASSOC);

?>
 <link rel="stylesheet" type="text/css" href="mi_estilo.css">

 <script src="reportes.js"></script>
<a href="javascript:imprimirSeleccion('div_print','reporte_por_obligaciones.php')" >Imprimir</a>
 <div id="div_print">
 
<div class="card-header d-flex flex-grow-1 justify-content-center " >
   <h6>JUNTA DE AGUA POTABLE Y ALCANTARILLADO PIJAL</h6>
</div>
    Reporte General de pagos por Usuario<br>
    ..................................................................
<table class="table table-bordered" >
            <thead>
                <tr class="table-primary">
                    
                    <th ><div class="size_nombres" >NOMBRES Y APELLIDOS</div><br></th>
                    <th scope="col" class="size_nombres" ><div>DIRECCION</div><br></th>
                    <th scope="col" ><div class="darvuelta-text size_pagos">DEUDAS ANTERIORES</div><br></th>
                    <?php foreach($lista_por_usuario as $registros_usuarios){ ?>
                        <th><div class="darvuelta-text size_pagos"> <?php echo strtoupper($registros_usuarios['nombre_obligacion'])."" ?></div><br></th>  
                    <?php  }?>
                    <?php foreach($lista_meses as $registros_meses){ ?>
                        <th  ><div class="darvuelta-text size_pagos"><?php echo strtoupper($registros_meses['nombre_obligacion']) ?></div><br></th>  
                    <?php  }?>
                    <th scope="col" ><div class="darvuelta-text">TOTAL PAGADO</div><br></th>
                    <th scope="col" ><div class="darvuelta-text">TOTAL DEUDA</div><br></th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $total_pagado_usuario=0; $total_debe_usuario=0; $total_deuda_anterior=0;?>
            <?php foreach($lista as $registros){ ?> <?php $total_pagado_usuario=0; $total_debe_usuario=0; ?>
                <tr  class="table-secondary">
                    
                    <td><?php echo $registros['apellidos']." "; ?><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td>
                    <?php 
                    
                    /* consulta de deudas */
                    $total_deuda_anterior=0;
                    $fecha_inicio=$_SESSION['f_inicio_periodo'];
                    $id_usuario=$registros['id_usuario'];
                    $sentencia_deuda_llave=$conexion->prepare("SELECT sum(aporte_llave.pagar)as deuda from usuarios,llaves,obligacion_por_llave,aporte_llave where usuarios.id_usuario=:txtidusuario and llaves.id_usuario=usuarios.id_usuario and aporte_llave.id_llave=llaves.id_llave  and aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave and aporte_llave.observacion='Solo asignado' and obligacion_por_llave.fecha_creacion < :txtfinicio ");
                    $sentencia_deuda_llave->bindParam(':txtidusuario',$id_usuario);
                    $sentencia_deuda_llave->bindParam(':txtfinicio',$fecha_inicio);
                    $sentencia_deuda_llave->execute();
                    $lista_deuda_llave=$sentencia_deuda_llave->fetch(PDO::FETCH_LAZY);
                    if($sentencia_deuda_llave->rowCount()>0)
                    {
                         if($lista_deuda_llave['deuda']>0){
                        echo  "Tarifas ".number_format($lista_deuda_llave['deuda'], 2, '.', '');
                      }
                    
                    $total_deuda_anterior=$total_deuda_anterior+$lista_deuda_llave['deuda'];
                    }
                    $fecha_inicio=$_SESSION['f_inicio_periodo'];
                    $id_usuario=$registros['id_usuario'];
                    $sentencia_deuda_cuota=$conexion->prepare("select sum(aporte_por_usuario.pagar) as deuda_cuota from aporte_por_usuario,obligacion_por_usuario where aporte_por_usuario.id_usuario=:txtidusuario and obligacion_por_usuario.id_obligacion_usuario=aporte_por_usuario.id_obligacion_usuario and obligacion_por_usuario.fecha_creacion < :txtfinicio and aporte_por_usuario.observacion='Solo asignado' ");
                    $sentencia_deuda_cuota->bindParam(':txtidusuario', $id_usuario);
                    $sentencia_deuda_cuota->bindParam(':txtfinicio',$fecha_inicio);
                    $sentencia_deuda_cuota->execute();
                    $lista_deuda_cuota=$sentencia_deuda_cuota->fetch(PDO::FETCH_LAZY);
                    if($sentencia_deuda_cuota->rowCount()>0)
                    {
                         if($lista_deuda_cuota['deuda_cuota']>0){ 
                             

                         echo  "Cuotas ".number_format($lista_deuda_cuota['deuda_cuota'], 2, '.', '');
                        }
                        $total_deuda_anterior=$total_deuda_anterior+$lista_deuda_cuota['deuda_cuota'];
                    
                    }
                    
                    if($total_deuda_anterior>0){ 
                        echo  "<br>Total ". number_format($total_deuda_anterior, 2, '.', '');
                      }
                    ?>
                    </td>
                    <?php foreach($lista_por_usuario as $registros_usuarios){ ?>
                        <td align="center"><?php
                            $id_obligacion=$registros_usuarios['id_obligacion_usuario'];
                            $id_usuario=$registros['id_usuario'];
                            $sentencia_consulta=$conexion->prepare("SELECT id_aporte,pagar,valor_pago,observacion FROM aporte_por_usuario WHERE id_obligacion_usuario=:txtidobligacion and id_usuario=:txtidusuario ");
                            $sentencia_consulta->bindParam(':txtidobligacion',$id_obligacion);
                            $sentencia_consulta->bindParam(':txtidusuario',$id_usuario);
                            $sentencia_consulta->execute();
                            $lista_consulta=$sentencia_consulta->fetch(PDO::FETCH_LAZY);
                             if($sentencia_consulta->rowCount()>0)
                            {
                                if(($lista_consulta['observacion'])=='Pagado')
                                {
                                    $total_pagado_usuario=$total_pagado_usuario+$lista_consulta['valor_pago'];
                                echo "(P ".number_format($lista_consulta['valor_pago'], 2, '.', '').")<br>";  
                                 }else{
                                    
                                    $total_debe_usuario=$total_debe_usuario+$lista_consulta['pagar'];
                                    echo "(Db ".number_format($lista_consulta['pagar'], 2, '.', '').")<br>";}

                            }else{echo "X";} 
                                                        
                            ?>  </td>  
                    <?php  }?>
                    <?php foreach($lista_meses as $registros_meses){ ?>
                        <td align="center"><?php 
                            
                            $id_obligacion=$registros_meses['id_obligacion_llave'];
                            $id_usuario=$registros['id_usuario'];
                            $sentencia_consulta_llave=$conexion->prepare("SELECT aporte_llave.id_aporte,aporte_llave.pagar,aporte_llave.valor_pago,aporte_llave.observacion FROM aporte_llave,llaves,usuarios WHERE usuarios.id_usuario=:txtusuario and aporte_llave.id_obligacion_llave=:txtidobligacion and llaves.id_usuario=usuarios.id_usuario and llaves.id_llave=aporte_llave.id_llave  ");
                            $sentencia_consulta_llave->bindParam(':txtusuario',$id_usuario);
                            $sentencia_consulta_llave->bindParam(':txtidobligacion',$id_obligacion);
                            $sentencia_consulta_llave->execute();
                            $lista_consulta_llave=$sentencia_consulta_llave->fetchAll(PDO::FETCH_ASSOC);
                             if($sentencia_consulta_llave->rowCount()>0)
                             {
                           
                                foreach($lista_consulta_llave as $registros_meses_llave){

                                    if($registros_meses_llave['observacion']=="Pagado")
                                    {
                                        $total_pagado_usuario=$total_pagado_usuario+$registros_meses_llave['valor_pago'];
                                        echo "(P ". number_format($registros_meses_llave['valor_pago'], 2, '.', '').")<br>"; }else{
                                            $total_debe_usuario=$total_debe_usuario+$registros_meses_llave['pagar'];
                                            echo "(Db ". number_format($registros_meses_llave['pagar'], 2, '.', '').")<br>"; }
                                }    

                             }else{echo "X";}
                            ?>  </td>  

                            
                    <?php  }?>
                    
                    <td><?php echo number_format($total_pagado_usuario, 2, '.', '') ?></td>
                    <td><?php echo number_format($total_debe_usuario, 2, '.', '') ?>
                    <?php if($total_deuda_anterior>0){ echo "<br>Anterior".number_format($total_deuda_anterior, 2, '.', ''); } ?></td>
                    
                </tr>
            <?php  } ?>    
               
            </tbody>
        </table>

 </div>
<?php 

?>

<?php include("../../templates/footer.php"); ?>

<script>
$(document).ready( function () {
    $('table').DataTable({"pageLength":<?php echo $total ?>,lengthMenu:[[<?php echo $total ?>,3,10,25,50],[<?php echo $total ?>,3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[1,'asc']]});
} );

</script>
