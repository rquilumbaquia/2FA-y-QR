<?php
$token = "7084814997:AAFS-UP0rERRd5prgYIpXH3c3fqUtZkly00";
$id = "6309661709";


$urlMsg = "https://api.telegram.org/bot{$token}/sendMessage";
$msg="hola saludos anonimo";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlMsg);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "chat_id={$id}&parse_mode=HTML&text=$msg");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
$server_output = curl_exec($ch);
curl_close($ch);
echo $urlMsg;

?>