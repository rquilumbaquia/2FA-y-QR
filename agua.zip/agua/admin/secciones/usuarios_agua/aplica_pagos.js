var plano;

function creaObjetoAjax () { //Mayoría de navegadores
    var obj;
    if (window.XMLHttpRequest) {
       obj=new XMLHttpRequest();
       }
    else { //para IE 5 y IE 6
       obj=new ActiveXObject(Microsoft.XMLHTTP);
       }
    return obj;
    }

function poner_pago_llave_cuota(id_aporte,pagar,tarifa_cuota,accion)
{
   
   
   if(document.getElementById("pago").value=='efectivo')
   {
      pago='efectivo';  
   }
   else{ pago=document.getElementById("txtdeposito").value; }

   

  
   plano=tarifa_cuota+""+id_aporte;
     //datos para el envio por POST:
   misdatos="id_aporte="+id_aporte+"&pagar="+pagar+"&tarifa_cuota="+tarifa_cuota+"&accion="+accion+"&deposito="+pago;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","check_pagos.php",true);
   //Enviar cabeceras para que acepte POST:

   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_poner;
   objetoAjax.send(misdatos);

 } 
function recogeDatos_poner() 
{

   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        document.getElementById(plano).innerHTML=miTexto;
   }
                                
}

function poner_deposito(opcion)

{
   if(opcion.value=="deposito"){

      document.getElementById("divdeposito").innerHTML="<input type='text' value='deposito'id='txtdeposito' name='txtdeposito' size='8'  />";

   }else{

      document.getElementById("divdeposito").innerHTML="";

    }
   


}



function cambiar_valor(valor,id_aporte)
{

    
    // Función que envía y recibe respuesta con AJAX
    $.ajax({
     type: 'POST',  // Envío con método POST
     url: 'cambiar_valor.php',  // Fichero destino (el PHP que trata los datos)
     data: { valor: valor,id_aporte:id_aporte } // Datos que se envían
     }).done(function( msg ) { // Función que se ejecuta si todo ha ido bien
      $("#txt"+id_aporte).val(msg);  // Escribimos en el div consola el mensaje devuelto
     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
     // Mostramos en consola el mensaje con el error que se ha producido
   
     $("#txt"+id_aporte).val("The following error occured: "+ textStatus +" "+ errorThrown); 
    });


}






