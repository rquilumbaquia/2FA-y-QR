<?php include("templates/header.php"); ?>

  <div class="p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5">
           
      <div class="card-header">


      Bienvenido al Sistemas Administrador de agua potable y alcantarillado JAAPYS  su nombre y rol es 
      <?php 
      if((isset($_SESSION['usuario']))&&($_SESSION['usuario']!='')){
      echo $_SESSION['usuario']."  ".ucwords($_SESSION['cargo']); 
    }
      ?>
        
      </div>
    </div>
  </div>

<?php include("templates/footer.php"); ?>

