<?php include("../../bd.php"); ?>
<?php include("../../templates/header.php"); ?>
<?php 

$fecha_inicio=$_SESSION['f_inicio_periodo'];
$fecha_final=$_SESSION['f_final_periodo'];


$sentencia=$conexion->prepare("SELECT * FROM obligacion_por_llave where fecha_creacion>=:txtfcreacion AND fecha_vencimiento<=:txtfechafin AND tarifa_mes='si' " );
$sentencia->bindParam(':txtfcreacion',$fecha_inicio);
$sentencia->bindParam(':txtfechafin',$fecha_final);
$sentencia->execute();


$lista_meses=$sentencia->fetchAll(PDO::FETCH_ASSOC);


?>

<table
            class="table" 
        >
            <thead>
                <tr>
                    
                    <th scope="col">Nombre Obligación</th>
                    <th scope="col">Valor</th>
                    <th scope="col">desde</th>
                    <th scope="col">Hasta</th>
                    
                    <th scope="col">Tipo</th>
                    <th scope="col">Tarifa Mes</th>
                    <th scope="col">Lectura fin de Mes</th>
                    
                   
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_meses as $registros){ ?>
                <tr class="">
                   
                    <td><?php echo $registros['nombre_obligacion']; ?></td>
                    <td><?php echo $registros['valor']; ?></td>
                    <td><?php echo $registros['fecha_creacion']; ?></td>
                    <td><?php echo $registros['fecha_vencimiento']; ?></td>
                    
                    <td><?php echo $registros['opcion']; ?></td>
                    <td><?php echo $registros['tarifa_mes']; ?></td>
                    <td><a href="crear.php?id_obligacion_llave=<?php echo $registros['id_obligacion_llave'] ?>">Ingresar</a></td>
                   
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>




<?php include("../../templates/footer.php"); ?>

 