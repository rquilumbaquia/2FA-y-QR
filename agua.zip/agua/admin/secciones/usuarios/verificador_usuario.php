<?php  
include("../../bd.php");

if($_POST['campo']=="correo")
{
$mystring = $_POST['valor'];
$findme   = '@';
$pos = strpos($mystring, $findme);
if ($pos === false) {
    echo "error";
    }else{
        $valor=$_POST['valor']; 
        $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso where correo=:txtcorreo AND activo='si' ");
        $sentencia->bindParam(':txtcorreo',$valor);
        $sentencia->execute();
        $sentencia->rowCount();
        $lista=$sentencia->fetch(PDO::FETCH_LAZY);
     if(($sentencia->rowCount())>0){ echo "si"; }       
    }
}
if($_POST['campo']=="login")
{
$valor=$_POST['valor']; 
$sentencia=$conexion->prepare("SELECT * FROM usuario_acceso where login=:txtlogin ");
$sentencia->bindParam(':txtlogin',$valor);
$sentencia->execute();
$sentencia->rowCount();
$lista=$sentencia->fetch(PDO::FETCH_LAZY);

if(($sentencia->rowCount())>0){
echo "si";

}

}




?>

