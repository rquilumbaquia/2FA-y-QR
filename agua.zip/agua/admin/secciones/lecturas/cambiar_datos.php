<?php include("../../bd.php"); ?>

<?php 
if($_POST){
 
    if($_POST['campo']=="sector"){
        $id_llave=$_POST['id_llave'];
        $valor=$_POST['valor'];
        $sentencia_poner=$conexion->prepare("UPDATE llaves SET sector=:txtsector where id_llave=:txtid_llave " );
        $sentencia_poner->bindParam(':txtsector', $valor);
        $sentencia_poner->bindParam(':txtid_llave', $id_llave);
        $sentencia_poner->execute();

        $sentencia_revisar=$conexion->prepare("SELECT * FROM llaves where id_llave=:txtidllave " );
        $sentencia_revisar->bindParam(':txtidllave',$id_llave);
        $sentencia_revisar->execute();
        $lista=$sentencia_revisar->fetch(PDO::FETCH_LAZY);
        ?>
        
        <input type="text" 
        name="txtsector<?php echo $lista['id_llave'] ?>" 
        id="txtsector<?php echo $lista['id_llave'] ?>" 
        value="<?php echo $lista['sector'] ?>" 
        onchange="cambiar_datos('<?php echo $lista['id_llave'] ?>',this.value,'sector');"  
        class="text-primary" 
        size="10"
        />

       <?php
    }

    if($_POST['campo']=="codigo_medidor"){
        $id_llave=$_POST['id_llave'];
        $valor=$_POST['valor'];
        $sentencia_poner=$conexion->prepare("UPDATE llaves SET codigo_medidor=:txtcodigo where id_llave=:txtid_llave " );
        $sentencia_poner->bindParam(':txtcodigo', $valor);
        $sentencia_poner->bindParam(':txtid_llave', $id_llave);
        $sentencia_poner->execute();

        $sentencia_revisar=$conexion->prepare("SELECT * FROM llaves where id_llave=:txtidllave " );
        $sentencia_revisar->bindParam(':txtidllave',$id_llave);
        $sentencia_revisar->execute();
        $lista=$sentencia_revisar->fetch(PDO::FETCH_LAZY);

        ?>
        
        <input type="text" name="txtcodigo_medidor<?php echo $lista['id_llave'] ?>" 
        id="txtcodigo_medidor<?php echo $lista['id_llave'] ?>" 
        value="<?php echo $lista['codigo_medidor'] ?>" 
        onchange="cambiar_datos('<?php echo $lista['id_llave'] ?>',this.value,'codigo_medidor');"  
        class="text-primary" size="5" />

       <?php



    }
   
    
}   

?>