<?php 
include("../../bd.php");
include("../../templates/header.php"); 
?>
<script src="aplica_pagos.js" ></script>
<script src="../../libs/CalendarControl.js" type="text/javascript" ></script>
<link href="../../libs/CalendarControl.css"  rel="stylesheet" type="text/css">
<?php

if((isset($_GET['csrf_token']))&&($_GET['csrf_token']==$_SESSION['tocte'])){

function diasEntreFechas($fechainicio, $fechafin)
   {
    $dias=((strtotime($fechafin)-strtotime($fechainicio))/86400);
   if ($dias>0)
    {
    return $dias;
    }else{return 0;}
 }

 if ((isset($_GET['id_usuario'])))
    {
   
      $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
      $sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios WHERE id_usuario=:txtidusuario");
      $sentencia_usuario->bindParam(':txtidusuario',$id_usuario);
      $sentencia_usuario->execute();
      $lista_usuario=$sentencia_usuario->fetch(PDO::FETCH_LAZY);
      
    }
if($_GET)
{
    if ((!isset($_GET['listar'])))
    {
        $_GET['listar']="Solo asignado"; 
    }
   if ((isset($_GET['listar']))&&(($_GET['listar']=="Solo asignado")))
    {
      $listar=$_GET['listar'];
      $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
      $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, llaves.id_llave, llaves.sector, aporte_llave.id_aporte, obligacion_por_llave.id_obligacion_llave, obligacion_por_llave.nombre_obligacion, aporte_llave.f_pago, aporte_llave.f_asignacion, aporte_llave.medidor, aporte_llave.observacion, obligacion_por_llave.fecha_creacion, obligacion_por_llave.fecha_vencimiento, obligacion_por_llave.valor, aporte_llave.pagar, aporte_llave.valor_pago, aporte_llave.deposito FROM usuarios, llaves, aporte_llave, obligacion_por_llave WHERE usuarios.id_usuario = :txtidusuario   AND llaves.id_usuario=usuarios.id_usuario AND llaves.id_llave=aporte_llave.id_llave  AND aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave AND aporte_llave.observacion=:txtobservacion  ORDER BY obligacion_por_llave.fecha_creacion, llaves.id_llave ");
      $sentencia->bindParam(':txtidusuario',$id_usuario);
      $sentencia->bindParam(':txtobservacion',$listar);
      $sentencia->execute();
      $lista_pagos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
      $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
      $sentencia_couta=$conexion->prepare("SELECT aporte_por_usuario.id_aporte, aporte_por_usuario.id_usuario, aporte_por_usuario.f_pago, aporte_por_usuario.f_asignacion, aporte_por_usuario.pagar, aporte_por_usuario.valor_pago, aporte_por_usuario.deposito, aporte_por_usuario.id_acceso, aporte_por_usuario.id_obligacion_usuario, aporte_por_usuario.observacion, obligacion_por_usuario.nombre_obligacion, obligacion_por_usuario.valor, obligacion_por_usuario.fecha_creacion, obligacion_por_usuario.fecha_vencimiento FROM aporte_por_usuario, obligacion_por_usuario WHERE aporte_por_usuario.id_usuario =:txtidusuario  AND aporte_por_usuario.id_obligacion_usuario=obligacion_por_usuario.id_obligacion_usuario AND  aporte_por_usuario.observacion=:txtobservacion ");
      $sentencia_couta->bindParam(':txtidusuario',$id_usuario);
      $sentencia_couta->bindParam(':txtobservacion',$listar);
      $sentencia_couta->execute();
      $lista_pagos_cuota=$sentencia_couta->fetchAll(PDO::FETCH_ASSOC);
      $ordenar="asc";
    }
    if ((isset($_GET['listar']))&&(($_GET['listar']=="Periodo")))
    {
        $f_inicio= $_SESSION['f_inicio_periodo'];
        $f_final= $_SESSION['f_final_periodo'];
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, llaves.id_llave, llaves.sector, aporte_llave.id_aporte, obligacion_por_llave.id_obligacion_llave, obligacion_por_llave.nombre_obligacion, aporte_llave.f_pago, aporte_llave.f_asignacion, aporte_llave.medidor, aporte_llave.observacion, obligacion_por_llave.fecha_creacion, obligacion_por_llave.fecha_vencimiento, obligacion_por_llave.valor, aporte_llave.pagar, aporte_llave.valor_pago, aporte_llave.deposito FROM usuarios, llaves, aporte_llave, obligacion_por_llave WHERE usuarios.id_usuario = :txtidusuario   AND llaves.id_usuario=usuarios.id_usuario AND llaves.id_llave=aporte_llave.id_llave  AND aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave AND obligacion_por_llave.fecha_creacion>=:txtfechainicio AND obligacion_por_llave.fecha_creacion<=:txtfechafin  ORDER BY obligacion_por_llave.fecha_creacion, llaves.id_llave ");
        $sentencia->bindParam(':txtidusuario',$id_usuario);
        $sentencia->bindParam(':txtfechainicio',$f_inicio);
        $sentencia->bindParam(':txtfechafin',$f_final);
        $sentencia->execute();
        $lista_pagos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia_couta=$conexion->prepare("SELECT aporte_por_usuario.id_aporte, aporte_por_usuario.id_usuario, aporte_por_usuario.f_pago, aporte_por_usuario.f_asignacion, aporte_por_usuario.pagar, aporte_por_usuario.valor_pago, aporte_por_usuario.deposito, aporte_por_usuario.id_acceso, aporte_por_usuario.id_obligacion_usuario, aporte_por_usuario.observacion, obligacion_por_usuario.nombre_obligacion, obligacion_por_usuario.valor, obligacion_por_usuario.fecha_creacion, obligacion_por_usuario.fecha_vencimiento FROM aporte_por_usuario, obligacion_por_usuario WHERE aporte_por_usuario.id_usuario =:txtidusuario  AND aporte_por_usuario.id_obligacion_usuario=obligacion_por_usuario.id_obligacion_usuario AND  obligacion_por_usuario.fecha_creacion>=:txtfechainicio AND obligacion_por_usuario.fecha_creacion<=:txtfechafin ");
        $sentencia_couta->bindParam(':txtidusuario',$id_usuario);
        $sentencia_couta->bindParam(':txtfechainicio',$f_inicio);
        $sentencia_couta->bindParam(':txtfechafin',$f_final);
        $sentencia_couta->execute();
        $lista_pagos_cuota=$sentencia_couta->fetchAll(PDO::FETCH_ASSOC); 
        $ordenar="asc";

    }
    if ((isset($_GET['listar']))&&(($_GET['listar']=="Anteriores")))
    {
        
        $f_inicio= $_GET['anterior'];
        $f_final= $_SESSION['f_final_periodo'];
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, llaves.id_llave, llaves.sector, aporte_llave.id_aporte, obligacion_por_llave.id_obligacion_llave, obligacion_por_llave.nombre_obligacion, aporte_llave.f_pago, aporte_llave.f_asignacion, aporte_llave.medidor, aporte_llave.observacion, obligacion_por_llave.fecha_creacion, obligacion_por_llave.fecha_vencimiento, obligacion_por_llave.valor, aporte_llave.pagar, aporte_llave.valor_pago, aporte_llave.deposito FROM usuarios, llaves, aporte_llave, obligacion_por_llave WHERE usuarios.id_usuario = :txtidusuario   AND llaves.id_usuario=usuarios.id_usuario AND llaves.id_llave=aporte_llave.id_llave  AND aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave AND obligacion_por_llave.fecha_creacion>=:txtfechainicio AND obligacion_por_llave.fecha_creacion<=:txtfechafin  ORDER BY obligacion_por_llave.fecha_creacion, llaves.id_llave ");
        $sentencia->bindParam(':txtidusuario',$id_usuario);
        $sentencia->bindParam(':txtfechainicio',$f_inicio);
        $sentencia->bindParam(':txtfechafin',$f_final);
        $sentencia->execute();
        $lista_pagos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
        
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia_couta=$conexion->prepare("SELECT aporte_por_usuario.id_aporte, aporte_por_usuario.id_usuario, aporte_por_usuario.f_pago, aporte_por_usuario.f_asignacion, aporte_por_usuario.pagar, aporte_por_usuario.valor_pago, aporte_por_usuario.deposito, aporte_por_usuario.id_acceso, aporte_por_usuario.id_obligacion_usuario, aporte_por_usuario.observacion, obligacion_por_usuario.nombre_obligacion, obligacion_por_usuario.valor, obligacion_por_usuario.fecha_creacion, obligacion_por_usuario.fecha_vencimiento FROM aporte_por_usuario, obligacion_por_usuario WHERE aporte_por_usuario.id_usuario =:txtidusuario  AND aporte_por_usuario.id_obligacion_usuario=obligacion_por_usuario.id_obligacion_usuario AND  obligacion_por_usuario.fecha_creacion>=:txtfechainicio AND obligacion_por_usuario.fecha_creacion<=:txtfechafin ");
        $sentencia_couta->bindParam(':txtidusuario',$id_usuario);
        $sentencia_couta->bindParam(':txtfechainicio',$f_inicio);
        $sentencia_couta->bindParam(':txtfechafin',$f_final);
        $sentencia_couta->execute();
        $lista_pagos_cuota=$sentencia_couta->fetchAll(PDO::FETCH_ASSOC); 
        $ordenar="asc";

    }
    if ((isset($_GET['listar']))&&(($_GET['listar']=="Pagados")))
    {
        
        
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia=$conexion->prepare("SELECT usuarios.id_usuario, llaves.id_llave, llaves.sector, aporte_llave.id_aporte, obligacion_por_llave.id_obligacion_llave, obligacion_por_llave.nombre_obligacion, aporte_llave.f_pago, aporte_llave.f_asignacion, aporte_llave.medidor, aporte_llave.observacion, obligacion_por_llave.fecha_creacion, obligacion_por_llave.fecha_vencimiento, obligacion_por_llave.valor, aporte_llave.pagar, aporte_llave.valor_pago, aporte_llave.deposito FROM usuarios, llaves, aporte_llave, obligacion_por_llave WHERE usuarios.id_usuario = :txtidusuario   AND llaves.id_usuario=usuarios.id_usuario AND llaves.id_llave=aporte_llave.id_llave  AND aporte_llave.id_obligacion_llave=obligacion_por_llave.id_obligacion_llave  AND aporte_llave.observacion='Pagado'  ORDER BY aporte_llave.f_pago desc ");
        $sentencia->bindParam(':txtidusuario',$id_usuario);
        $sentencia->execute();
        $lista_pagos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
        
        $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
        $sentencia_couta=$conexion->prepare("SELECT aporte_por_usuario.id_aporte, aporte_por_usuario.id_usuario, aporte_por_usuario.f_pago, aporte_por_usuario.f_asignacion, aporte_por_usuario.pagar, aporte_por_usuario.valor_pago, aporte_por_usuario.deposito, aporte_por_usuario.id_acceso, aporte_por_usuario.id_obligacion_usuario, aporte_por_usuario.observacion, obligacion_por_usuario.nombre_obligacion, obligacion_por_usuario.valor, obligacion_por_usuario.fecha_creacion, obligacion_por_usuario.fecha_vencimiento FROM aporte_por_usuario, obligacion_por_usuario WHERE aporte_por_usuario.id_usuario =:txtidusuario  AND aporte_por_usuario.id_obligacion_usuario=obligacion_por_usuario.id_obligacion_usuario AND aporte_por_usuario.observacion='Pagado' ORDER BY aporte_por_usuario.f_pago desc ");
        $sentencia_couta->bindParam(':txtidusuario',$id_usuario);
        $sentencia_couta->execute();
        $lista_pagos_cuota=$sentencia_couta->fetchAll(PDO::FETCH_ASSOC); 
        $ordenar="desc";

    }
  
}

?>
<style>

input {
  font-size: 0.875em;
}

</style>
<p ><?php echo $lista_usuario['apellidos']." ".$lista_usuario['nombres'] ?></p>

<!-- Horizontal under breakpoint -->
<ul 
    class="list-group list-group-horizontal" 
>
    <li class="list-group-item"><a href="pagos.php?id_usuario=<?php echo $_GET['id_usuario']; ?>&listar=Solo asignado&csrf_token=<?php echo $_SESSION['tocte']  ?>">Abligaciones Deudoras</a></li>
    <li class="list-group-item"><a href="pagos.php?id_usuario=<?php echo $_GET['id_usuario']; ?>&listar=Periodo&csrf_token=<?php echo $_SESSION['tocte']  ?>">Periodo Actual</a></li>
    <li class="list-group-item"><a href="pagos.php?id_usuario=<?php echo $_GET['id_usuario']; ?>&listar=Pagados&csrf_token=<?php echo $_SESSION['tocte']  ?>">Pagados</a></li>
    <li class="list-group-item" >
    Fechas Anteriores
    <form method="get" action="">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['tocte'] ?>" size="8" >
    <input type="text" name="anterior" value="" size="8"  onclick="showCalendarControl(this);">
    <input type="hidden" name="id_usuario" value="<?php echo $_GET['id_usuario'] ?>">
    <input type="submit" name="listar" value="Anteriores">
    </form>
</li>
    <li class="list-group-item">Pagar con : 
        
        <?php if($_SESSION['cargo']=='tesorero'){ ?>
        <select name="pago" id="pago" onchange="poner_deposito(this)">   
        <option value="efectivo"  >Efectivo</option>
        <option value="deposito">Deposito</option>              
       
        </select><div id="divdeposito"></div>    
        <?php }else{?>
            
            <select name="pago" id="pago" onchange="poner_deposito(this)">   
       
        <option value="deposito" selected >Deposito</option>              
       
        </select>
        <div id="divdeposito">
        <input type='text' value='deposito'id='txtdeposito' name='txtdeposito' size='8' 
        data-bs-toggle="tooltip"
        data-bs-placement="top" title="Ingrese aqui el numero de deposito de la papeleta"
        /> </div> <--aqui numero de deposito 
               
        <?php } ?>


    
    </li> 

</ul>
<br>
<table 
            class="table"
        >
            <thead>
                <tr>
                    <th scope="col">Codigo</th>
                    <th scope="col">Llave</th>
                    <th scope="col">Mes/Obligacion</th>
                    <th scope="col">Fecha Aplicacio</th>
                    <th scope="col">Desde</th>
                    <th scope="col">Hasta</th>
                    <th scope="col">Fecha de Pago</th>
                    <th scope="col">Consumo</th>
                    <th scope="col">Pagar</th>
                    <th scope="col">Mora</th>
                    <th scope="col">Valor Pagado</th>
                    <th>Pagó con                  
                    </th>
                    <th scope="col">Observacion</th>
                    <th>.</th>
                    <th>Facturas</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php $i=0;
                  
                  foreach($lista_pagos as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['id_aporte']; ?></td>
                    <td><?php echo $registros['sector']; ?></td>
                    <td><?php echo $registros['nombre_obligacion']; ?></td>
                    <td><?php echo $registros['f_asignacion']; ?></td>
                    <td><?php echo $registros['fecha_creacion']; ?></td>
                    <td><?php echo $registros['fecha_vencimiento']; ?></td>
                    <td><?php echo $registros['f_pago']; ?></td>
                    <td><?php echo $registros['medidor']; ?></td>
                    <td>
                      
                     <?php 
                     if($_SESSION['cargo']=='tesorero'){

                        ?>
                        <input id="txt<?php echo $registros['id_aporte'] ?>" type="text" value="<?php echo $registros['pagar']; ?>" onchange="cambiar_valor(this.value,'<?php echo $registros['id_aporte']; ?>')" size="4" />
                        <?php
                     }else{
                     echo $registros['pagar']; 
                    }
                     
                     ?>
                    </td>
                    <td><?php echo diasEntreFechas($registros['fecha_vencimiento'], date("Y-m-d")) ?></td>
                    <td><?php echo $registros['valor_pago']; ?></td>
                    <td><?php echo $registros['deposito']; ?></td>
                    <td><?php echo $registros['observacion']; ?></td>
                    <td>
                    <?php //echo $fecha_hoy=date("Y-m-d"); 
                    
                    ?>
                    <div id="tarifa<?php echo "".$registros['id_aporte']; ?>">
                    <?php if (($registros['observacion']=='Solo asignado')&&(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='coperativa'))){ ?>
                    <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" onchange="poner_pago_llave_cuota('<?php echo $registros['id_aporte']; ?>','<?php echo $registros['pagar']; ?>','tarifa','poner')" value="<?php echo $registros['id_aporte']; ?>">
                    <?php }  ?>
                    <?php if (($registros['observacion']=='Pagado')&&($registros['f_pago']==date("Y-m-d"))&&(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='coperativa'))){ ?>
                    <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" onchange="poner_pago_llave_cuota('<?php echo $registros['id_aporte']; ?>','<?php echo $registros['pagar']; ?>','tarifa','quitar')" value="<?php echo $registros['id_aporte']; ?>" checked>
                   <?php }  ?>
                    
                    <?php if (($registros['observacion']=='Pagado')&&($registros['f_pago']!=date("Y-m-d"))&&($_SESSION['cargo']=='coperativa'))
                    {  ?>
                    <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" checked disabled>
                     <?php } ?>

                     <?php if (($registros['observacion']=='Pagado')&&($registros['f_pago']!=date("Y-m-d"))&&($_SESSION['cargo']=='tesorero'))
                    {  ?>
                    <input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" onchange="poner_pago_llave_cuota('<?php echo $registros['id_aporte']; ?>','<?php echo $registros['pagar']; ?>','tarifa','quitar')" value="<?php echo $registros['id_aporte']; ?>" checked>
                    <?php } ?>
                    
                    </div>
                    </td>
                    <td align="center">
                        <?php 
                       
                       if(($i<>$registros['f_pago'])&&($registros['observacion']=='Pagado')){
                       echo "<a href='factura.php?csrf_token=".$_SESSION['tocte']."&id_usuario=".$_GET['id_usuario']."&f_pago=".$registros['f_pago']." '>".$registros['f_pago']."</a> ";
                       $i= $registros['f_pago'];  
                       }else{echo ".....";}

                       ?>
                       <?php ?>
                    </td>
                    
                </tr>
            <?php          } ?> 

            <?php $i=0;
                  foreach($lista_pagos_cuota as $registros_cuotas){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros_cuotas['id_aporte']; ?></td>
                    <td><?php echo ".Sector."; ?></td>
                    <td><?php echo $registros_cuotas['nombre_obligacion']; ?></td>
                    <td><?php echo $registros_cuotas['f_asignacion']; ?></td>
                    <td><?php echo $registros_cuotas['fecha_creacion']; ?></td>
                    <td><?php echo $registros_cuotas['fecha_vencimiento']; ?></td>
                    <td><?php echo $registros_cuotas['f_pago'];  ?></td>
                    <td><?php echo "Sin consumo.."; ?></td>
                    <td><?php echo $registros_cuotas['pagar']; ?></td>
                    <td><?php echo diasEntreFechas($registros_cuotas['fecha_vencimiento'], date("Y-m-d")) ?></td>
                    <td><?php echo $registros_cuotas['valor_pago']; ?></td>
                    <td><?php echo $registros_cuotas['deposito']; ?></td>
                    <td><?php echo $registros_cuotas['observacion']; ?></td>
                    <td>
                    <div id="cuota<?php echo "".$registros_cuotas['id_aporte']; ?>">
                    <?php if (($registros_cuotas['observacion']=='Solo asignado')&&(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='coperativa'))){ ?>
                    <input type="checkbox" name="check_cuota[]" id="check_cuota[]" onchange="poner_pago_llave_cuota('<?php echo $registros_cuotas['id_aporte']; ?>','<?php echo $registros_cuotas['pagar']; ?>','cuota','poner')">
                    <?php }  ?>

                    <?php if (($registros_cuotas['observacion']=='Pagado')&&($registros_cuotas['f_pago']==date("Y-m-d"))&&(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='coperativa'))){ ?>
                    <input type="checkbox" name="check_cuota[]" id="check_cuota[]" onchange="poner_pago_llave_cuota('<?php echo $registros_cuotas['id_aporte']; ?>','<?php echo $registros_cuotas['pagar']; ?>','cuota','quitar')" checked>
                    <?php }  ?>
                    <?php if (($registros_cuotas['observacion']=='Pagado')&&($registros_cuotas['f_pago']!=date("Y-m-d"))&&($_SESSION['cargo']=='coperativa'))
                    {
                       ?><input type="checkbox" name="check_tarifa[]" id="check_tarifa[]" checked disabled>
                       
                       <?php }  ?>


                       <?php if (($registros_cuotas['observacion']=='Pagado')&&($registros_cuotas['f_pago']!=date("Y-m-d"))&&($_SESSION['cargo']=='tesorero'))
                    {
                       ?>

                       <input type="checkbox" name="check_cuota[]" id="check_cuota[]" onchange="poner_pago_llave_cuota('<?php echo $registros_cuotas['id_aporte']; ?>','<?php echo $registros_cuotas['pagar']; ?>','cuota','quitar')" checked>

                       
                       <?php }  ?>   


                    </div></td>
                    <td align="center">
                        <?php 
       

                       if(($i<>$registros_cuotas['f_pago'])&&($registros_cuotas['observacion']=='Pagado')){
                        echo "<a href='factura.php?csrf_token=".$_SESSION['tocte']."&id_usuario=".$_GET['id_usuario']."&f_pago=".$registros_cuotas['f_pago']." '>".$registros_cuotas['f_pago']."</a> ";
                        $i=$registros_cuotas['f_pago'];
                       }else{echo ".....";}                        
                        
                        ?>
                    </td>                    
                </tr>                                               
            <?php          } ?>
               
            </tbody>
        </table>
<?php 
}
?>

<?php include("../../templates/footer.php"); ?>

<script>

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})


$(document).ready( function () {
    $('table').DataTable({"pageLength":15,lengthMenu:[[6,15,25,50],[6,15,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[4,'<?php echo $ordenar ?>']]});
} );

  </script>
