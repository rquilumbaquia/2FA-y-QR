
<?php 
include("../../../templates/header.php"); 
include("../../../bd.php");
if(($_GET))
{
    $id_obligacion_usuario=(isset($_GET['id_obligacion_usuario']))?$_GET['id_obligacion_usuario']:"";
       
    $sentencia=$conexion->prepare("DELETE FROM obligacion_por_usuario WHERE id_obligacion_usuario=:txtobligacionporusuario; ");
    $sentencia->bindParam(':txtobligacionporusuario',$id_obligacion_usuario);
    $sentencia->execute();

}
$sentencia=$conexion->prepare("SELECT * FROM obligacion_por_usuario ORDER BY fecha_creacion ASC  ");
$sentencia->execute();
$lista_aportes=$sentencia->fetchAll(PDO::FETCH_ASSOC);

?>

Lista para aplicacion de aportes
<div class="card">
    <div class="card-header">
    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?> 
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="crear.php"
        role="button"
        >Nuevo Aporte Usuario</a
    >
        <?php } ?>
    </div>
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table
            class="table" 
        >
            <thead>
                <tr>
                    <th scope="col">Id Obligacion</th>
                    <th scope="col">Nombre Obligación</th>
                    <th scope="col">Valor</th>
                    <th scope="col">Fecha de Creación</th>
                    <th scope="col">Fecha de vencimiento</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Aplicaciones</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_aportes as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['id_obligacion_usuario']; ?></td>
                    <td><?php echo $registros['nombre_obligacion']; ?></td>
                    <td><?php echo $registros['valor']; ?></td>
                    <td><?php echo $registros['fecha_creacion']; ?></td>
                    <td><?php echo $registros['fecha_vencimiento']; ?></td>
                    <td><?php echo $registros['opcion']; ?></td>
                    
                    <td>
                    <?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?> 
                    

                    <a
                        name=""
                        id=""
                        href="#"                       
                        >Editar</a
                    >
                   <a
                    name=""
                    id=""                   
                    href="index.php?id_obligacion_usuario=<?php echo $registros['id_obligacion_usuario'];  ?>"                    
                    >Eliminar</a
                   >
                   <a
                    name=""
                    id=""                   
                    href="aplicar.php?id_obligacion_usuario=<?php echo $registros['id_obligacion_usuario'];  ?>"                    
                    >Aplicar</a
                   >
                   <?php } ?>
                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
       

    </div>
   
</div>
<?php include("../../../templates/footer.php"); ?>
<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[3,'desc']]});
} );

  </script>

 