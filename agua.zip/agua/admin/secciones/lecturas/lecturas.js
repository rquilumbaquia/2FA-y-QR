var plano_cambiar;
var plano_consumo;
var plano_anterior;

function creaObjetoAjax () { //Mayoría de navegadores
    var obj;
    if (window.XMLHttpRequest) {
       obj=new XMLHttpRequest();
       }
    else { //para IE 5 y IE 6
       obj=new ActiveXObject(Microsoft.XMLHTTP);
       }
    return obj;
    }

function poner_lectura(id_aporte,dato,id_aporte_anterior,id_llave)
{
   plano="lectura"+id_aporte;
     //datos para el envio por POST:
  var misdatos="id_aporte="+id_aporte+"&lectura_actual="+dato.value+"&id_aporte_anterior="+id_aporte_anterior+"&id_llave="+id_llave;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","poner_lectura.php",true);
   //Enviar cabeceras para que acepte POST:
   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_poner;
   objetoAjax.send(misdatos);

 } 
function recogeDatos_poner() 
{

   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        
        document.getElementById(plano).innerHTML=miTexto;
   }
                                
}

function cambiar_datos(id_llave,valor,campo)
{
   plano_cambiar=campo+""+id_llave;
     //datos para el envio por POST:
  var misdatos="id_llave="+id_llave+"&valor="+valor+"&campo="+campo;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","cambiar_datos.php",true);
   //Enviar cabeceras para que acepte POST:
   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_cambiar_datos;
   objetoAjax.send(misdatos);

 } 
function recogeDatos_cambiar_datos() 
{

   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        
        document.getElementById(plano_cambiar).innerHTML=miTexto;
   }
                                
}



