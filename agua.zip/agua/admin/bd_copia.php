<?php 

$hostname_acceso = "mysql.webcindario.com";

$database_acceso = "juntadeaguapijal";

$username_acceso = "juntadeaguapijal";

$password_acceso = "Rqa123456**";
try{

    $conexion= new PDO("mysql:host=$hostname_acceso;dbname=$database_acceso;charset=utf8",$username_acceso,$password_acceso);
    

} catch(Exception $error){echo $error->getMessage(); }


?>