

<?php
//TOKEN QUE NOS DA FACEBOOK
$token = 'EAAea7Dc3DuEBOwW0SPhckmumVj6a5dFRKw9RyJIGTjMip19wTi1VJpSZBOuxtleUNViBkuvqUmDn22ZCSdVsOjiFGyLfa7OCcCZB2AxrCdPAn4jfGlVfYS3f7DI6wQfqsq5oZCYWoydL883dbUjgQLjKv72tcsLz10yhATYkJlhUjl6xvRAti7RpLHl8w6HeSYp59SxpAIpBIsA9b18ZD';
//NUESTRO TELEFONO
$telefono = '593968255549';
//URL A DONDE SE MANDARA EL MENSAJE
$url = 'https://graph.facebook.com/v19.0/349337234920618/messages';

//CONFIGURACION DEL MENSAJE
$mensaje = ''
        . '{'
        . '"messaging_product": "whatsapp", '
        . '"to": "'.$telefono.'", '
        . '"type": "template", '
        . '"template": '
        . '{'
        . '     "name": "hello_world",'
        . '     "language":{ "code": "en_US" } '
        . '} '
        . '}';
//DECLARAMOS LAS CABECERAS
$header = array("Authorization: Bearer " . $token, "Content-Type: application/json",);
//INICIAMOS EL CURL
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POSTFIELDS, $mensaje);
curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//OBTENEMOS LA RESPUESTA DEL ENVIO DE INFORMACION
$response = json_decode(curl_exec($curl), true);
//IMPRIMIMOS LA RESPUESTA 
print_r($response);
//OBTENEMOS EL CODIGO DE LA RESPUESTA
$status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
//CERRAMOS EL CURL
curl_close($curl);
?>