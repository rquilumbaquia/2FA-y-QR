<?php include("../../bd.php"); ?>
<?php 
if(isset($_GET['mensaje']))
{

    $mensaje=$_GET['mensaje'];
}
$sentencia=$conexion->prepare("SELECT * FROM  a_lectivo ORDER BY f_inicio DESC  " );
$sentencia->execute();
$lista_anio=$sentencia->fetchAll(PDO::FETCH_ASSOC);

?>
<?php include("../../templates/header.php"); ?>

<div class="card-header">
<?php if(($_SESSION['cargo']=='tesorero')||($_SESSION['cargo']=='presidente')){ ?> 
   
 
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="crear_anio.php"
        role="button"
        
        >Nuevo año lectivo</a
    >
<?php } ?>
<table
            class="table" 
        >
            <thead>
                <tr>
                    
                    <th scope="col">Codigo año </th>
                    <th scope="col">Año lectivo</th>
                    <th scope="col">Desde</th>
                    <th scope="col">Hasta</th>
                    <th scope="col">Opciones</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_anio as $registros){ ?>
                <tr class="">
                   
                    <td><?php echo $registros['anio_lectivo']; ?></td>
                    <td><?php echo $registros['nombre_anio']; ?></td>
                    <td><?php echo $registros['f_inicio']; ?></td>
                    <td><?php echo $registros['f_final']; ?></td>
                    <td> 
                    <?php if($_SESSION['cargo']=='presidente'){ ?>
 
                    Modificar  <a href="eliminar_anio.php?anio_lectivo=<?php echo $registros['anio_lectivo'];  ?>">Eliminar</a>
                    <?php } ?>
 
                    </td>
                    
                   
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
        <?php include("../../templates/footer.php"); ?>