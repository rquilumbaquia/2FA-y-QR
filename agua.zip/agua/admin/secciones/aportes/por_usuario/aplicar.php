<?php 

include("../../../templates/header.php"); 
include("../../../bd.php");

if(($_GET))
{
    $id_obligacion_usuario=(isset($_GET['id_obligacion_usuario']))?$_GET['id_obligacion_usuario']:"";
    $sentencia=$conexion->prepare("SELECT * FROM obligacion_por_usuario WHERE id_obligacion_usuario=:txtidobligacionusuario");
    $sentencia->bindParam(':txtidobligacionusuario',$id_obligacion_usuario);
    $sentencia->execute();
    $aportes_usuario=$sentencia->fetchAll(PDO::FETCH_ASSOC);
}
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios where estado='activo' order by apellidos ASC ");
$sentencia_usuario->execute();
$lista_usuarios=$sentencia_usuario->fetchAll(PDO::FETCH_ASSOC);

?>

<script src="usuarios.js" type="text/javascript" ></script>

<div class="card">
    
    <div class="card-header">
            
        <div
            class="alert alert-primary"
            role="alert"
        >
            <strong>Aplicar :|<?php  foreach($aportes_usuario as $registros_obligacion){  echo ucwords($registros_obligacion['nombre_obligacion'])."| Valor: ";echo $registros_obligacion['valor']; echo "|  Fecha Creacion : ".$registros_obligacion['fecha_creacion']."| Fecha Vencimiento: ".$registros_obligacion['fecha_vencimiento']; $valor=$registros_obligacion['valor']; $opcion=$registros_obligacion['opcion'];  }  ?>| Por Usuarios</strong> 
        </div>
    </div>
      
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table 
            class="table"
        >
            <thead>
                <tr>
                    
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">Cedula</th>
                                       
                    <th scope="col">

                    <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_obligacion_usuario=<?php echo $_GET['id_obligacion_usuario'] ?>&valor=<?php echo $valor ?>&poner=poner"
        
        >Todos</a>
        <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_obligacion_usuario=<?php echo $_GET['id_obligacion_usuario'] ?>&valor=<?php echo $valor ?>&poner=quitar"
        
        >Quitar</a>
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_usuarios as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td>
                    <?php 
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM aporte_por_usuario where id_usuario=:txtidusuario and id_obligacion_usuario=:txtidobligacionusuario  ");
                    $sentencia_aplicacion->bindParam(':txtidusuario',$registros['id_usuario']);
                    $sentencia_aplicacion->bindParam(':txtidobligacionusuario',$_GET['id_obligacion_usuario']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);

                    foreach($resultado as $dato)
                    {
                        $pagar=$dato['pagar'];
                    }
                    
                   
                    if(($sentencia_aplicacion->rowCount())>0)
                    
                    {
                        ?>
                       
                            <div id="check<?php echo $registros['id_usuario']; ?>">
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    checked
                                    onclick="poner_usuario('<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_usuario']?>','no','<?php echo $valor  ?>','<?php echo $opcion  ?>')"
                                    
                                />
                                <?php if($opcion=='ingresado'){ ?>
                                
                                <input type="text" size="4" value="<?php echo $pagar ?>" onchange="poner_usuario('<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_usuario']?>','cambiar',this.value,'<?php echo $opcion  ?>')"  />

                                 <?php } ?>
                                

                            </div>
                        <?php

                    }else
                    {
                        ?>
                        
                        <div id="check<?php echo $registros['id_usuario']; ?>">
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    onclick="poner_usuario('<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_obligacion_usuario'];?>','si','<?php echo $valor;  ?>','<?php echo $opcion;  ?>')"
                                   
                                />
                        
                         </div>
                        <?php

                    }
                echo "<br>";
                    ?>

                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
    </div>
   
</div>
<?php include("../../../templates/footer.php"); ?>

<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[1,'asc']]});
} );

  </script>