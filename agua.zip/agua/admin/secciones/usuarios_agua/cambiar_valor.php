<?php 
include("../../bd.php");
if($_POST)
{

    $id_aporte=(isset($_POST['id_aporte']))?$_POST['id_aporte']:"";
    $pagar= (isset($_POST['valor']))?$_POST['valor']:""; 
    $sentencia=$conexion->prepare(" UPDATE aporte_llave SET pagar=:txtpagar  WHERE id_aporte=:txtidaporte; ");
    $sentencia->bindParam(':txtpagar',$pagar);
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->execute();


$sentencia_s=$conexion->prepare(" SELECT pagar FROM aporte_llave  WHERE id_aporte=:txtidaporte; ");
$sentencia_s->bindParam(':txtidaporte',$id_aporte);
$sentencia_s->execute();
$resultado=$sentencia_s->fetch(PDO::FETCH_LAZY);
echo $resultado['pagar'];

}

?>