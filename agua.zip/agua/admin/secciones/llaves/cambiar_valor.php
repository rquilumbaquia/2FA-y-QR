<?php
include("../../bd.php");

if($_POST['campo']=="suspendido")
{
    if($_POST['accion']=="cambiar"){
    $suspendido=$_POST['valor'];
    $id_llave=$_POST['id_llave'];   
    $sentencia=$conexion->prepare("UPDATE llaves SET suspendido=:txtsuspendido WHERE id_llave=:txtidllave ");
    $sentencia->bindParam(':txtsuspendido',$suspendido);
    $sentencia->bindParam(':txtidllave',$id_llave);
    $sentencia->execute();
    $_POST['accion']=="cargar";    
    $sentencia_consulta=$conexion->prepare("SELECT * FROM llaves WHERE id_llave=:txtidllave ;");
    $sentencia_consulta->bindParam(':txtidllave',$id_llave);
    $sentencia_consulta->execute();
    $lista= $sentencia_consulta->fetch(PDO::FETCH_LAZY);

?>
<div id="suspendido<?php echo $lista['id_llave'];  ?>" ondblclick="cambiar_valor('suspendido','<?php echo $lista['id_llave'];  ?>','','mostrar')" >
<?php echo $lista['suspendido']; ?>
</div>
<?php   

}

if($_POST['accion']=="mostrar"){
?>
<div id="<?php echo $_POST['campo'];?><?php echo $_POST['id_llave'];   ?>">
<select onchange="cambiar_valor('suspendido','<?php echo $_POST['id_llave'];   ?>',this.value,'cambiar')" >
   <option value="" >Seleccione</option>
   <option value="si" >Si</option>
   <option value="no" >No</option>
</select>
</div>
<?php 
}  

}

if($_POST['campo']=="sector")
{
    if($_POST['accion']=="cambiar"){
    $sector=$_POST['valor'];
    $id_llave=$_POST['id_llave'];   
    $sentencia=$conexion->prepare("UPDATE llaves SET sector=:txtsector WHERE id_llave=:txtidllave ");
    $sentencia->bindParam(':txtsector',$sector);
    $sentencia->bindParam(':txtidllave',$id_llave);
    $sentencia->execute();
    $_POST['accion']=="cargar";    
    $sentencia_consulta=$conexion->prepare("SELECT * FROM llaves WHERE id_llave=:txtidllave ;");
    $sentencia_consulta->bindParam(':txtidllave',$id_llave);
    $sentencia_consulta->execute();
    $lista= $sentencia_consulta->fetch(PDO::FETCH_LAZY);

?>
<div id="sector<?php echo $lista['id_llave'];  ?>" ondblclick="cambiar_valor('sector','<?php echo $lista['id_llave'];  ?>','','mostrar')" >
<?php echo $lista['sector']; ?>
</div>
<?php 

}
if($_POST['accion']=="mostrar"){

    $id_llave=$_POST['id_llave']; 
    $sentencia_consulta=$conexion->prepare("SELECT * FROM llaves WHERE id_llave=:txtidllave ;");
    $sentencia_consulta->bindParam(':txtidllave',$id_llave);
    $sentencia_consulta->execute();
    $lista= $sentencia_consulta->fetch(PDO::FETCH_LAZY);
?>
<div id="<?php echo $_POST['campo'];?><?php echo $_POST['id_llave'];   ?>">
<input type="text" value="<?php echo  $lista['sector'];  ?>" onchange="cambiar_valor('sector','<?php echo $_POST['id_llave'];   ?>',this.value,'cambiar')"    />
</div>
<?php 
}  

}


if($_POST['campo']=="informacion")
{
    if($_POST['accion']=="cambiar"){
    $informacion=$_POST['valor'];
    $id_llave=$_POST['id_llave'];   
    $sentencia=$conexion->prepare("UPDATE llaves SET informacion=:txtinformacion WHERE id_llave=:txtidllave ");
    $sentencia->bindParam(':txtinformacion',$informacion);
    $sentencia->bindParam(':txtidllave',$id_llave);
    $sentencia->execute();
    $_POST['accion']=="cargar";  
    $sentencia_consulta=$conexion->prepare("SELECT * FROM llaves WHERE id_llave=:txtidllave ;");
    $sentencia_consulta->bindParam(':txtidllave',$id_llave);
    $sentencia_consulta->execute();
    $lista= $sentencia_consulta->fetch(PDO::FETCH_LAZY); 

   
?>
<div id="informacion<?php echo $lista['id_llave'];  ?>" ondblclick="cambiar_valor('informacion','<?php echo $lista['id_llave'];  ?>','','mostrar')" >
<?php echo $lista['informacion']; ?>
</div>
<?php 

}
if($_POST['accion']=="mostrar"){

    $id_llave=$_POST['id_llave']; 
    $sentencia_consulta=$conexion->prepare("SELECT * FROM llaves WHERE id_llave=:txtidllave ;");
    $sentencia_consulta->bindParam(':txtidllave',$id_llave);
    $sentencia_consulta->execute();
    $lista= $sentencia_consulta->fetch(PDO::FETCH_LAZY);
?>
<div id="<?php echo $_POST['campo'];?><?php echo $_POST['id_llave'];   ?>">
<input type="text" value="<?php echo  $lista['informacion'];  ?>" onchange="cambiar_valor('informacion','<?php echo $_POST['id_llave'];   ?>',this.value,'cambiar')"    />
</div>
<?php 
}  

}




?>

