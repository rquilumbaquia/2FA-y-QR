function limpiar()
{        var msg="";
        $("#enviado").html(msg);
        $("#divimagen").html(msg);        
}

function enviar()
{
        id_acceso= $('#id_user').val(); // Cogemos del formulario el valor nom             
        // Función que envía y recibe respuesta con AJAX
        $.ajax({
         type: 'POST',  // Envío con método POST
         url: 'enviar.php',  // Fichero destino (el PHP que trata los datos)
         data: { id_acceso: id_acceso } // Datos que se envían
         }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
          $("#enviado").html(msg);  // Escribimos en el div consola el mensaje devuelto
         }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
         // Mostramos en consola el mensaje con el error que se ha producido
         $("#enviado").html("The following error occured: "+ textStatus +" "+ errorThrown); 
        }); 
}

function validarUsuario()
{ 
    var mensaje="";
    usuario= $('#login').val(); // Cogemos del formulario el valor nom
    contrasenia= $('#password-input').val(); // Cogemos del formulario el valor pass
    $('#exampleModalLabel').html("Ventana de Generacion de codigo QR");
       
    // Función que envía y recibe respuesta con AJAX
    if(($('#nombre').val()=="")){
               mensaje=mensaje+"Ingrese nombre de usuario<br>";
    } 
    if(($('#correo').val()=="")){
        mensaje=mensaje+"Ingrese correo electronico<br>";
      } 
      if(($('#login').val()=="")){
                mensaje=mensaje+"Ingrese Login<br>";
      }
      if(($('#password-input').val()=="")){

        mensaje=mensaje+"Ingrese Password<br>";
      }        
      if(($('#cargo').val()=="")){
        mensaje=mensaje+"Selecciones un cargo<br>";        
      } 
      if(($('#anio_lectivo').val()=="")){
        mensaje=mensaje+"Selecciones un cargo<br>";
      } 
      if(mensaje!==""){

    $('#mensajetotal').html("<div class='alert alert-danger alert-dismissible fade show' role='alert' > <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button><strong>"+mensaje+"</strong></div>");
    document.getElementById("cerrar_modal").click();
    document.getElementById("guardar").disabled=true;
   }else{

    document.getElementById("guardar").disabled=false;
    $.ajax({
     type: 'POST',  // Envío con método POST
     url: '/agua/admin/libs/generadorqr/aguaqr.php',  // Fichero destino (el PHP que trata los datos)
     data: { login: usuario, password: contrasenia } // Datos que se envían
     }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
      $("#divimagen").html(msg);  // Escribimos en el div consola el mensaje devuelto
     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
     // Mostramos en consola el mensaje con el error que se ha producido
     $("#divimagen").html("The following error occured: "+ textStatus +" "+ errorThrown); 
    });
    
    }
     
}
    
      function generarUsuario(){
        datos= $('#data').val(); // Cogemos del formulario el valor nom
        nivel= $('#level').val(); // Cogemos del formulario el valor pass
        tamanio= $('#size').val();
        // Función que envía y recibe respuesta con AJAX
        $.ajax({
         type: 'POST',  // Envío con método POST
         url: '/agua/admin/libs/generadorqr/aguaqr.php',  // Fichero destino (el PHP que trata los datos)
         data: { data: datos, level: nivel, size: tamanio } // Datos que se envían
         }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
          $("#divimagen").html(msg);  // Escribimos en el div consola el mensaje devuelto
         }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
         // Mostramos en consola el mensaje con el error que se ha producido
         $("#divimagen").html("The following error occured: "+ textStatus +" "+ errorThrown); 
        });
                            }
 
        function recuperarqr(id_acceso)
            {
            $.ajax({
            type: 'POST',  // Envío con método POST
            url: 'recuperar_imagen.php',  // Fichero destino (el PHP que trata los datos)
            data: { id_acceso: id_acceso} // Datos que se envían
            }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
             $("#poner_qr").html(msg);  // Escribimos en el div consola el mensaje devuelto
            }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
            // Mostramos en consola el mensaje con el error que se ha producido
            $("#poner_qr").html("The following error occured: "+ textStatus +" "+ errorThrown); 
            });
            }
            

            function poner_fechas(){

                anio_lectivo=$('#anio_lectivo').val();
              
                $.ajax({
                 type: 'POST',  // Envío con método POST
                 url: 'recupera_fecha.php',  // Fichero destino (el PHP que trata los datos)
                 data: { anio_lectivo: anio_lectivo,campo:"f_inicio"} // Datos que se envían
                 }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
                 
                  $("#f_inicio").val(msg) // Escribimos en el div consola el mensaje devuelto
                 }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
                 // Mostramos en consola el mensaje con el error que se ha producido
                 $("#f_inicio").val(""); 
                });   

                $.ajax({
                    type: 'POST',  // Envío con método POST
                    url: 'recupera_fecha.php',  // Fichero destino (el PHP que trata los datos)
                    data: { anio_lectivo: anio_lectivo,campo:"f_final"} // Datos que se envían
                    }).done(function( msg ) { 
                        $("#f_final").val(msg);  // Escribimos en el div consola el mensaje devuelto
                    }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
                    // Mostramos en consola el mensaje con el error que se ha producido
                    $("#f_final").val(""); 
                   });   


                }

                function verificar_adecuado(campo,valor)
                {
                 
                     $.ajax({
                     type: 'POST',  // Envío con método POST
                     url: 'verificador_usuario.php',  // Fichero destino (el PHP que trata los datos)
                     data: { campo: campo,valor:valor} // Datos que se envían
                     }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
                                          
                       if(msg.trim()=='si'){
                        $('#mensaje'+campo).html("<div class='alert alert-danger alert-dismissible fade show' role='alert' > <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button><strong>Ya existe un "+campo+" similar en la Base de Datos pf cambie</strong></div>");
                        $("#"+campo).val("");
                        $("#"+campo).focus();
                        }

                                           
                        if(msg.trim()=='error'){
                        $('#mensaje'+campo).html("<div class='alert alert-danger alert-dismissible fade show' role='alert' > <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button><strong>El "+campo+" no tiene un formato correcto</strong></div>");
                        $("#"+campo).val("");
                        $("#"+campo).focus();
                        }                   
                     
                     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
                     // Mostramos en consola el mensaje con el error que se ha producido
                    /// $("#mensaje"+campo).html(""); 
                    });   
                            
                }
                    

                function cambio_password()
                {
                    var mensaje="";
                    usuario= $('#login').val(); // Cogemos del formulario el valor nom
                    id_acceso= $('#id_acceso').val(); // Cogemos del formulario el valor nom
                    //contrasenia= $('#password-input').val(); // Cogemos del formulario el valor pass
                    document.getElementById("guardar").disabled=true;
                    $('#exampleModalLabel').html("Ventana de cambio de contraseña");
                    $("#divimagen").html("Ingrese la contraseña actual<input type='password' value='' name='actual' id='actual'/><button type='button'  name='verificar' class='btn btn-outline-success' onclick='verificar_password()'> <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-check' viewBox='0 0 16 16'><path d='M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z'/></svg></button>");
                     
                }


                function verificar_password()
                {
                    var mensaje="";
                    password_actual= $('#actual').val(); // Cogemos del formulario el valor nom
                    id_acceso= $('#id_acceso').val(); // Cogemos del formulario el valor nom
                    //contrasenia= $('#password-input').val(); // Cogemos del formulario el valor pass
                                       
                    // Función que envía y recibe respuesta con AJAX
                                        
                    document.getElementById("guardar").disabled=true;
                    $.ajax({
                     type: 'POST',  // Envío con método POST
                     url: 'probar_contrasena.php',  // Fichero destino (el PHP que trata los datos)
                     data: { password_actual: password_actual, id_acceso: id_acceso } // Datos que se envían
                     }).done(function( msg ) {  // Función que se ejecuta si todo ha ido bien
                      let result=msg.trim();
                      
                      if(result=="correcto")
                        {
                          document.getElementById("password-input").disabled=false;
                          document.getElementById("btgenerar").disabled=false;
                          document.getElementById("aplicar_2fa").disabled=false;
                          document.getElementById("f_final").disabled=false;
                          document.getElementById("f_inicio").disabled=false;
                          document.getElementById("anio_lectivo").disabled=false;
                          document.getElementById("activo").disabled=false;
                          document.getElementById("cargo").disabled=false;
                          document.getElementById("login").disabled=false;
                          document.getElementById("correo").disabled=false;
                          document.getElementById("nombre").disabled=false;
                          $('#exampleModalLabel').html("");
                          $("#divimagen").html("<div id='mensajetotal' ></div>");                         

                          document.getElementById("cerrar_modal").click();

                        }else{

                          $('#exampleModalLabel').html("La verificación es incorrecta");
                        }


                     /// $("#divimagen").html(msg);  // Escribimos en el div consola el mensaje devuelto
                     }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
                     // Mostramos en consola el mensaje con el error que se ha producido
                     $("#divimagen").html("The following error occured: "+ textStatus +" "+ errorThrown); 
                    });
                    
                    
                     
                }
                 