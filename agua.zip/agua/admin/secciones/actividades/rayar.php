<?php 
include("../../bd.php");
include("../../templates/header.php"); 
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios where estado='activo' or estado='nuevo' order by apellidos ASC ");
$sentencia_usuario->execute();
$lista_usuarios=$sentencia_usuario->fetchAll(PDO::FETCH_ASSOC);
$total=$sentencia_usuario->rowCount();

$f_inicio=$_SESSION['f_inicio_periodo'];
$sentencia_actividades=$conexion->prepare("SELECT * FROM actividades where f_ejecucion >=:txtfinicio  order by f_ejecucion ASC ");
$sentencia_actividades->bindParam(':txtfinicio',$f_inicio);
$sentencia_actividades->execute();
$lista_actividades=$sentencia_actividades->fetchAll(PDO::FETCH_ASSOC);

function fecha_txt($valor,$dia,$mes)
{
 $dx= date($valor);
$fecha= array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
//Ensure correct for language. English is "January 1, 2004"
$DAY = $fecha[$mes] . " " . $dia . ", " . date("Y", $dx);
return $DAY;
}

?>
<link rel="stylesheet" type="text/css" href="mi_estilo.css">
<script src="actividades.js" type="text/javascript" ></script>
<a href="javascript:imprimirSeleccion('div_print','rayar.php')" >Imprimir</a>
<div id="div_print">

<div class="card-header">
        <div
           
           
        >
            <strong>Actividades desde <?php 
            
            $fechaEntera = strtotime($_SESSION['f_inicio_periodo']);
            
            $mes = date("m", $fechaEntera);
            $mes=abs($mes);

            $dia = date("d", $fechaEntera);

            echo fecha_txt($fechaEntera,$dia,$mes);
            
            ?> 
            Hasta 
            <?php 
            
            $fechaEntera = strtotime($_SESSION['f_final_periodo']);
            $_SESSION['f_inicio_periodo'];  
            $mes = date("m", $fechaEntera);
            $mes=abs($mes);

            $dia = date("d", $fechaEntera);

            echo fecha_txt($fechaEntera,$dia,$mes);
            
            ?></strong> 
        </div>


<table 
            class="table"
        >
            <thead>
                <tr>
                    
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">Cedula</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Tercera Edad</th>
                    
                    <th scope="col"></th>
                    <?php foreach($lista_actividades as $registros_actividades){ ?>
                        <th scope="col"><div class="darvuelta-text size_pagos"> <?php echo $registros_actividades['nombre_actividad']; ?></div></th>
                    <?php } ?>
                    
                    <th> Total </th>
                </tr>
            </thead>
            <tbody>
                
            <?php foreach($lista_usuarios as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td><?php echo $registros['estado']; ?></td>
                    <td><?php echo $registros['tercera_edad']; ?></td>
                    <td></td>
                    <?php $total_usuario=0; ?>
                    <?php foreach($lista_actividades as $registros_actividades)
                    
                    { ?>
                        <td>
                          <di id="raya<?php echo $registros['id_usuario']; ?>-<?php echo $registros_actividades['id_actividad']; ?>" ></div>
                                              
                          <?php //echo $registros_actividades['nombre_actividad']; ?>

                          <?php 
                    $id_usuario=$registros['id_usuario'];
                    $id_actividad=$registros_actividades['id_actividad'];
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM rayas_usuario where id_usuario=:txtidusuario and id_actividad=:txtidactividad  ");
                    $sentencia_aplicacion->bindParam(':txtidusuario',$id_usuario);
                    $sentencia_aplicacion->bindParam(':txtidactividad',$id_actividad);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetch(PDO::FETCH_LAZY);
                    
                    if(($sentencia_aplicacion->rowCount())>0)
                    {

                    if($resultado['cumplido']==1)
                    
                    {  $total_usuario=$total_usuario+$resultado['cantidad_raya'];
                        ?>
                       
                       <div id="raya<?php echo $registros['id_usuario']; ?>-<?php echo $registros_actividades['id_actividad']; ?>" >
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    checked
                                    onclick="poner_raya('<?php echo $registros['id_usuario']; ?>','<?php echo $registros_actividades['id_actividad']?>','no')"
                                    
                                />

                                <?php echo $resultado['cantidad_raya'];  ?>
                            </div>
                        <?php

                    }
                    if($resultado['cumplido']!=1)
                   
                    {
                        ?>
                        
                        <div id="raya<?php echo $registros['id_usuario']; ?>-<?php echo $registros_actividades['id_actividad']; ?>" >
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    onclick="poner_raya('<?php echo $registros['id_usuario']; ?>','<?php echo $registros_actividades['id_actividad'];?>','si')"
                                   
                                />
                                <input type="text" value="<?php echo $resultado['cantidad_raya']  ?>" 
                                id="txt<?php echo $registros['id_usuario']; ?>-<?php echo $registros_actividades['id_actividad']; ?>" 
                                size="2" 
                                onchange="cantidadraya('<?php echo $registros['id_usuario']; ?>','<?php echo $registros_actividades['id_actividad'];?>',this.value)" 
                                placeholder="rayas" 
                                data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Ingrese Numero de rayas"
                                />
                        
                         </div>
                        <?php

                    }
                echo "<br>";
                    
                   }
                    ?>
                    
                    
                         </td>
                    <?php } ?>
                  
                    <td><?php echo $total_usuario; ?></td>

                </tr>
           
            <?php          } ?>    
               
            </tbody>
        </table>
    
                </div>


<?php include("../../templates/footer.php"); ?>           
<script>

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

</script>


<script>
$(document).ready( function () {
    $('table').DataTable({"pageLength":<?php echo $total ?>,lengthMenu:[[<?php echo $total ?>,3,10,25,50],[<?php echo $total ?>,3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[1,'asc']]});
} );

</script>
