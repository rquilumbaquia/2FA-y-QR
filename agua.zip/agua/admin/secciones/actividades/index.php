<?php 
include("../../bd.php");
include("../../templates/header.php"); 

if(isset($_GET['eliminar'])&&($_GET['eliminar']=='si'))
{

$sentencia_eliminar=$conexion->prepare("DELETE FROM actividades  WHERE id_actividad=:txtactividad ");
$sentencia_eliminar->bindParam(':txtactividad',$_GET['id_actividad']);

$sentencia_eliminar->execute();

}



$sentencia=$conexion->prepare("SELECT * FROM actividades ORDER BY f_ejecucion DESC  ");
$sentencia->execute();
$lista_actividades=$sentencia->fetchAll(PDO::FETCH_ASSOC);

?>

Lista de Activiades
<div class="card">
    <div class="card-header">
    <?php if(($_SESSION['cargo']=='secretario')||($_SESSION['cargo']=='presidente')){ ?> 
    <a
        name=""
        id=""
        class="btn btn-primary"
        href="crear.php"
        role="button"
        >Nueva Actividad</a
    >
        <?php } ?>
    </div>
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table
            class="table" 
        >
            <thead>
                <tr>
                    <th scope="col">Id Actividad</th>
                    <th scope="col">Nombre Actividad</th>
                    <th scope="col">Valor en Rayas</th>
                    <th scope="col">Fecha de Ejecución</th>
                    <th scope="col">Observación</th>
                    <th scope="col">Valor al no cumplir</th>
                    <th scope="col">Aplicaciones</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_actividades as $registros){ ?>
                <tr class="">
                    <td scope="row"><?php echo $registros['id_actividad']; ?></td>
                    <td><?php echo $registros['nombre_actividad']; ?></td>
                    <td><?php echo $registros['cantidad_rayas']; ?></td>
                    <td><?php echo $registros['f_ejecucion']; ?></td>
                    <td><?php echo $registros['observacion']; ?></td>
                    <td><?php echo $registros['valor_no_cumplir']; ?></td>
                    
                    <td>
                    <?php if(($_SESSION['cargo']=='secretario')||($_SESSION['cargo']=='presidente')){ ?> 
                    

                    <a
                        name=""
                        id=""
                        href="#"                       
                        >Editar</a
                    >
                   <a
                    name=""
                    id=""                   
                    href="index.php?eliminar=si&id_actividad=<?php echo $registros['id_actividad'];  ?>"                    
                    >Eliminar</a
                   >
                   <a
                    name=""
                    id=""                   
                    href="aplicar.php?id_actividad=<?php echo $registros['id_actividad'];  ?>"                    
                    >Aplicar</a
                   >
                   <?php } ?>
                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
       

    </div>
   
</div>

<?php include("../../templates/footer.php");  ?>
<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[3,'desc']]});
} );

  </script>

