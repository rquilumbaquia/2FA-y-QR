<?php

include("../../../bd.php");
if ((isset($_POST['poner']))&&($_POST['poner']=="cambiar"))
 {
    $id_aporte=$_POST['id_usuario']."-".$_POST['id_obligacion_usuario'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
    $pagar=$_POST['valor'];
    $observacion="Solo asignado";
    $sentencia_update=$conexion->prepare("UPDATE aporte_por_usuario SET pagar=:txtpagar where id_aporte=:txtidaporte ");
    $sentencia_update->bindParam(':txtpagar',$pagar);
    $sentencia_update->bindParam(':txtidaporte',$id_aporte);
    $sentencia_update->execute();
}

if ((isset($_POST['poner']))&&($_POST['poner']=="si"))
 {
    $id_aporte=$_POST['id_usuario']."-".$_POST['id_obligacion_usuario'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
    $f_pago="";
    $f_asignacion=date("Y-m-d");
    $pagar=$_POST['valor'];
    $valor_pago="";
    $id_acceso="";
    $id_obligacion_usuario=(isset($_POST['id_obligacion_usuario']))?$_POST['id_obligacion_usuario']:"";
    $observacion="Solo asignado";
    $sentencia=$conexion->prepare("INSERT INTO aporte_por_usuario (id_aporte, id_usuario, f_pago, f_asignacion, pagar, valor_pago, id_acceso, id_obligacion_usuario, observacion)values(:txtidaporte, :txtidusuario, :txtfpago, :txtfasignacion, :txtpagar, :txtvalorpago, :txtidacceso, :txtidobligacionusuario, :txtobservacion); ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':txtfpago', $f_pago);
    $sentencia->bindParam(':txtfasignacion',$f_asignacion);
    $sentencia->bindParam(':txtpagar',$pagar);
    $sentencia->bindParam(':txtvalorpago',$valor_pago);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtidobligacionusuario',$id_obligacion_usuario);
    $sentencia->bindParam(':txtobservacion',$observacion);
    $sentencia->execute();
}

if ((isset($_POST['poner']))&&($_POST['poner']=="no"))
 {
    $id_aporte=$_POST['id_usuario']."-".$_POST['id_obligacion_usuario'];   
    $sentencia=$conexion->prepare("DELETE FROM aporte_por_usuario WHERE id_aporte=:txtidaporte AND observacion<>'Pagado'; ");
    $sentencia->bindParam(':txtidaporte',$id_aporte);
    $sentencia->execute();
    

}
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM aporte_por_usuario where id_usuario=:txtidusuario and id_obligacion_usuario=:txtidobligacionusuario ");
                    $sentencia_aplicacion->bindParam(':txtidusuario',$_POST['id_usuario']);
                    $sentencia_aplicacion->bindParam(':txtidobligacionusuario',$_POST['id_obligacion_usuario']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach($resultado as $dato)
                    {
                    $pagar=$dato['pagar'];

                    }
                    if(($sentencia_aplicacion->rowCount())>0)
                    {
                     
                        ?>
                            <div id="check<?php echo $_POST['id_usuario']; ?>">
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    checked
                                    onclick="poner_usuario('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_usuario']?>','no','<?php echo $_POST['valor']  ?>','<?php echo $_POST['opcion']  ?>')"
                                    autocomplete="off"
                                />

                                <?php if($_POST['opcion']=='ingresado'){
                                
                                ?>
                               
                               <input type="text" size="4" value="<?php echo $pagar; ?>" onchange="poner_usuario('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_usuario']?>','cambiar',this.value,'<?php echo $_POST['opcion']  ?>')" />
                               
                                <?php } ?>
                                
                            </div>
                        <?php

                    }else
                    {

                        ?>
                        <div id="check<?php echo $_POST['id_usuario']; ?>">
                    
                        <input
                            type="checkbox"
                            class="form-check-input"
                            name=""
                            onclick="poner_usuario('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_obligacion_usuario']?>','si','<?php echo $_POST['valor']  ?>','<?php echo $_POST['opcion']  ?>')"
                            autocomplete="off"
                        />
                        </div>
                <?php
                    }

    ?>