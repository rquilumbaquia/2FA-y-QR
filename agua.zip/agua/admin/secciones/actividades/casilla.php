<?php

include("../../bd.php");


if ((isset($_POST['poner']))&&($_POST['poner']=="si"))
 {
   
   /* consultamos la cantidad de rayas de la actividad */

    $sentencia_cantidad=$conexion->prepare("SELECT * FROM actividades where  id_actividad=:txtidactividad ");
    $sentencia_cantidad->bindParam(':txtidactividad',$_POST['id_actividad']);
    $sentencia_cantidad->execute();                   
    $resultado=$sentencia_cantidad->fetch(PDO::FETCH_LAZY);
    $cantidad=$resultado['cantidad_rayas'];

    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];   
    $id_usuario=(isset($_POST['id_usuario']))?$_POST['id_usuario']:"";
   
    $f_registro=date("Y-m-d");
    
    $cumplido="";
    $id_actividad=(isset($_POST['id_actividad']))?$_POST['id_actividad']:"";
    $id_acceso="";
    
    $sentencia=$conexion->prepare("INSERT INTO rayas_usuario (id_raya, id_usuario, id_actividad, fecha_registro, id_acceso, cumplido, cantidad_raya)values(:txtidraya, :txtidusuario, :txtidactividad, :txtfecharegistro, :txtidacceso, :txtcumplido, :txtcantidadraya ); ");
    $sentencia->bindParam(':txtidraya',$id_raya);
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':txtidactividad', $id_actividad);
    $sentencia->bindParam(':txtfecharegistro',$f_registro);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtcumplido',$cumplido);
    $sentencia->bindParam(':txtcantidadraya',$cantidad);
    $sentencia->execute();
}

if ((isset($_POST['poner']))&&($_POST['poner']=="no"))
 {
    $id_raya=$_POST['id_usuario']."-".$_POST['id_actividad'];   
    $sentencia=$conexion->prepare("DELETE FROM rayas_usuario WHERE id_raya=:txtidraya  ");
    $sentencia->bindParam(':txtidraya',$id_raya);
    $sentencia->execute();
    

}
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM rayas_usuario where id_usuario=:txtidusuario and id_actividad=:txtidactividad ");
                    $sentencia_aplicacion->bindParam(':txtidusuario',$_POST['id_usuario']);
                    $sentencia_aplicacion->bindParam(':txtidactividad',$_POST['id_actividad']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);
                    
                    if(($sentencia_aplicacion->rowCount())>0)
                    {
                     
                        ?>
                            <div id="check<?php echo $_POST['id_usuario']; ?>">
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    checked
                                    onclick="poner_usuario('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_actividad']?>','no')"
                                    autocomplete="off"
                                />

                                
                                
                            </div>
                        <?php

                    }else
                    {

                        ?>
                        <div id="check<?php echo $_POST['id_usuario']; ?>">
                    
                        <input
                            type="checkbox"
                            class="form-check-input"
                            name=""
                            onclick="poner_usuario('<?php echo $_POST['id_usuario']; ?>','<?php echo $_POST['id_actividad']?>','si')"
                            autocomplete="off"
                        />
                        </div>
                <?php
                    }

    ?>