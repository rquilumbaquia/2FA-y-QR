<?php 

$hostname_acceso = "localhost";

$database_acceso = "agua";

$username_acceso = "root";

$password_acceso = "";
try{

    $conexion= new PDO("mysql:host=$hostname_acceso;dbname=$database_acceso;charset=utf8",$username_acceso,$password_acceso);
    

} catch(Exception $error){echo $error->getMessage(); }


?>