

<script src="./js/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="./css/sweetalert2.min.css">

<?php 
include("bd.php");
date_default_timezone_set("America/Bogota");
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
//header("Content-Security-Policy: default-src 'self'");
//header("Content-Security-Policy: default-src 'self' ");

$url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/";

/*llamamos a la función autenticator para el uso de QR*/
require_once './libs/Autenticator/GoogleAuthenticator.php';
$ga = new PHP_GoogleAuthenticator();

include("sesion.php");

if (!isset($_SESSION)) {
 correr_session(); 
}

/* Procedimiento de verificacion 2FA por codigo */
if((isset($_POST['entrar_codigo']))&&($_POST['entrar_codigo']=="Enviar")&&($_SESSION['tocte']==$_POST['csrf_token']))
{
if((isset($_POST['id_acceso']))&&(isset($_POST['codigo_recuperacion'])))
  { $id_acceso=$_POST['id_acceso'];
    $codigo=$_POST['codigo_recuperacion'];
    $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->execute();
    $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);    
    if (password_verify($codigo, $lista_usuario['codigo_recuperacion']))
    {
            $hora_actual=date("His"); 
            $valor=$lista_usuario['hora_recuperacion'];
            $hora_recuperacion = new DateTime($valor);
            $hora_limite=($hora_recuperacion->format('His'))+300;
            if(($hora_actual>$hora_limite))
            {
              $mensaje= "El tiempo ha expirado realice un nuevo proceso de recuperacion";
              echo ".";
              $id_acceso=$_POST['id_acceso'];
              $sentencia=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion='',hora_recuperacion='' WHERE id_acceso=:txtidacceso ");
              $sentencia->bindParam(':txtidacceso',$id_acceso);
              $sentencia->execute();
             // $MM_redirectLoginSuccess ="login.php?mensaje=".$mensaje;
             //header("Location: " . $MM_redirectLoginSuccess );
              
           
            }else{
              /* se autentica el usuario y se asignan los datos a las sessiones, finalmente se redirecciona a index.php */
              $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
              $_SESSION['usuario']=$lista_usuario['login'];
              $_SESSION['cargo']=$lista_usuario['cargo'];
              $_SESSION['logeado']=true;
              $_SESSION['f_inicio_usuario']=$lista_usuario['f_inicio'];
              $_SESSION['f_final_usuario']=$lista_usuario['f_final'];
              $fecha_caducidad=$lista_usuario['fecha_caducidad'];
              $anio_lectivo=$lista_usuario['anio_lectivo'];
              $sentencia_anio=$conexion->prepare("SELECT * FROM a_lectivo WHERE anio_lectivo=:txtanio ");
              $sentencia_anio->bindParam(':txtanio',$anio_lectivo);
              $sentencia_anio->execute();
              $lista_anio=$sentencia_anio->fetch(PDO::FETCH_LAZY);
              $_SESSION['anio_lectivo']=$lista_anio['anio_lectivo'];
              $_SESSION['f_inicio_periodo']=$lista_anio['f_inicio'];
              $_SESSION['f_final_periodo']=$lista_anio['f_final'];
              $id_acceso=$_POST['id_acceso'];
              $sentencia=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion='',hora_recuperacion='',intentos='' WHERE id_acceso=:txtidacceso ");
              $sentencia->bindParam(':txtidacceso',$id_acceso);
              $sentencia->execute();
              $mensaje="Succes";
              $MM_redirectLoginSuccess ="index.php";
              header("Location: " . $MM_redirectLoginSuccess );
           }
        }else{$mensaje="El codigo de acceso es incorrecto";echo ".";}
  }           
}   

/* Procedimiento de verificacion por QR */
if((isset($_POST['entrar_QR']))&&($_POST['entrar_QR']=="Verificar")&&($_SESSION['tocte']==$_POST['csrf_token']))
{
if((isset($_POST['id_acceso']))&&(isset($_POST['codigo']))&&(isset($_POST['secreto'])))
{
  $secret=$_POST['secreto'];   
  //$oneCode = $ga->getCode($secret);
  $oneCode =$_POST['codigo'];
  echo "Verificando Code '$oneCode' Y Secreto '$secret':";
  $checkResult = $ga->verifyCode($secret, $oneCode, 2);    // 2 = 2*30sec clock tolerance
  if ($checkResult) {

      $id_acceso=$_POST['id_acceso'];
      $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
      $sentencia->bindParam(':txtidacceso',$id_acceso);
      $sentencia->execute();
      $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);    
      echo 'OK';
      $mensaje="Verificación correcta";
      $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
      $_SESSION['usuario']=$lista_usuario['login'];
      $_SESSION['cargo']=$lista_usuario['cargo'];
      $_SESSION['logeado']=true;
      $_SESSION['f_inicio_usuario']=$lista_usuario['f_inicio'];
      $_SESSION['f_final_usuario']=$lista_usuario['f_final'];
      $fecha_caducidad=$lista_usuario['fecha_caducidad'];
      $anio_lectivo=$lista_usuario['anio_lectivo'];
      $sentencia_anio=$conexion->prepare("SELECT * FROM a_lectivo WHERE anio_lectivo=:txtanio ");
      $sentencia_anio->bindParam(':txtanio',$anio_lectivo);
      $sentencia_anio->execute();
      $lista_anio=$sentencia_anio->fetch(PDO::FETCH_LAZY);
      $_SESSION['anio_lectivo']=$lista_anio['anio_lectivo'];
      $_SESSION['f_inicio_periodo']=$lista_anio['f_inicio'];
      $_SESSION['f_final_periodo']=$lista_anio['f_final'];
      $id_acceso=$_POST['id_acceso'];
      $sentencia=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion='',hora_recuperacion='',intentos='' WHERE id_acceso=:txtidacceso ");
      $sentencia->bindParam(':txtidacceso',$id_acceso);
      $sentencia->execute();
      $mensaje="Succes";
      $MM_redirectLoginSuccess ="index.php";
      header("Location: " . $MM_redirectLoginSuccess );
  } else {
     
     $mensaje="La verificacion ha fallado";
     echo 'FAILED';
  }

}
}
?>
<?php 
  $id_acceso=(isset($_SESSION['id_acceso']))?$_SESSION['id_acceso']:"";
  $sentencia=$conexion->prepare("SELECT id_acceso,login,password,cargo,f_inicio,f_final,anio_lectivo,correo,intentos,fecha_caducidad,aplicar_2fa,activo FROM usuario_acceso WHERE id_acceso=:txtidacceso  " );
  $sentencia->bindParam(':txtidacceso',$id_acceso);
  $sentencia->execute();
  $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);

?>
<!--<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> !-->
<script src="/agua/js/sweetalert2@11"></script>
<link href="/agua/admin/libs/bootstrap-5.2.3-dist/css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
<script  src="/agua/js/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>

<main>
  <br><br>
  
<div class="container">
  <div class="row">
    <div class="col-4"></div>
      <div class="col-4">
        <div class="card  border border-primary">
        <div class="card-header text-primary">Verificacion 2FA </div>
        
        <div class="card-body">
        <div class="mb-3">


 <form action="" method="post" autocomplete="off" > 
      <input
      type="hidden"
      name="csrf_token"
      id="csrf_token"
      value="<?php
      if(isset($_SESSION['tocte'])){
      echo  $_SESSION['tocte'];
      }
      
      ?>"
      />   
    
     <?php 
     if((isset($lista_usuario['aplicar_2fa']))&&($lista_usuario['aplicar_2fa']=="email"))
     { ?>      
      
     Bienvenido: <?php echo $lista_usuario['login']."  "; ?>
      
      <br>      
      Tenemos instrucciones de verificar tu autenticidad compruebalo con un codigo que hemos enviado a tu correo electronico..<br> 
       <?php 
      $usuario = strstr($lista_usuario['correo'], "@", true);
      $longitud=strlen($usuario);
      echo substr($usuario,0,$longitud-3)."xxx".strstr($lista_usuario['correo'], "@");
      ?> vinculado a esta cuenta 
      <br>
      Tiempo maximo esperado es 5 minutos...
      <br>
      
      <input type="hidden" name="id_acceso" value="<?php echo $id_acceso ?>" />
      <label for="codigo_recuperacion" class="form-label text-primary">Codigo</label>
      <input
      type="text"
      class="border border-success text-primary"
      name="codigo_recuperacion"
      id="codigo_recuperacion"
      aria-describedby="helpId"
      placeholder="Ingresa aqui el codigo que recibiste"
      
      />
      <script>
      //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
      $('#codigo_recuperacion').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
      });
      </script>
      <input type="submit" name="entrar_codigo" value="Enviar" class="btn btn-outline-primary" />
      <a
        name=""
        id=""
        class="btn btn-outline-primary"
        href="login.php"
        role="button"
        >Cancelar</a>   
    
      <?php      
     }
      if((isset($lista_usuario['aplicar_2fa']))&&($lista_usuario['aplicar_2fa']=="QR"))
      {
        $secret = $ga->createSecret();
       /* echo "codigo secreto: ".$secret."<br>";*/
        $qrCodeUrl = $ga->getQRCodeGoogleUrl('Sistema de Agua', $secret);
      ?> 
  
      <img src="<?php echo $qrCodeUrl ?>" class="border border-4 border-primary" >    
      <br>  <br>      
      Hola: <?php echo $lista_usuario['login']."  "; ?>   
      <br>
       Decodifica este codigo QR con Google autenticator<br>
       e ingresa para comprobar si eres tu<br>          
        
      <input type="hidden" name="id_acceso" value="<?php echo $id_acceso ?>" />      
      <label for="secreto" class="form-label text-secondary" >Codigo Secreto/Clave</label>      
      <input name="secreto" value="<?php echo $secret ?>" readonly class="border border-success text-secondary" /><br>
      <label for="codigo" class="form-label text-primary">Decodificacion QR</label>       
      <input name="codigo" value="" placeholder="Ingrese aqui el codigo" class="border border-primary text-primary" /><br>
      <script>
      //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
      $('#codigo').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
      });
      </script>     
      <button type="submit" class="btn btn-outline-primary" value="Verificar" name="entrar_QR">Verificar
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
      <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76z"/>
      </svg>   
     </button>
          
      <?php 
      } 
      ?> 

  </form>

  </div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </main> 

  <script src="/agua/admin/libs/bootstrap-5.2.3-dist/js/bootstrap.js" crossorigin="anonymous"> </script>
 <script>
    <?php if(isset($mensaje)){  ?>
    swal.fire({icon:"success", title:"<?php echo $mensaje; ?>",confirmButtonColor: "#3085d6",
    confirmButtonText: "Si?"}).then((result) => {
    if (result.isConfirmed) {
    window.location.href = "login.php";
    }
    });
    <?php } ?>
  </script>
