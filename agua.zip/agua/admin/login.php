
<?php
date_default_timezone_set("America/Bogota");
header("strict-transport-security:max-age=600"); 
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: script-src 'self' 'unsafe-eval' 'unsafe-inline' ;style-src 'self';form-action 'self' ");
$url_base="https://".$_SERVER['SERVER_NAME'];
include("./bd.php");
include("sesion.php");

if (!isset($_SESSION)) {  
  iniciar_sesion();
  correr_session(); 
  if(!isset($_SESSION['tocte']))
  
  {
    $hora = date('H:i');
    $session_id = session_id();
    $token = hash('sha256', $hora.$session_id);
    $_SESSION['tocte'] = $token;

  }
}

if(($_POST)&&($_SESSION['tocte']==$_POST['csrf_token']))
{
  $usuario=(isset($_POST['usuario']))?$_POST['usuario']:"";
  $password=(isset($_POST['password']))?$_POST['password']:"";
  $options=(isset($_POST['options']))?$_POST['options']:"";
 // echo "Resultado de inyeccion usuario es:  ".$usuario."<br>";
  /*Proceso de saneamiento de variables y prevención de inyección Sql*/
  $usuario=$conexion->quote($usuario);
  $password=$conexion->quote($password);
  $options=$conexion->quote($options);
  $caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
  $usuario = trim(str_replace($caracteresNoPermitidos,'',$usuario));
  $password = trim(str_replace($caracteresNoPermitidos,'',$password));
  $options=trim(str_replace($caracteresNoPermitidos,'',$options));
  /*Fin de saneamiento */
  /*busca si existe el usuario en la base de datos*/ 
 try {
  $sentencia=$conexion->prepare("SELECT id_acceso,password,cargo,f_inicio,f_final,anio_lectivo,correo,intentos,fecha_caducidad,aplicar_2fa,activo,dia_hora_bloqueo,imagen_qr FROM usuario_acceso WHERE login=:txtusuario  " );
  $sentencia->bindParam(':txtusuario',$usuario,PDO::PARAM_STR);
  $sentencia->execute();
 //echo $sentencia->debugDumpParams()."<br>";
  $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);
}catch(PDOException $e){

echo "Error";
}
 
  if (($sentencia->rowCount())<1)
  {
   $mensaje="El Usuario i/o Contraseña es incorrecto";
  }else 
  {
  if (password_verify($password, $lista_usuario['password']))  {
        
        /*Verificacion 2FA por email si esta activo */
        if(($lista_usuario['aplicar_2fa']=="email")&&($lista_usuario['activo']=="si"))
           {
            $codigo="";
            /*generacion de codigo aleatorio*/ 
            for($i=0;$i<3;$i++){$codigo=$codigo."".rand(1,200);}            
            /*hash del codigo*/
             $timeTarget = 0.05; // 50 milisegundos 
             $coste = 8;
          do {
             $coste++;
             $inicio = microtime(true);
             password_hash("test", PASSWORD_BCRYPT, ["cost" => $coste]);
             $fin = microtime(true);
             }   while (($fin - $inicio) < $timeTarget);
                /*echo "Coste apropiado encontrado: " . $coste . "\n";*/
                $opciones = [
               'cost' => $coste,
                    ];
             $codigo_hash=password_hash($codigo, PASSWORD_BCRYPT, $opciones);
             /*fin del hash de codigo*/ 
             $correo=$lista_usuario['correo'];
             $archivo=$lista_usuario['imagen_qr'];
             $id_acceso=$lista_usuario['id_acceso'];
             $hora=date("H:i:s");
             $sentencia_update=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion=:codigo,hora_recuperacion=:txthora WHERE id_acceso=:idacceso");
             $sentencia_update->bindParam(':codigo',$codigo_hash);
             $sentencia_update->bindParam(':txthora',$hora);
             $sentencia_update->bindParam(':idacceso',$id_acceso);
             $sentencia_update->execute();
             /*enviamos un correo con el codigo de verificación generado*/ 
             include("./libs/PHPMailer/mail_verificacion.php");

             $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
             $_SESSION['usuario']=$usuario;
             $MM_redirectLoginSuccess ="verificacion.php";
             header("Location: " . $MM_redirectLoginSuccess );
           }
           /* Verificación 2FA por QR */
           if(($lista_usuario['aplicar_2fa']=="QR")&&($lista_usuario['activo']=="si"))
           {
            
             $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
             $_SESSION['usuario']=$usuario;
             $MM_redirectLoginSuccess ="verificacion.php";
             header("Location: " . $MM_redirectLoginSuccess );
           }  
            /* Procedimiento de verificacion y desbloqueo de usuario */
            if(($lista_usuario['intentos']>=4)&&($lista_usuario['activo']=="bloqueado"))
            {
              $date1 = strtotime($lista_usuario['dia_hora_bloqueo']);
              $date2 = strtotime(date('Y-m-d h:i:s'));
              $horas = abs($date2 - $date1)/3600;   
              if($horas>24)
              {              
              
             
              /*Pasamos a desbloquear si ha pasado 24 horas pero se activa un mecanismos 2FA de verificación*/
              for($i=0;$i<3;$i++){$codigo=$codigo."".rand(1,200);}
              /*hash del codigo*/
              $timeTarget = 0.05; // 50 milisegundos 
              $coste = 8;
           do {
              $coste++;
              $inicio = microtime(true);
              password_hash("test", PASSWORD_BCRYPT, ["cost" => $coste]);
              $fin = microtime(true);
              }   while (($fin - $inicio) < $timeTarget);
                 /*echo "Coste apropiado encontrado: " . $coste . "\n";*/
                 $opciones = [
                'cost' => $coste,
                     ];
              $codigo_hash=password_hash($codigo, PASSWORD_BCRYPT, $opciones); 
              /*fin del hash */
              $correo=$lista_usuario['correo'];
              $archivo=$lista_usuario['imagen_qr'];
              $id_acceso=$lista_usuario['id_acceso'];
              $hora=date("H:i:s");
              $sentencia_update=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion=:codigo,hora_recuperacion=:txthora,dia_hora_bloqueo='',activo='si' WHERE id_acceso=:idacceso");
              $sentencia_update->bindParam(':codigo',$codigo_hash);
              $sentencia_update->bindParam(':txthora',$hora);
              $sentencia_update->bindParam(':idacceso',$id_acceso);
              $sentencia_update->execute();
             
              if($lista_usuario['aplicar_2fa']=="email"){
              /*enviamos un correo*/ 
              include("./libs/PHPMailer/mail_verificacion.php");
              } 
              $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
              $_SESSION['usuario']=$usuario;
              $MM_redirectLoginSuccess ="verificacion.php";
              header("Location: " . $MM_redirectLoginSuccess );                         
            
            }else{
              
             echo ".";
             $mensaje="La autenticacion ha sido desactivada vuelva a intentar luego de 24 horas"; 

             }
           
            }
        /* Procedimiento de autenticación directa sin aplicación de 2FA */
           if(($lista_usuario['aplicar_2fa']=="")&&($lista_usuario['activo']=="si"))
           {  
              $_SESSION['id_acceso']=$lista_usuario['id_acceso'];
              $_SESSION['usuario']=$usuario;
              $_SESSION['cargo']=$lista_usuario['cargo'];
              $_SESSION['logeado']=true;
              $_SESSION['f_inicio_usuario']=$lista_usuario['f_inicio'];
              $_SESSION['f_final_usuario']=$lista_usuario['f_final'];
              $fecha_caducidad=$lista_usuario['fecha_caducidad'];
              $anio_lectivo=$lista_usuario['anio_lectivo'];
              $sentencia_anio=$conexion->prepare("SELECT * FROM a_lectivo WHERE anio_lectivo=:txtanio ");
              $sentencia_anio->bindParam(':txtanio',$anio_lectivo);
              $sentencia_anio->execute();
              $lista_anio=$sentencia_anio->fetch(PDO::FETCH_LAZY);
              $_SESSION['anio_lectivo']=$lista_anio['anio_lectivo'];
              $_SESSION['f_inicio_periodo']=$lista_anio['f_inicio'];
              $_SESSION['f_final_periodo']=$lista_anio['f_final'];  
              $MM_redirectLoginSuccess ="index.php";
              header("Location: " . $MM_redirectLoginSuccess );
            }

  } else
      { 
        /* En caso de que la autenticación es incorrecta incrementa los intentos de de acceso y
        si los intentos son mayores a 4 bloquea al acceso al usuario durante 24 hora
        */
        
        $mensaje="El Usuario i/o Contraseña es incorrecto";
        /*verificacion de intentos*/
        $usuario=(isset($_POST['usuario']))?$_POST['usuario']:"";
        /*Proceso de saneamiento de variables y prevención de inyección Sql*/
        $caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
        $usuario = str_replace($caracteresNoPermitidos,'',$usuario);
           
        $sentencia=$conexion->prepare(" UPDATE usuario_acceso SET intentos=intentos+1  WHERE login=:txtusuario; ");
        $sentencia->bindParam(':txtusuario',$usuario);
        $sentencia->execute();
       if($lista_usuario['intentos']>=4)
        {
        /* se bloquea la cuenta y enviamos un correo electronico o watsap de alerta */
        $fecha_hora=date("Y-m-d h:i:s");
        $usuario=(isset($_POST['usuario']))?$_POST['usuario']:"";
        $caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
        $usuario = str_replace($caracteresNoPermitidos,'',$usuario);
        $sentencia_debloqueo=$conexion->prepare(" UPDATE usuario_acceso SET activo='bloqueado', dia_hora_bloqueo=:txtdatetime  WHERE login=:txtusuario; ");
        $sentencia_debloqueo->bindParam(':txtdatetime',$fecha_hora);
        $sentencia_debloqueo->bindParam(':txtusuario',$usuario);
        $sentencia_debloqueo->execute();
        /* envio de correo de alerta por mail o watsap indicando que ha sido bloqueado */ 
        $correo=$lista_usuario['correo'];
        $archivo=$lista_usuario['imagen_qr'];      
        include("./libs/PHPMailer/mail_bloqueo.php");
        $mensaje="La autenticacion ha sido desactivada vuelva a intentar luego de 24 horas";   
            
        }      
      }
  }    
}
?>
<!doctype html>
<html lang="es">
<head>
  <title>Login</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS v5.2.1 -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">  -->
  <link href="/agua/admin/libs/bootstrap-5.2.3-dist/css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
  <script type="text/javascript" src="/agua/admin/libs/lectorqr/js/instascan.js" ></script> 
  <script src="/agua/admin/js/jquery-3.6.3.min.js" ></script>
  <script src="admin.js" lang="javascript"></script>
</head>
<body>
  <header>
    <!-- place navbar here -->
  </header>
  <main>
  <br><br>
<div class="container">
  <div class="row">
    <div class="col-4"></div>
      <div class="col-4">
        <div class="card">
        <div class="card-header">Login</div>
        <div class="card-body">
        <?php if(isset($mensaje)){  ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
            aria-label="Close"
          ></button>
          <strong><?php echo $mensaje ?></strong>
        </div>        
        <script>
          var alertList = document.querySelectorAll(".alert");
          alertList.forEach(function (alert) {
            new bootstrap.Alert(alert);
          });
        </script>        
        <?php } ?>
<form action="" method="post" name="formulario" autocomplete="off">
    
      <input
      type="hidden"
      name="csrf_token"
      id="csrf_token"
      value="<?php
      if(isset($_SESSION['tocte'])){
      echo  $_SESSION['tocte'];
       }
      
      ?>"
      />  
      <div class="mb-3">
      <label for="usuario" class="form-label">Usuario</label>
      <input
      type="text"
      class="form-control"
      name="usuario"
      id="usuario"
      aria-describedby="helpId"
      placeholder=""
      autocomplete="FALSE"
      />  
    </div>
     
    <script>
    //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
    $('#usuario').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
    });
    </script>   
    <div class="mb-3">
      <label for="password" class="form-label">Contraseña</label>
      <input
      type="text"
      class="form-control"
      name="password"
      id="password"
      aria-describedby="helpId"
      placeholder="Ingrese el password"
      oninput="ocultar()"  
         
      />
    </div>
    <script>
    //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
    $('#password').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
    });
    </script> 
      
     <button type="submit" 
      class="btn btn btn-primary" 
      value="Entrar"
      name="entrar"
      id="entrar"
      data-bs-toggle="tooltip"
      data-bs-placement="top" title="Ingresar al Sistema"
      title="Ingresar al sistema"      
      >
      Entrar
      </button>   

      <button type="button" 
      class="btn btn btn-primary" 
      data-bs-placement="top" 
      title="Activar la Camara para Indicar su codigo QR"
      data-bs-toggle="modal" 
      data-bs-target="#exampleModal"
      onclick="mostrar(),activar_camara()" >
      QR
      </button>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Codigo QR</h5>
        <button type="button" name="close" id="close" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="apagar()"></button>
      </div>
    <div class="modal-body" id="divqr">
      <style>
        #preview {
            width: 500px;
            height: 500px;
            margin: 0px auto;
        }
      </style>
    <video id="preview"></video>
    <div class="btn-group btn-group-toggle mb-5" data-toggle="buttons">
        <label class="btn btn-primary active">
        <input type="radio" name="options" value="1" autocomplete="off" checked> Frontal Camera
        <script>
        //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
        $('#options').on('input', function () { 
        this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
        });
        </script> 
        </label>
        <label class="btn btn-secondary">
        <input type="radio" name="options" value="2" autocomplete="off"> Detraz Camera 1
        <script>
        //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
        $('#options').on('input', function () { 
        this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
        });
        </script>   
      </label>
        <label class="btn btn-secondary">
        <input type="radio" name="options" value="3" autocomplete="off"> Detraz Camera 2
        <script>
        //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
        $('#options').on('input', function () { 
        this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
        });
        </script>   
      </label>
    </div>
      ...
     
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>        
      </div>
    </div>
  </div>
</div>
<div class="mb-3"><a href="recuperar.php">Olvido la contraseña?</a> </div>
</form>
        </div>
      </div>
    </div>
  </div>
</div>
  </main>
  <footer>
    <!-- place footer here -->
  </footer>
  
  <script src="/agua/admin/js/popper.min.js" crossorigin="anonymous"></script>
  <script src="/agua/admin/libs/bootstrap-5.2.3-dist/js/bootstrap.js" crossorigin="anonymous"></script>
  <script src="/agua/admin/libs/bootstrap-5.2.3-dist/js/bootstrap.bundle.js" crossorigin="anonymous"></script>
  <script>
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
  })
  var myModal = document.getElementById('exampleModal')
  var myInput = document.getElementById('divqr')
  myModal.addEventListener('shown.bs.modal', function () {
  myInput.focus()
  })
  </script>
</body>
</html>