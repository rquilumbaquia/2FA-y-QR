<?php include("../../bd.php"); ?>

<?php if($_POST)
{

    $nombre_anio=$_POST['nombre_anio'];
    $f_inicio=$_POST['f_inicio'];
    $f_final=$_POST['f_final'];
    $precio_por_dia_mora=$_POST['precio_por_dia_mora'];
    $tarifa_base=$_POST['tarifa_base'];
    $limiteconsumo=$_POST['limiteconsumo'];
    $valorconsumo=$_POST['valorconsumo'];
    
    $sentencia_poner=$conexion->prepare("INSERT INTO a_lectivo (anio_lectivo, nombre_anio, f_inicio, f_final, precio_por_dia_mora, tarifa_base, limiteconsumo, valorconsumo)VALUES('',:txtnombreanio,:txtfinicio,:txtffinal,:txtpreciopordiamora,:txttarifabase,:txtlimiteconsumo,:txtvalorconsumo) " );
    $sentencia_poner->bindParam(':txtnombreanio',  $nombre_anio);
    $sentencia_poner->bindParam(':txtfinicio',   $f_inicio);
    $sentencia_poner->bindParam(':txtffinal',  $f_final);
    $sentencia_poner->bindParam(':txtpreciopordiamora', $precio_por_dia_mora);
    $sentencia_poner->bindParam(':txttarifabase', $tarifa_base);

    $sentencia_poner->bindParam(':txtlimiteconsumo', $limiteconsumo);
    $sentencia_poner->bindParam(':txtvalorconsumo', $valorconsumo);
    $sentencia_poner->execute();

    
    
    $MM_redirectLoginSuccess ="anio_lectivos.php";
    header("Location: " . $MM_redirectLoginSuccess );

} ?>

<?php include("../../templates/header.php"); ?>

<script src="../../../admin/libs/CalendarControl.js" type="text/javascript"></script>
<link href="../../../admin/libs/CalendarControl.css"  rel="stylesheet" type="text/css">

<div class="card">
    <div class="card-header">Obligaciones por llave</div>
    <div class="card-body">
        <form action="" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nombre_anio" class="form-label">Nombre del Año </label>
            <input
                type="text"
                class="form-control"
                name="nombre_anio"
                id="nombre_anio"
                aria-describedby="helpId"
                placeholder="ej. año 2024"
                
            />
        </div>
        <div class="mb-3">
            <label for="f_inicio" class="form-label">Fecha inicio</label>
            <input
                type="text"
                class="form-control"
                name="f_inicio"
                id="f_inicio"
                aria-describedby="helpId"
                placeholder="Fecha inicial"
                onclick="showCalendarControl(this);"
            />
            
        </div>
        <div class="mb-3">
            <label for="f_final" class="form-label">Fecha de finalizacion</label>
            <input
                type="text"
                class="form-control"
                name="f_final"
                id="f_final"
                aria-describedby="helpId"
                placeholder="Ingres fecha de finalizacion"
                onclick="showCalendarControl(this);"
            />
            
        </div>
        <div class="mb-3">
            <label for="precio_por_dia_mnora" class="form-label">Precio por dia mora</label>
            <input
                type="text"
                class="form-control"
                name="precio_por_dia_mora"
                id="precio_por_dia_mnora"
                aria-describedby="helpId"
                placeholder=""
                
            />
            
        </div>
        <div class="mb-3">
            <label for="tarifa_base" class="form-label">Tarifa Base</label>
            <input
                type="text"
                class="form-control"
                name="tarifa_base"
                id="tarifa_base"
                aria-describedby="helpId"
                placeholder=""
                
            />
            
        </div>

        <div class="mb-3">
            <label for="limiteconsumo" class="form-label">Limite de consumo</label>
            <input
                type="text"
                class="form-control"
                name="limiteconsumo"
                id="limiteconsumo"
                aria-describedby="helpId"
                placeholder=""
                
            />
            
        </div>

        <div class="mb-3">
            <label for="valorconsumo" class="form-label">Valor por el consumo</label>
            <input
                type="text"
                class="form-control"
                name="valorconsumo"
                id="valorconsumo"
                aria-describedby="helpId"
                placeholder=""
                
            />
            
        </div>

        
        <button
            type="submit"
            class="btn btn-success"
        >
            Guardar
        </button>
        
        <a
            name=""
            id=""
            class="btn btn-primary"
            href="anio_lectivos.php"
            role="button"
            >Cancelar</a
        >
        </form>
       
    </div>
    <?php include("../../templates/footer.php"); ?>