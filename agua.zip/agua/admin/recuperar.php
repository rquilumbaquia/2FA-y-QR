<?php 
include("./bd.php");
date_default_timezone_set("America/Bogota");
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'self';form-action 'self' ");
$url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/";
include("sesion.php");
if (!isset($_SESSION)) {
  correr_session(); 
 }

if((isset($_POST['correo']))&&($_SESSION['tocte']==$_POST['csrf_token']))
{
    /*Revisa si existe el usuario con el correo*/
    /*Proceso de saneamiento de variables y prevención de inyección Sql*/
    $caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
    $correo=(isset($_POST['correo']))?$_POST['correo']:"";  
  /*Proceso de saneamiento de variables y prevención de inyección Sql*/
    $caracteresNoPermitidos = array(" ","!",'"',"#","%","&","'","(",")","+","=",";");   
    $correo = str_replace($caracteresNoPermitidos,'',$correo);
    $sentencia=$conexion->prepare("SELECT * FROM usuario_acceso WHERE correo=:txtcorreo AND activo='si'");
    $sentencia->bindParam(':txtcorreo',$correo);
    $sentencia->execute();
    if($sentencia->rowCount()>0)
    {
    $lista_usuario=$sentencia->fetch(PDO::FETCH_LAZY);
    $id_acceso=$lista_usuario['id_acceso'];
    $archivo=$lista_usuario['imagen_qr'];
    $codigo="";   
    for($i=0;$i<3;$i++){$codigo=$codigo."".rand(1,200);}
    /*Hash del codigo aleatorio */
    $timeTarget = 0.05; // 50 milisegundos 
    $coste = 8;
 do {
    $coste++;
    $inicio = microtime(true);
    password_hash("test", PASSWORD_BCRYPT, ["cost" => $coste]);
    $fin = microtime(true);
    }   while (($fin - $inicio) < $timeTarget);
       /*echo "Coste apropiado encontrado: " . $coste . "\n";*/
       $opciones = [
      'cost' => $coste,
           ];
    $codigo_hash=password_hash($codigo, PASSWORD_BCRYPT, $opciones); 
    /*fin del hash */
    /*almacena el hash en base de datos*/
    $hora=date("H:i:s");
    $sentencia_update=$conexion->prepare("UPDATE usuario_acceso SET codigo_recuperacion=:codigo,hora_recuperacion=:txthora WHERE id_acceso=:idacceso");
    $sentencia_update->bindParam(':codigo',$codigo_hash);
    $sentencia_update->bindParam(':txthora',$hora);
    $sentencia_update->bindParam(':idacceso',$id_acceso);
    $sentencia_update->execute();
    include("../admin/libs/PHPMailer/mail.php");
    $_GET['autentificar']="si";
    $_GET['id_acceso']=$id_acceso;
   }else{
        $mensaje="No tiene permiso para recuperar cuentas";
        echo ".";       
     //   $MM_redirectLoginSuccess ="login.php?mensaje=".$mensaje;
        //header("Location: " . $MM_redirectLoginSuccess );
      
       }
}
?>
<!DOCTYPE html>
<head lang="ES" >
</head>
<script src="./js/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="./css/sweetalert2.min.css">
<link href="/agua/admin/libs/bootstrap-5.2.3-dist/css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
<main>
  <br><br>
<div class="container">
  <div class="row">
    <div class="col-4"></div>
      <div class="col-4">
        <div class="card">
        <div class="card-header">Recuperacion de contraseña</div>
        <div class="card-body">
        <div class="mb-3">
<?php 
if((isset($_GET['autentificar'])&&($_GET['autentificar']=='si')))
{ 
?>
<form method="post" action="cambiopassword.php" >    
      <input
      type="hidden"
      name="csrf_token"
      id="csrf_token"
      value="<?php
      if(isset($_SESSION['tocte'])){
      echo  $_SESSION['tocte'];      
      }
      ?>"
      />  
<div class="mb-3">        
    <label for="codigo_recuperacion" class="form-label">Ingrese codigo temporal solo tiene 5 Minutos</label>
    <input
        type="text"
        class="form-control"
        name="codigo_recuperacion"
        id="codigo_recuperacion"
        aria-describedby="helpId"
        placeholder="codigo que llegoo a su correo"
        value=""
    />
    <script>
    //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
    $('#codigo_recuperacion').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
    });
    </script> 
    <input
        type="hidden"
        class="form-control"
        name="id_acceso"
        id="id_acceso"
        aria-describedby="helpId"
        placeholder="codigo que llegoo a su correo"
        value="<?php echo $_GET['id_acceso']; ?>"
    />
   
    <button
         class="btn btn-outline-primary"
         type="submit"
        value="Enviar"
    >Enviar
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
    <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76z"/>
     </svg> 

    </button>
      
</div>
</form>
<?php
}  else {
?>
<form method="post" action="" >   
      <input
      type="hidden"
      name="csrf_token"
      id="csrf_token"
      value="<?php
      
      echo  $_SESSION['tocte'];
      
      
      ?>"
      />  
<div class="mb-3">
    <label for="" class="form-label">Email
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"/>
    </svg> 
    </label>
    <input
        type="text"
        class="form-control"
        name="correo"
        id="correo"
        aria-describedby="helpId"
        placeholder="Ingrese su Correo electronico"
    />
    <script>
    //Asociamos evento 'keypress', el cual ejecuta una función al momento de presionar o pulsar cualquier tecla
    $('#correo').on('input', function () { 
      this.value = this.value.replace(/[^0-9a-zA-ZñÑáéíóúÁÉÍÓÚ$%?¿Ç{}./::,@* _-]/g,'');
    });
    </script>    
    <button
        class="btn btn-outline-primary"
        type="submit"
        value="Enviar"
    >Enviar
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
      <path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76z"/>
      </svg> 
    </button>
     <a
        name=""
        id=""
        class="btn btn-outline-primary"
        href="login.php"
        role="button"
        >Cancelar</a>   
</div>
</form>
<?php  }  ?>
</div>
        </div>
        </div>
        </div>
      </div>
    </div>
  </main> 
</html>
<script src="/agua/admin/libs/bootstrap-5.2.3-dist/js/bootstrap.js" crossorigin="anonymous"></script>

<script>
    <?php if(isset($mensaje)){  ?>
    swal.fire({icon:"success", title:"<?php echo $mensaje; ?>",confirmButtonColor: "#3085d6",
    confirmButtonText: "Si?"}).then((result) => {
    if (result.isConfirmed) {
    window.location.href = "login.php";
    }
    });
    <?php } ?>
  </script>

