<?php
date_default_timezone_set("America/Bogota");
setlocale( LC_ALL, "es_EC.UTF-8" );
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
///header("Content-Security-Policy: script-src 'self'; ");
$url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/";

//echo $_SERVER['DOCUMENT_ROOT']."<br>";
//echo dirname( __DIR__ );

include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php");

if (!isset($_SESSION)) 
{
    correr_session();
}
/*Inicio función para espiración de sessión */
if(isset($_SESSION['deleted_time']) ) {

   //Tiempo en segundos para dar vida a la sesión.
  $inactivo = 600;//10min en este caso.
  //Calculamos tiempo de vida inactivo.
  $vida_session = time() - $_SESSION['deleted_time'];
         //Compraración para redirigir página, si la vida de sesión sea mayor a el tiempo insertado en inactivo.
      if($vida_session > $inactivo)      {
          //Removemos sesión.
          session_unset();
          //Destruimos sesión.
          session_destroy();              
          //Redirigimos pagina.

          $mensaje="La sessiòn fue finalizada";
          echo $mensaje;
          $MM_redirectLoginSuccess =$url_base."login.php";
          header("Location: " . $MM_redirectLoginSuccess );
          exit();
      } else {  // si no ha caducado la sesion, actualizamos
        $_SESSION['deleted_time'] = time();
      }

} else {
  //Activamos sesion tiempo.
  $_SESSION['deleted_time'] = time();
}
/*Fin de tiempo de expiracio */

/*Si no existe un usuario redireccionamiento a la pagina de autenticación */
if(!isset($_SESSION['usuario']))
 {
 $MM_redirectLoginSuccess =$url_base."login.php";
 header("Location: " . $MM_redirectLoginSuccess );
 }
?>
<!doctype html>
<html lang="es">
<head>
  <title>Sistema de Agua</title>
  <!-- Required meta tags -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no", charset="utf-8">

    <link href="<?php echo $url_base ?>libs/bootstrap-5.2.3-dist/css/bootstrap.css" rel="stylesheet"  crossorigin="anonymous">
<script     
			  src="<?php echo $url_base ?>js/jquery-3.6.3.min.js"
			  integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU="
			  crossorigin="anonymous">
</script>

    <link rel="stylesheet" type="text/css" href="<?php echo $url_base ?>css/jquery.dataTables.min.css">
    <script type="text/javascript" charset="utf8" src="<?php echo $url_base ?>js/jquery.dataTables.min.js"></script>
     
</head>
<body>
  <header>
    <!-- place navbar here -->
    <ul
        class="nav nav-tabs"
      >
      <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            data-bs-toggle="dropdown"
            href="#"
            role="button"
            aria-haspopup="true"
            aria-expanded="false"
            >Administrador</a
          >
          <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo $url_base;?>">Inicio</a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/usuarios/">Usuarios del sistema</a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/configuraciones/">Configuraciones</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Otros</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            data-bs-toggle="dropdown"
            href="#"
            role="button"
            aria-haspopup="true"
            aria-expanded="false"
            >Consumo de Agua</a
          >
          <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/usuarios_agua/">Usuarios de Agua </a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/aportes/por_llave/">Aplicar aporte por Llaves</a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/aportes/por_usuario/">Aplicar aporte por Usuario</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/lecturas/">Lecturas</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            data-bs-toggle="dropdown"
            href="#"
            role="button"
            aria-haspopup="true"
            aria-expanded="false"
            >Actividades</a
          >
          <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/actividades/">Aplicar Actividades ausuarios </a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/actividades/rayar.php">Rayar actividades</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/lecturas/">    </a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a
            class="nav-link dropdown-toggle"
            data-bs-toggle="dropdown"
            href="#"
            role="button"
            aria-haspopup="true"
            aria-expanded="false"
            >Contabilidad</a
          >
          <div class="dropdown-menu">
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/contabilidad/carteras.php">Carteras del Periodo</a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/contabilidad/asignar_cartera.php">Asignar obligaciones a cartera</a>
            <a class="dropdown-item" href="<?php echo $url_base;?>secciones/contabilidad/cierre_de_caja.php">Cierre de caja diario</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Gastos</a>
            <a class="dropdown-item" href="#">Otros</a>
          </div>
          
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              data-bs-toggle="dropdown"
              href="#"
              role="button"
              aria-haspopup="true"
              aria-expanded="false"
              >Reportes</a
            >
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/lista_general.php">Lista general de usuarios</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/lista_llaves.php">Lista general por llaves</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/lista_nuevos.php">Usuarios Nuevos</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/lista_tercera.php">Usuarios de Tercera Edad</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/aportes_del_usuario.php">Aportes del usuario</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/recaudacion_por_obligaciones.php">Recaudacion por obligaciones</a>
              <a class="dropdown-item" href="<?php echo $url_base;?>secciones/reportes/reporte_por_obligaciones.php">Reporte general por obligaciones</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Reporte general por rayas</a>
              <a class="dropdown-item" href="#">Otros</a>
            </div>

        </li>
        <li class="nav-item">
          <a href="<?php echo $url_base;?>cerrar.php?csrf_token=<?php if(isset($_SESSION['tocte'])){echo $_SESSION['tocte'];}  ?>" class="nav-link">Cerrar Sesion</a>  
        </li>
      </ul>
   
  </header>
  <main class="container" >
  <br/>
 

