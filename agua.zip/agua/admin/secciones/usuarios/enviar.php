<?php 
include("../../bd.php");
$id_acceso=(isset($_POST['id_acceso']))?$_POST['id_acceso']:"";
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuario_acceso WHERE id_acceso=:txtidacceso ");
$sentencia_usuario->bindParam(':txtidacceso',$id_acceso);
$sentencia_usuario->execute();
$lista_usuarios=$sentencia_usuario->fetch(PDO::FETCH_LAZY);
$correo=$lista_usuarios['correo'];
$archivo=$lista_usuarios['imagen_qr'];
$credenciales= $lista_usuarios['login'] ;
$nombre_usuario=$lista_usuarios['nombre'];
include("../../libs/PHPMailer/mail_credenciales.php");
echo "Enviado ".$correo;
?>
