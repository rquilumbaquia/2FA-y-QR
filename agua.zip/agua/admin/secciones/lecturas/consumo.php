<?php 
include("../../bd.php");

$id_aporte=$_POST['id_aporte'];
$sentencia_revisar=$conexion->prepare("SELECT * FROM aporte_llave where  id_aporte=:txtidaporte " );
$sentencia_revisar->bindParam(':txtidaporte',$id_aporte);
$sentencia_revisar->execute();
$lista=$sentencia_revisar->fetch(PDO::FETCH_LAZY);

$lectura=$lista['medidor'];
echo  $lectura;

?>