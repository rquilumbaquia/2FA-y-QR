
function ocultar()
{
    document.getElementById('password').type = 'password';
}
function mostrar()
{
    document.getElementById('password').type = 'text';
}

function activar_camara(){
        var scanner = new Instascan.Scanner({
        video: document.getElementById('preview'),
        scanPeriod: 5,
        mirror: false
    });
    scanner.addListener('scan', function (content) {          
        
        $.ajax({
            type: 'POST',  // Envío con método POST
            url: 'desifrado_qr.php',  // fichero para desifrar el valor de la imagen
            data: { dato:content  } // Datos que se envían
            }).done(function( msg ) {
                  // Función que se ejecuta si todo ha ido bien
            $("#usuario").val(msg);
           var contenido=document.getElementById("usuario").value;
           content=contenido;
           var longitud= content.length;       
           var posicion = content.search(":");
           var login=content.substring(0, posicion)
           var password=content.substring(posicion+1,longitud)
           // alert("Usuario identificado: "+login);    
           document.getElementById("usuario").value = login.trim() ;
           document.getElementById("password").value = password.trim() ;
            // alert("Imagen Procesado  ");
           document.getElementById("entrar").click();
        
        
            }).fail(function (jqXHR, textStatus, errorThrown){ // Función que se ejecuta si algo ha ido mal
            // Mostramos en consola el mensaje con el error que se ha producido

            alert("The following error occured: "+ textStatus +" "+ errorThrown); 
           });

    });
    Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
   // alert('Camara: '+ cameras.length);
            scanner.start(cameras[0]);
            $('[name="options"]').on('change', function () {
                if ($(this).val() == 1) {
                    if (cameras[0] != "") {
                        scanner.start(cameras[0]);
                    } else {
                        alert('No Front camera found!');
                    }
                } else if ($(this).val() == 2) {
                    if (cameras[1] != "") {
                        scanner.start(cameras[1]);
                    } else {
                        alert('No Back camera 1 found!');
                    }
                } else if ($(this).val() == 3) {
                    if (cameras[2] != "") {
                        scanner.start(cameras[2]);
                    } else {
                        alert('No Back camera 2 found!');
                    }
                }
            });
        } else {
            console.error('No cameras found.');
            alert('No cameras found.');
        }
    }).catch(function (e) {
        console.error(e);
        alert(e);
    });
}

function apagar(){
    
    var scanner = new Instascan.Scanner({
        video: document.getElementById('preview'),
        scanPeriod: 5,
        mirror: false
    });
    scanner.addListener('scan', function (content) {
        alert("Resultado "+content);
        //window.location.href=content;
    });
    scanner.stop;
    Instascan.stop;
    Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
            
            
            scanner.stop;
            scanner.stop(cameras[0]);
           
        } else {
            console.error('No cameras found.');
            alert('No cameras found.');
        }
    }).catch(function (e) {
        console.error(e);
        alert(e);
    });



}





