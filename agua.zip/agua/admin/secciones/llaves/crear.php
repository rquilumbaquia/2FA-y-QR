<?php 

include("../../bd.php");
include($_SERVER['DOCUMENT_ROOT']."/agua/admin/sesion.php");

if (!isset($_SESSION)) 
{
    correr_session();
}

if($_GET)
{
    $id_usuario=(isset($_GET['id_usuario']))?$_GET['id_usuario']:"";
    $sector="";
    $id_acceso="1";
    $orden_lista="";
    $codigo_medidor="";
    $suspendido="no";
    $informacion="";
            
    $sentencia=$conexion->prepare("INSERT INTO llaves (id_usuario,sector,id_acceso,orden_lista,codigo_medidor,suspendido,informacion)values(:txtidusuario,:txtsector,:txtidacceso,:txtordenlista,:txtcodigomedidor,:txtsuspendido,:txtinformacion); ");
    $sentencia->bindParam(':txtidusuario',$id_usuario);
    $sentencia->bindParam(':txtsector', $sector);
    $sentencia->bindParam(':txtidacceso',$id_acceso);
    $sentencia->bindParam(':txtordenlista',$orden_lista);
    $sentencia->bindParam(':txtcodigomedidor',$codigo_medidor);
    $sentencia->bindParam(':txtsuspendido',$suspendido);
    $sentencia->bindParam(':txtinformacion',$informacion);
    $sentencia->execute();

}

$MM_redirectLoginSuccess ="index.php?id_usuario=".$_GET['id_usuario']."&csrf_token=".$_SESSION['tocte'];
header("Location: " . $MM_redirectLoginSuccess );

?>
