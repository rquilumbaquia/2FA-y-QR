

<?php 
header("strict-transport-security:max-age=600");
header("X-Frame-Options: DENY");
header('X-Content-Type-Options: nosniff');
$url_base="https://".$_SERVER['SERVER_NAME']."/agua/admin/";

   include("sesion.php");
   if (!isset($_SESSION)) 
   {
    // iniciar_sesion();
     correr_session();
   }
    if(($_SESSION['tocte']==$_GET['csrf_token']))
    {
    $url_base="https://".$_SERVER['SERVER_NAME'];
    session_unset();
    session_destroy(); 
    regenerar_session_id();
    $MM_redirectLoginSuccess =$url_base."/agua/admin/"."login.php";
    header("Location: " . $MM_redirectLoginSuccess );
    }
 



?>