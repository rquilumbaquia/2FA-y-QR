<?php 
//include_once __DIR__ .'/csrf/libs/csrf/csrfprotector.php';

//Initialise CSRFGuard library

//csrfProtector::init();
?>


<?php

// Funcion inicio de una nueva sessión
function correr_session() {
    session_name('mySession');  
    session_start(); 
   
    // Destrucción de sesiones antiguas
    if (!empty($_SESSION['deleted_time']) && $_SESSION['deleted_time'] < time() - 600) {
        session_destroy();
        session_start();
    }
}
// funcion de regeneración de ID de session
function regenerar_session_id() {
    // Llame a session_create_id() mientras la sesión está activa 
    // Se asegura de que existe colisiones
    if (session_status() != PHP_SESSION_ACTIVE) {
        session_start();
    }
    //Funcion para generación de id aleatrorio.
    $codigo="";
    for($i=0;$i<3;$i++){$codigo=$codigo."".rand(1,200);}
    //fin de función de generació ID aleatoria.
    // Assignación de prefijo de session
    $newid = session_create_id("-".$codigo);
    // Establecer marca de tiempo eliminada.
    $_SESSION['deleted_time'] = time();
    // Finalizar la session
    session_commit();
    // Asegúrese de aceptar el ID de sesión definido por el usuario
    // NOTA: Debe habilitar use_strict_mode para operaciones normales.
    ini_set('session.use_strict_mode', 0);
    // Establecer la nueva sessión
    session_id($newid);
    // Iniciar una session personalizada
    session_start();
}
// use_strict_mode es obligatorio por razones de seguridad.

function iniciar_sesion(){
ini_set('session.use_trans_sid', 0);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_cookies', 1);
ini_set("session.use_trans_sid", 0);
ini_set('session.use_only_cookies',1);
ini_set('session.hash_function',5);
ini_set('session.hash_bits_per_character',5);
ini_set('session.cookie_samesite', 'Strict');

}

?>

