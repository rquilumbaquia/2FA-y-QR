var plano;
var planotxt;

function creaObjetoAjax () { //Mayoría de navegadores
    var obj;
    if (window.XMLHttpRequest) {
       obj=new XMLHttpRequest();
       }
    else { //para IE 5 y IE 6
       obj=new ActiveXObject(Microsoft.XMLHTTP);
       }
    return obj;
    }

function poner_usuario(id_usuario,id_actividad,poner)
{
   
   plano="check"+id_usuario;
     //datos para el envio por POST:
   misdatos="id_usuario="+id_usuario+"&id_actividad="+id_actividad+"&poner="+poner;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","casilla.php",true);
   //Enviar cabeceras para que acepte POST:

   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_poner;
   objetoAjax.send(misdatos);
   

 } 
function recogeDatos_poner() 
{


   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        document.getElementById(plano).innerHTML=miTexto;
   }
                                
}

//

function cantidadraya(id_usuario,id_actividad,valor)
{
   
   planotxt="txt"+id_usuario+"-"+id_actividad;
     //datos para el envio por POST:
   misdatos="id_usuario="+id_usuario+"&id_actividad="+id_actividad+"&valor="+valor;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","cantidad_raya.php",true);
   //Enviar cabeceras para que acepte POST:

   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_cantidadraya;
   objetoAjax.send(misdatos);
   

 } 
function recogeDatos_cantidadraya() 
{


   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        document.getElementById(planotxt).value=miTexto;
   }
                                
}

//
function poner_raya(id_usuario,id_actividad,poner)
{
   
   plano="raya"+id_usuario+"-"+id_actividad;
     //datos para el envio por POST:
   misdatos="id_usuario="+id_usuario+"&id_actividad="+id_actividad+"&poner="+poner;
   //Objeto XMLHttpRequest creado por la función.
    
   objetoAjax=creaObjetoAjax();
   //Preparar el envio  con Open
  
   objetoAjax.open("POST","casilla_raya.php",true);
   //Enviar cabeceras para que acepte POST:

   objetoAjax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   objetoAjax.setRequestHeader("Content-length", misdatos.length);
   objetoAjax.setRequestHeader("Connection", "close");
   objetoAjax.onreadystatechange=recogeDatos_poner_raya;
   objetoAjax.send(misdatos);
   

 } 
function recogeDatos_poner_raya() 
{


   if (objetoAjax.readyState==4 && objetoAjax.status==200) 
   {
        miTexto=objetoAjax.responseText;
        document.getElementById(plano).innerHTML=miTexto;
   }
                                
}


function imprimirSeleccion(nombre,direccion) {
   
   var ficha = document.getElementById(nombre);
   //DataTables_Table_0_filter
  var varhtml=document.getElementById('DataTables_Table_0_length').innerHTML;
  var varhtml_filtro=document.getElementById('DataTables_Table_0_filter').innerHTML;

  document.getElementById('DataTables_Table_0_length').innerHTML="";
  document.getElementById('DataTables_Table_0_filter').innerHTML="";
  
   var ventimp = window.open(' ', 'popimpr');
   ventimp.document.write( ficha.innerHTML );
   ventimp.document.close();
   ventimp.print( );
   ventimp.close();
  
   location.href =direccion;

}

