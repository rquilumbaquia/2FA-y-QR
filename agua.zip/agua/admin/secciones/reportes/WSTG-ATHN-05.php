Owasp   WSTG-CLNT-12  y  WSTG-ATHN-05

<script lang="javascript">

alert("Numero de Seesion Sesion.."+sessionStorage.length);
for (let i = 0; i < sessionStorage.length; i++) {
  const key = sessionStorage.key(i);
  const value = sessionStorage.getItem(key);
  console.log(`${key}: ${value}`);
alert("clave... "+key+"   Valor..."+value );

}



alert("Logitud Local Storage  "+localStorage.length);
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  const value = localStorage.getItem(key);
  console.log(`${key}: ${value}`);
 alert("clave... "+key+"   Valor..."+value );

}
</script>
