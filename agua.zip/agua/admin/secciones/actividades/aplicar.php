<?php 
include("../../templates/header.php"); 
include("../../bd.php");

if(($_GET))
{
    $id_actividad=(isset($_GET['id_actividad']))?$_GET['id_actividad']:"";
    $sentencia=$conexion->prepare("SELECT * FROM actividades WHERE id_actividad=:txtidactividad ");
    $sentencia->bindParam(':txtidactividad', $id_actividad);
    $sentencia->execute();
    $lista_actividad=$sentencia->fetchAll(PDO::FETCH_ASSOC);
}
$sentencia_usuario=$conexion->prepare("SELECT * FROM usuarios where (estado='activo' or estado='nuevo') and tercera_edad='no'  order by apellidos ASC ");
$sentencia_usuario->execute();
$lista_usuarios=$sentencia_usuario->fetchAll(PDO::FETCH_ASSOC);

?>

<script src="actividades.js" type="text/javascript" ></script>
<div class="card">
    <div class="card-header">
        <div
            class="alert alert-primary"
            role="alert"
        >
            <strong>Aplicar :|<?php  foreach($lista_actividad as $registros_actividad){  echo ucwords($registros_actividad['nombre_actividad'])."| Rayas: ";echo $registros_actividad['cantidad_rayas']; echo "|  Fecha ejecucion : ".$registros_actividad['f_ejecucion']."| Observacion: ".$registros_actividad['observacion']."| Valor de multa: ".$registros_actividad['valor_no_cumplir'];   }  ?>| Por Usuarios</strong> 
        </div>
    </div>
      
    <div class="card-body">
    <div
        class="table-responsive-sm"
    >
        <table 
            class="table"
        >
            <thead>
                <tr>
                    
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Direccion</th>
                    <th scope="col">Cedula</th>
                    <th scope="col">Estado</th>
                                       
                    <th scope="col">

                    <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_actividad=<?php echo $_GET['id_actividad'] ?>&poner=poner"
        
        >Todos</a>
        <a
        name=""
        class="btn btn-outline-success"
        id=""
        href="aplicar_todo.php?id_actividad=<?php echo $_GET['id_actividad'] ?>&poner=quitar"
        
        >Quitar</a>
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($lista_usuarios as $registros){ ?>
                <tr class="">
                    <td><?php echo $registros['nombres']; ?></td>
                    <td><?php echo $registros['apellidos']; ?></td>
                    <td><?php echo $registros['direccion']; ?></td>
                    <td><?php echo $registros['cedula']; ?></td>
                    <td><?php echo $registros['estado']; ?></td>
                    <td>
                    <?php 
                    $sentencia_aplicacion=$conexion->prepare("SELECT * FROM rayas_usuario where id_usuario=:txtidusuario and id_actividad=:txtidactividad  ");
                    $sentencia_aplicacion->bindParam(':txtidusuario',$registros['id_usuario']);
                    $sentencia_aplicacion->bindParam(':txtidactividad',$_GET['id_actividad']);
                    $sentencia_aplicacion->execute();                   
                    $resultado=$sentencia_aplicacion->fetchAll(PDO::FETCH_ASSOC);
                    
                    if(($sentencia_aplicacion->rowCount())>0)
                    
                    {
                        ?>
                       
                            <div id="check<?php echo $registros['id_usuario']; ?>">
                            
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    checked
                                    onclick="poner_usuario('<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_actividad']?>','no')"
                                    
                                />
                                

                            </div>
                        <?php

                    }else
                    {
                        ?>
                        
                        <div id="check<?php echo $registros['id_usuario']; ?>">
                                <input
                                    type="checkbox"
                                    class="form-check-input"
                                    name=""
                                    
                                    onclick="poner_usuario('<?php echo $registros['id_usuario']; ?>','<?php echo $_GET['id_actividad'];?>','si')"
                                   
                                />
                        
                         </div>
                        <?php

                    }
                echo "<br>";
                    ?>

                    </td>
                </tr>
            <?php          } ?>    
               
            </tbody>
        </table>
    </div>
    </div>
   
</div>
<?php include("../../templates/footer.php"); ?>

<script>

$(document).ready( function () {
    $('table').DataTable({"pageLength":10,lengthMenu:[[3,10,25,50],[3,10,25,50]],"language":{"url":"/agua/admin/js/es-MX.json"},order: [[1,'asc']]});
} );

  </script>