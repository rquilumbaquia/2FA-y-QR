<?php use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';
    
     $mail = new PHPMailer;
     $mail->isSMTP(); 
     $mail->SMTPDebug = 0; 
     $mail->Host = "smtp.office365.com"; 
     $mail->Port = "587"; // typically 587 
     $mail->SMTPSecure = 'STARTTLS'; // ssl is depracated
     $mail->SMTPAuth = true;
     $mail->Username = "comite-de-agua@outlook.com";
     //$mail->Username = "junta-de-pijal@outlook.com";
     $mail->Password = "rqa123456";
     //$mail->setFrom("junta-de-pijal@outlook.com", "Sistema de Agua");
     $mail->setFrom("comite-de-agua@outlook.com", "Sistema de control de agua");
     $mail->addAddress($correo,'Usuario');
     $mail->Subject = 'Recuperacion de cuenta';
     $mail->msgHTML("Ingrese este codigo de recuperacion  en 5 Minutos :".$codigo); // remove if you do not want to send HTML email
     $mail->AltBody = 'HTML not supported';
    // $mail->addAttachment('imagenes/'.$archivo); //Attachment, can be skipped
   /* echo "<img src='../admin/libs/generadorqr/temp/".$archivo."'  />";*/
     $mail->addAttachment('../admin/libs/generadorqr/temp/'.$archivo); //Attachment, can be skipped
     $mail->send();
    
 

?>