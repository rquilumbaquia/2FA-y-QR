<?php

class Crypto {
    private $key;

    public function __construct(string $key) {
        $this->key = $key;
    }

    public function encrypt(string $value): string {
        // Generar un vector de inicialización aleatorio
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));

        // Encriptar el valor utilizando OpenSSL
        $encrypted = openssl_encrypt($value, 'aes-256-cbc', $this->key, 0, $iv);

        // Combinar el valor encriptado y el vector de inicialización en una cadena codificada en base64
        return base64_encode($encrypted . '::' . $iv);
    }

    public function decrypt(string $value): string {
        // Decodificar la cadena codificada en base64 y separar el valor encriptado del vector de inicialización
        $parts = explode('::', base64_decode($value), 2);

        // Desencriptar el valor utilizando OpenSSL
        $decrypted = openssl_decrypt($parts[0], 'aes-256-cbc', $this->key, 0, $parts[1]);

        // Devolver el valor desencriptado
        return $decrypted;
    }
}


// Crear una nueva instancia de Crypto
$crypto = new Crypto("esta-es-la-clave-secreta");

// Encriptar un valor
$encrypted_value = $crypto->encrypt("rodrigoq2024:Rqa123456***");

// Imprimir el valor encriptado
echo $encrypted_value;

// Desencriptar el valor
$decrypted_value = $crypto->decrypt($encrypted_value);

// Imprimir el valor desencriptado
echo $decrypted_value;
?>
<form action="descifrar.php" method="post">
    <input value="<?php echo $encrypted_value; ?>" name="cifrado" id="cifrado" />

<input type="submit" value="enviar">
</form>